#!/bin/sh

UNAME=`which uname`
ARCH=`$UNAME -m`
SYSTEM=`$UNAME`
PHP=`which php`

MIKBILL_PATH_LINUX="/var/www/mikbill"
MIKBILL_PATH_BSD="/usr/local/www/mikbill"

while true
do

case $SYSTEM in
Linux)
  cd $MIKBILL_PATH_LINUX/admin/
;;
FreeBSD)
  cd $MIKBILL_PATH_BSD/admin/
;;
esac

$PHP ./index.php runRosKomNadzorDaemon >/dev/null
sleep 1800
done
