#!/bin/bash

cd /var/www/mikbill/admin
