/bin/echo "Acct-Session-Id=9424520-vlan165-130,User-Name=cash07,NAS-IP-Address=10.10.254.7,Framed-IP-Address=192.168.47.153" | /usr/bin/radclient -r 1 10.10.254.7:3799 disconnect mik234
