#!/bin/bash

# writen by LD for MikBiLL
# http://www.mikbill.ru
#
# script params
# $1 - user ip from MikBiLL Database
# $2 - user uid from MikBiLL Database
# $3 - switch ip from MikBiLL Database 
# $4 - switch port from MikBiLL Database
# $5 - switch snmp comunity from MikBiLL Database
# $6 - switch snmp port from MikBiLL Database
# $7 - switchtype ID from MikBiLL Database
# $7 - swid old
# $8 - swid new
#
#disable port
#snmpset -v 2c -c [community] [ip] .1.3.6.1.2.1.2.2.1.7.[port] i 2
#enable port
#snmpset -v 2c -c [community] [ip] .1.3.6.1.2.1.2.2.1.7.[port] i 1

#echo "$5 $3 $4" >> /var/www/mikbill/admin/sys/scripts/log.txt

#/usr/bin/snmpset -v 2c -c $5 $3 .1.3.6.1.2.1.2.2.1.7.$4 i 2
#sleep 1
#/usr/bin/snmpset -v 2c -c $5 $3 .1.3.6.1.2.1.2.2.1.7.$4 i 1
