#!/bin/sh

cd /var/www/mikbill/admin/app/lib

#for BSD
#cd /usr/local/www/mikbill/admin/app/lib

#php -q ./mikbill.php kernel -d


