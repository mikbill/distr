#!/bin/bash

PHP=`which php`
cd /var/www/mikbill/admin/

$PHP ./index.php mbp_bras $1
