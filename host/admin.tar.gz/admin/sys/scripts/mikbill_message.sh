#!/bin/bash

cd /var/www/mikbill/admin/res/message

php ./message.php
