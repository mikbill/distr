#!/bin/sh

OS=`uname`
PHP=`which php`

if [ "$OS" == "Linux" ]; then
#for linux
cd /var/www/mikbill/admin/res/pcq
else
#for BSD
cd /usr/local/www/mikbill/admin/res/pcq
fi


$PHP ./pcq_script.php
