#!/bin/bash

cd /var/www/mikbill/admin
#for BSD
#cd /usr/local/www/mikbill/admin

php ./index.php block_dolgniki
#php ./index.php block_dolgniki_inet


