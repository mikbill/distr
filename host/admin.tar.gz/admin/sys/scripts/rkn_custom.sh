#!/bin/sh

echo `date`

