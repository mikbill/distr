#!/bin/bash

# writen by LD for MikBiLL
# http://www.mikbill.ru
#
# script params
# $1 - ticketid from MikBiLL Database

