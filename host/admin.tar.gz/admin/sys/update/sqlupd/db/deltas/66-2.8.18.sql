SET NAMES 'utf8';


INSERT INTO system_options (`key`, value) VALUES ('compay_uid_prio', '1'); 
INSERT INTO system_options (`key`, value) VALUES ('compay_login_prio', '2'); 
INSERT INTO system_options (`key`, value) VALUES ('compay_numdogovor_prio', '3');

INSERT INTO system_options (`key`, value) VALUES ('compay_uid', '1');
INSERT INTO system_options (`key`, value) VALUES ('compay_login', '0');
INSERT INTO system_options (`key`, value) VALUES ('compay_numdogovor', '0');

INSERT INTO system_options (`key`, value) VALUES ('privat_v2_payer_info_new', '0');

INSERT INTO system_options (`key`, value) VALUES ('nonstop_service_id_uid', '1');
INSERT INTO system_options (`key`, value) VALUES ('nonstop_service_id_login', '2');
INSERT INTO system_options (`key`, value) VALUES ('nonstop_service_id_numdogovor', '3');


