SET NAMES 'utf8';

INSERT INTO `system_options` (
`key` ,
`value`
)
VALUES (
'real_ip_link_with_packet_type', '0'
);

