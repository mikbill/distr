SET NAMES 'utf8';

INSERT INTO system_options (`key`, value) VALUES ('brasacctreopen', '0');
INSERT INTO system_options (`key`, value) VALUES ('kernelusecoa', '0');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_garden_service', 'MBOPENGARDEN');

INSERT INTO system_options (`key`, value) VALUES ('pscb_debug_on', '0');
INSERT INTO system_options (`key`, value) VALUES ('ukrpays_debug_on', '0');
INSERT INTO system_options (`key`, value) VALUES ('yandex_debug_on', '0');
INSERT INTO system_options (`key`, value) VALUES ('uniteller_debug_on', '0');
INSERT INTO system_options (`key`, value) VALUES ('uniteller_test', '0');

