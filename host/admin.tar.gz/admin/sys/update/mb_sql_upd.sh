#!/bin/bash

AWK=`which awk`
GREP=`which grep`
CAT=`which cat`
PHING=`which phing`


if [ "$PHING" == "" ];
then
    echo "Please install phing. SQL update aborted "
    exit
fi

BUILDPROP="./sqlupd/deploy/build.properties"
MBCONF="../../app/etc/config.xml"
MYSQLBIN=`which mysql`

HOST=`$CAT $MBCONF | $GREP host|$AWK '{ gsub("<host>"," "); print }' |$AWK '{ gsub("</host>"," "); print }'|$AWK '{print $1}'`
USERNAME=`$CAT $MBCONF | $GREP username |$AWK '{ gsub("<username>"," "); print }' |$AWK '{ gsub("</username>"," "); print }'|$AWK '{print $1}'`
PASSWORD=`$CAT $MBCONF | $GREP password |$AWK '{ gsub("<password>"," "); print }' |$AWK '{ gsub("</password>"," "); print }'|$AWK '{print $1}'`
DBNAME=`$CAT $MBCONF | $GREP dbname |$AWK '{ gsub("<dbname>"," "); print }' |$AWK '{ gsub("</dbname>"," "); print }'|$AWK '{print $1}'`

if [ "$HOST" == "" ];
then
 HOST="localhost"
fi

echo "" > $BUILDPROP
echo "build.dir=../" >> $BUILDPROP
echo "" >> $BUILDPROP
echo "db.host=$HOST" >> $BUILDPROP
echo "db.user=$USERNAME" >> $BUILDPROP
echo "db.pass=$PASSWORD" >> $BUILDPROP
echo "db.name=$DBNAME" >> $BUILDPROP
echo "" >> $BUILDPROP
echo "progs.mysql=$MYSQLBIN"  >> $BUILDPROP
echo "" >> $BUILDPROP

cd ./sqlupd/deploy

$PHING

cd ../..
echo "" > $BUILDPROP
