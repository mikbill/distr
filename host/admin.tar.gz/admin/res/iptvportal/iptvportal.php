﻿<?php

ini_set('maximum_execution_time', 3600);
$config_file = '/var/www/mikbill/admin/app/etc/config.xml';
#$config_file = 'D:\\WORK\\SOFT\\OpenServer\\domains\\admin2x\\app\\etc\\config.xml';
$pathToLogFile = './iptv.log';

$syncConfig = array(
//	'clear_services' => true,
//	'clear_terminals' => true,
//	'clear_users' => true
);

echo "<pre>";
include('./iptvportal_helper.php');

$link = connectToDB($CONF_MYSQL_HOST, $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD, $CONF_MYSQL_DBNAME);

# получить сис. опции
$IPTVOptions = getSystemOptionsIPTV($link);
if (!isset($IPTVOptions['iptvportal_login'], $IPTVOptions['iptvportal_pass'], $IPTVOptions['iptvportal_subdomain'])) {
	die('IPTVPortal does not configured in system options.');
}

$_auth_uri = 'https://admin.' . $IPTVOptions['iptvportal_subdomain'] . '.iptvportal.ru/api/jsonrpc/';
$_jsonsql_uri = 'https://admin.' . $IPTVOptions['iptvportal_subdomain'] . '.iptvportal.ru/api/jsonsql/';
$_iptvportal_header = null;

authorize_user($_auth_uri, $IPTVOptions['iptvportal_login'], $IPTVOptions['iptvportal_pass']);
//$user = authorize_user($_auth_uri, $_username, $_password);
//echo 'authorize user result: ';
//print_r($user);
echo "In!\n";

if (!empty($syncConfig['clear_services'])) {
	# удаление тарифов
	jsonsql_call("delete",
		array(
			"from" => "package",
		)
	);
}

if (!empty($syncConfig['clear_terminals'])) {
	# удаление терминалов
	jsonsql_call("delete",
		array(
			"from" => "terminal",
		)
	);
}

if (!empty($syncConfig['clear_users'])) {
	# удаление абонентов
	jsonsql_call("delete",
		array(
			"from" => "subscriber",
		)
	);
}

$usersMikBiLLLogin = array();
$usersIPTV = array();
$addUsers = array();
$deleteUsers = array();
$currentUsers = array();

# синхронищзация пакетов (услуг)
syncServicesIPTV($link);

$usersMikBiLL = getUsersWithServices($link);

foreach ($usersMikBiLL as $user) {
	$usersMikBiLLLogin[$user['user']] = 0;
}
//print_r($usersMikBiLL);
# по каждому абоненту выберем оборудование и услуги

# выборка списка абонентов
$usersIPTVList = getUsersIPTV();
//echo 'select users: ';
//print_r($usersIPTVList);
//print_r($usersMikBiLL);

foreach ($usersIPTVList as $user) {
	$usersIPTV[$user[1]] = $user;
}

foreach ($usersMikBiLL as $user) {
	if (!isset($usersIPTV[$user['user']])) {
		# новый
		$addUsers[] = $user;
	} else {
		# уже есть - обновить
		$currentUsers[] = $user;
	}
}

foreach ($usersIPTV as $user) {
	if (!isset($usersMikBiLLLogin[$user[1]])) {
		# удаление по логину
		$deleteUsers[] = $user[1];
	}
}

unset($usersMikBiLL, $usersIPTVList);

echo "\ndel: " . count($deleteUsers) . "\n";
#print_r($deleteUsers);
deleteAccountsIPTV($deleteUsers);
echo "\nadd: " . count($addUsers) . "\n";
#print_r($addUsers);
addAccountIPTV($addUsers);
echo "\ncurrent: " . count($currentUsers) . "\n";
changeCurrentUsers($currentUsers, $usersIPTV);

syncSubscriberServices();

# @TODO выбрать абонов с биллнга с услугами

# выборка списка тв медиа
/*$res = jsonsql_call("select", array(
	"data"  => array(
		"name",
		array(
			"concat" => array(
				"protocol",
				"://",
				"inet_addr",
				array(
					"coalesce" => array(
						array(
							"concat" => array(
								":",
								"port"
							)
						),
						""
					)
				),
				array(
					"coalesce" => array(
						array(
							"concat" => array(
								"/",
								"path"
							)
						),
						""
					)
				)
			),
			"as"     => "mrl"
		)
	),
	"from"  => "media",
	"where" => array(
		"eq" => array(
			"is_tv",
			true
		)
	)
));
echo 'select cmd result: '; print_r ($res);
*/

# выборка списка терминалов
//$res = jsonsql_call("select", array(
//	"data"     => array(
//		array("t" => "inet_addr"),
//		array("t" => "mac_addr"),
//		array("s" => "username")
//	),
//	"from"     => array(
//		array(
//			"table" => "terminal",
//			"as"    => "t"
//		),
//		array(
//			"join"      => "subscriber",
//			"join_type" => "left",
//			"as"        => "s",
//			"on"        => array(
//				"eq" => array(
//					array("t" => "subscriber_id"),
//					array("s" => "id")
//				)
//			)
//		)
//	),
//	"order_by" => array("s" => "username")
//));
//echo 'select cmd result: ';
//print_r($res);

# получение пакетов для акаунта "123456"
/*$res = jsonsql_call("select", array(
	"data"     => array(
		array("p" => "id"),
		array("p" => "name")
	),
	"from"     => array(
		array(
			"table" => "package",
			"as"    => "p"
		),
		array(
			"join"      => "subscriber_package",
			"join_type" => "inner",
			"as"        => "s2p",
			"on"        => array(
				"eq" => array(
					array("s2p" => "package_id"),
					array("p" => "id")
				)
			)
		),
		array(
			"join"      => "subscriber",
			"join_type" => "inner",
			"as"        => "s",
			"on"        => array(
				"eq" => array(
					array("s2p" => "subscriber_id"),
					array("s" => "id")
				)
			)
		)
	),
	"where"    => array(
		"eq" => array(
			array("s" => "username"),
			"123456"
		)
	),
	"order_by" => array("p" => "name")
));
echo 'select cmd result: ';
print_r($res);
*/

# получение терминалов для акаунта "123456"
//$res = jsonsql_call("select", array(
//	"data"  => array(
//		array("t" => "id"),
//		array("t" => "inet_addr"),
//		array("t" => "mac_addr")
//	),
//	"from"  => array(
//		array(
//			"table" => "terminal",
//			"as"    => "t"
//		),
//		array(
//			"join"      => "subscriber",
//			"join_type" => "inner",
//			"as"        => "s",
//			"on"        => array(
//				"eq" => array(
//					array("t" => "subscriber_id"),
//					array("s" => "id")
//				)
//			)
//		)
//	),
//	"where" => array(
//		"eq" => array(
//			array("s" => "username"),
//			"123456"
//		)
//	)
//));
//echo 'select cmd result: ';
//print_r($res);

# отключение абонента с акаунтом "123456"
//$res = jsonsql_call("update", array(
//	"table"     => "subscriber",
//	"set"       => array(
//		"disabled" => true
//	),
//	"where"     => array(
//		"eq" => array(
//			"username",
//			"123456"
//		)
//	),
//	"returning" => "id"
//));
//echo 'update cmd result: ';
//print_r($res);

# обновляем абонента с акаунтом "123456"
//$res = jsonsql_call("update", array(
//	"table"     => "subscriber",
//	"set"       => array(
//		"disabled" => true
//	),
//	"where"     => array(
//		"eq" => array(
//			"username",
//			"123456"
//		)
//	),
//	"returning" => "id"
//));
//echo 'update cmd result: ';
//print_r($res);

//if (!(count($res) > 0)) {
//	# добавление абонента "123456" с паролем "111"
//	$res = jsonsql_call("insert", array(
//		"into"      => "subscriber",
//		"columns"   => array(
//			"username",
//			"password"
//		),
//		"values"    => array(
//			"username" => "123456",
//			"password" => "111",
//		),
//		"returning" => "id"
//	));
//	echo 'insert cmd result: ';
//	print_r($res);
//}

# удаление пакетов "movie", "sports" для акаунта "123456"
/*$res = jsonsql_call("delete", array(
	"from"      => "subscriber_package",
	"where"     => array(
		"and" => array(
			array(
				"in" => array(
					"subscriber_id",
					array(
						"select" => array(
							"data"  => "id",
							"from"  => "subscriber",
							"where" => array(
								"eq" => array(
									"username",
									"123456"
								)
							)
						)
					)
				)
			),
			array(
				"in" => array(
					"package_id",
					array(
						"select" => array(
							"data"  => "id",
							"from"  => "package",
							"where" => array(
								"in" => array(
									"name",
									"movie",
									"sports"
								)
							)
						)
					)
				)
			)
		)
	),
	"returning" => "package_id"
));
echo 'delete cmd result: ';
print_r($res);*/

function addAccountIPTV($usersList)
{
	if (!empty($usersList)) {
		global $link;
		$usersData = array();
		$usersDevicesData = array();
		$MikBiLL2IPTV = array();
		$userDevice = array();
		$devices = array();
		$UIDsRow = '';
		$devidsRow = '';

		foreach ($usersList as $user) {
			$UIDsRow .= $user['uid'] . ',';
			$usersData[] = array(
				$user['user'],
				$user['password']
			);
		}

		$UIDsRow = substr($UIDsRow, 0, -1);

		# добавление абонентов
		$result = jsonsql_call("insert", array(
			"into"      => "subscriber",
			"columns"   => array(
				"username",
				"password"
			),
			"values"    => $usersData,
			"returning" => "id"
		));
		echo 'insert cmd result: ';
		#print_r($result);

		foreach ($result as $key => $subscriberID) {
			$MikBiLL2IPTV[$usersList[$key]['uid']] = $subscriberID;
		}

		$query = "SELECT * FROM `dev_user` WHERE `uid` IN ($UIDsRow) AND `devid` IN (SELECT `devid` FROM `dev_fields` WHERE `key` = 'devtypeid' AND `value` IN (SELECT `devtypeid` FROM `dev_types` WHERE `portal` = 1))";
		$userDeviceTmp = fetchAll($query, $link);

		foreach ($userDeviceTmp as $row) {
			$devidsRow .= $row['devid'] . ',';
			$userDevice[$row['devid']] = $row['uid'];
		}
		$devidsRow = substr($devidsRow, 0, -1);

		if (!empty($devidsRow)) {
			$query = "SELECT * FROM `dev_fields` WHERE `devid` IN ($devidsRow)";
			# по каждому новому абоненту выберем и соберём его оборудование из MikBiLL
			$devicesTmp = fetchAll($query, $link);

			# нужно "собрать" устройства
			foreach ($devicesTmp as $device) {
				$devices[$device['devid']][$device['key']] = $device['value'];
			}
		}

//		var_dump($userDevice['14'], $MikBiLL2IPTV[$userDevice[14]]);

		if (!empty($devices)) {
			foreach ($devices as $devid => $device) {
				$usersDevicesData[] = array(
					$MikBiLL2IPTV[$userDevice[$devid]],
					isset($device['dev_mac']) ? $device['dev_mac'] : '00:00:00:00:00:00',
					true
				);
			}

			# добавление терминала с мак-адресом
			$res = jsonsql_call("insert",
				array(
					"into"    => "terminal",
					"columns" => array(
						"subscriber_id",
						"mac_addr",
						"registered"
					),
					"values"  => $usersDevicesData
					//			"returning" => "id"
				)
			);
//		echo 'insert cmd result: ';
//		print_r($res);
		}
	}
}

function deleteAccountsIPTV($usersList)
{
	if (!empty($usersList)) {
		# составим список для удаления
		$deleteList = array(
			'username'
		);

		foreach ($usersList as $user) {
			$deleteList[] = $user;
		}

//		var_dump($deleteList);

		# удаление абонентских устройств акаунта
		jsonsql_call("delete", array(
				"from"  => "terminal",
				"where" => array(
					"in" => array(
						"subscriber_id",
						array(
							"select" => array(
								"data"  => "id",
								"from"  => "subscriber",
								"where" => array(
									"in" => $deleteList
								)
							)
						)
					)
				),
			)
		);

		# удаление пакетов для акаунта
		jsonsql_call("delete", array(
			"from"  => "subscriber_package",
			"where" => array(
				"in" => array(
					"subscriber_id",
					array(
						"select" => array(
							"data"  => "id",
							"from"  => "subscriber",
							"where" => array(
								"in" => $deleteList
							)
						)
					)
				)
			),
		));

		# удаление аккаунта
		jsonsql_call("delete", array(
			"from"  => "subscriber",
			"where" => array(
				"in" => $deleteList
			),
		));
	}
}

function changeCurrentUsers($usersMikBiLL, $usersIPTV)
{
	$addDevices = array();
	$allPortalDevice = array();
	$deleteDevices = array("id");

	if (!empty($usersMikBiLL)) {
		# проверка паролей

		#Получить все устройства пользователей
		$allDeviceTmp = getUsersPortalDevicesAll();
		foreach ($allDeviceTmp as $deviceTmp) {
				$allPortalDevice[$deviceTmp[0]] = $deviceTmp;
		}

		foreach ($usersMikBiLL as $user) {

			$MBDevices = array();
			$TVDevices = array();
			# идентификация устройств по MAC'ам

			$MBDevicesTmp = getUsersMBDevicesByUID($user['uid']);

			if(isset($allPortalDevice[$usersIPTV[$user['user']][0]])){
				$TVDevicesTmp = $allPortalDevice[$usersIPTV[$user['user']][0]];
			}else{
				$TVDevicesTmp = array();
			}

			foreach ($MBDevicesTmp as $device) {
				$MBDevices[mb_strtolower($device['dev_mac'])] = $device;
			}

			foreach ($TVDevicesTmp as $device) {
				$TVDevices[$device['1']] = $device;
			}

			# ищем новые устройства
			foreach ($MBDevices as $mac => $device) {
				if (!isset($TVDevices[$mac])) {
					$addDevices[] = array(
						$usersIPTV[$user['user']][0],
						$mac
					);
				}
			}

			# ищем удалённые устройства
			foreach ($TVDevices as $mac => $device) {
				if (!isset($MBDevices[$mac])) {
					$deleteDevices[] = $device[0];
				}
			}

//			print_r($MBDevices);
//			print_r($TVDevices);
//			var_dump($usersIPTV[$user['user']][0]);
//			print_r($user);
//			print_r($usersIPTV[$user['user']]);

//			if ($usersIPTV[$user['user']][2] != $user['user']['password']) {
//				# @TODO action
//			}
		}
	}

	if (!empty($addDevices)) {
		jsonsql_call("insert", array(
				"into"    => "terminal",
				"columns" => array(
					"subscriber_id",
					"mac_addr"
				),
				"values"  => $addDevices
			)
		);
	}

	if (count($deleteDevices) > 1) {
		jsonsql_call("delete", array(
				"from"  => "terminal",
				"where" => array(
					"in" => $deleteDevices
				),
			)
		);
	}
}

function send($url, $data, $extra_headers = null)
{
	$errorCounter = 0;
	$content = null;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	if (isset($extra_headers)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $extra_headers);
	}

	while ($errorCounter < 100) {
		//echo "HTTP fetching '$url'...\n";
		$content = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if ($content === false) {
			$err_msg = "HTTP error: $http_code (" . curl_error($ch) . ')' . '\n';
			echo $err_msg;
//		throw new Exception ($err_msg);
		} elseif ($http_code != 200) {
			$err_msg = "HTTP request failed ($http_code)\n";
			echo $err_msg;
//		throw new Exception ($err_msg);
		} else {
			//echo "HTTP OK ($http_code)\n";
			curl_close($ch);
			break;
		}
		$errorCounter++;
	}

	return $content;
}

function jsonrpc_call($url, $method, $params, $extra_headers = null)
{
	static $req_id = 1;

	$req = array(
		"jsonrpc" => '2.0',
		"id"      => $req_id++,
		"method"  => $method,
		"params"  => $params
	);
	$req = json_encode($req);
	$res = send($url, $req, $extra_headers);
	#echo $res;
	$res = json_decode($res, true);
	if (!isset($res)) {
		echo "error: not result\n";

		return null;
	} elseif (isset($res['error'])) {
//	} elseif (!array_key_exists('result', $res) || !isset($res['result'])) {
		print_r($res['error']);

		return null;
	} else {
		return $res['result'];
	}
}

function jsonsql_call($cmd, $params)
{
	global $_jsonsql_uri, $_iptvportal_header;

//	echo 'iptvportal_header: '; print_r ($_iptvportal_header);
	return jsonrpc_call($_jsonsql_uri, $cmd, $params, $_iptvportal_header);
}

function authorize_user($auth_uri, $username, $password)
{
	global $_iptvportal_header;
	$res = jsonrpc_call($auth_uri, $cmd = "authorize_user", $params = array(
		'username' => $username,
		'password' => $password
	));
	if (isset($res) AND array_key_exists('session_id', $res)) {
		$_iptvportal_header = array('Iptvportal-Authorization: ' . 'sessionid=' . $res ['session_id']);
	}

	return $res;
}

function getUsersMBDevicesByUID($uid)
{
	global $link;
	$devidsRow = '';
	$devices = array();

	$query = "SELECT * FROM `dev_user` WHERE `uid` = $uid AND `devid` IN (SELECT `devid` FROM `dev_fields` WHERE `key` = 'devtypeid' AND `value` IN (SELECT `devtypeid` FROM `dev_types` WHERE `portal` = 1))";
	$userDeviceTmp = fetchAll($query, $link);

	foreach ($userDeviceTmp as $row) {
		$devidsRow .= $row['devid'] . ',';
		$userDevice[$row['devid']] = $row['uid'];
	}
	$devidsRow = substr($devidsRow, 0, -1);

	if (!empty($devidsRow)) {
		$query = "SELECT * FROM `dev_fields` WHERE `devid` IN ($devidsRow)";
		# по каждому новому абоненту выберем и соберём его оборудование из MikBiLL
		$devicesTmp = fetchAll($query, $link);

		# нужно "собрать" устройства
		foreach ($devicesTmp as $device) {
			$devices[$device['devid']][$device['key']] = $device['value'];
		}
	}

	return $devices;
}

function getUsersPortalDevices($id)
{
	$devices = jsonsql_call("select", array(
		"data"  => array(
			"id",
			"mac_addr"
		),
		"from"  => "terminal",
		"where" => array(
			"eq" => array(
				"subscriber_id",
				$id
			)
		)
	));

	return $devices;
}

function getUsersPortalDevicesAll()
{
	$devices = jsonsql_call("select", array(
		"data" => array(
			"id",
			"mac_addr"
		),
		"from" => "terminal"
		//		"where" => array(
		//			"eq" => array("subscriber_id", $id)
		//		)
	));

	return $devices;
}

function deleteIPTVPacketFromUser($records = array())
{
	if (!empty($records)) {
		$parts = array();

		foreach ($records as $record) {
			$parts[] = array(
				"and" => array(
					array(
						"eq" => array(
							"subscriber_id",
							$record[0]
							# абон
						)
					),
					array(
						"eq" => array(
							"package_id",
							$record[1]
							# пакет
						)
					)
				)
			);
		}

		$where = array(
			"or" => $parts
		);

		jsonsql_call("delete", array(
				"from"  => "subscriber_package",
				"where" => $where
			)
		);
	}
}