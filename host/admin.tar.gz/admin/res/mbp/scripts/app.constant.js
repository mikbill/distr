angular.module('configApp', [])

.constant('RESOURCES', {PRODUCTION:true})

;