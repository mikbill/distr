<?php
/**
 * Created by PhpStorm.
 * User: Nekkoy
 * Date: 15.07.2015
 * Time: 17:26
 */
 
$config_file='../../app/etc/config.xml';

if (file_exists($config_file)) {
    $xml = simplexml_load_file($config_file);
    $TIME_ZONE           = (string) $xml->parameters->timezone;
} else {
    die("config not found");
}

if(isset($TIME_ZONE))
    date_default_timezone_set($TIME_ZONE);
else
    date_default_timezone_set('Europe/Kiev');
	
echo date('H:i:s');