<div id="block-system" class="block-style span5">
	<h6> <i class="icon-info-sign"></i> Системная информация <span onclick="mms.reloadBlock('system');" class="refresh system mif-ani-pulse mif-spinner2 float-right"> </span> </h6> 
	<dl class="dl-horizontal insert-block">
	  <dt> Версия ОС: </dt>
	  <dd id="system-os">
          <?php
          if($_SESSION["demo"] == true)
              echo $DemoData["OS"] . " " . $DemoData["Revision"];
          else
              echo $server->getOS();
          ?> </dd>
	  
	  <dt> Версия ядра: </dt>
	  <dd id="system-version">
          <?php
          if($_SESSION["demo"] == true)
              echo $DemoData["Kernel"];
          else
              echo $server->getKernel();
          ?> </dd>
	  
	  <dt> Время работы: </dt>
	  <dd id="system-uptime"> </dd>
	  
	  <dt> Активные: </dt>
	  <dd id="system-active"> </dd>
	  
	  <dt> Последний: </dt>
	  <dd id="system-last"> </dd>
	</dl>
</div>
<script>
	mms.getSystem();
	setInterval(mms.getSystem, system_interval*1000);
</script>