<div id="cpu-block" class="block-style span5">
	<h6><span class="mif-meter"></span> Процессор <span onclick="mms.reloadBlock('load_average');" class="refresh load_average mif-ani-pulse mif-spinner2 float-right"> </span> </h6>
	<table id="cpu-insert">
		<tr><td class="text-center">1 min</td><td class="text-center">5 min</td><td class="text-center">15 min</td></tr>
		<tr>
			<td>
				<div style="display: inline; width: 75px; height: 50px;">
					<canvas width="25" height="50"></canvas>
					<input type="text" class="gauge" id="load_1" value="0" data-height="50" data-width="75" data-min="0" data-max="100" data-readonly="true" data-fgcolor="#BED7EB" data-angleoffset="-90" data-anglearc="180" readonly="readonly">
				</div>
			</td>
			<td>
				<div style="display: inline; width: 75px; height: 50px;">
					<canvas width="25" height="50"></canvas>
					<input type="text" class="gauge" id="load_5" value="0" data-height="50" data-width="75" data-min="0" data-max="100" data-readonly="true" data-fgcolor="#BED7EB" data-angleoffset="-90" data-anglearc="180" readonly="readonly">
				</div>
			</td>
			<td>
				<div style="display: inline; width: 75px; height: 50px;">
					<canvas width="25" height="50"></canvas>
					<input type="text" class="gauge" id="load_15" value="0" data-height="50" data-width="75" data-min="0" data-max="100" data-readonly="true" data-fgcolor="#BED7EB" data-angleoffset="-90" data-anglearc="180" readonly="readonly">
				</div>
			</td>
		</tr>
	</table>	
</div>
<script>
	mms.getLoad_average();
	setInterval(mms.getLoad_average, cpu_interval*1000);
</script>