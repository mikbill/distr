<div id="disk-block" class="block-style span5">
	<h6><i class="icon-hdd"></i> Диск <span onclick="mms.reloadBlock('disk');" class="refresh disk mif-ani-pulse mif-spinner2 float-right"> </span> </h6> 
	<table id="disk-insert" >
		<tr>
			<td class="mount-point"> <td>
			<td class="mount-progress">
				<div class="progress">
					<div class="bar bar-success" style="width: 33%;">free</div>
					<div class="bar bar-warning" style="width: 33%;">used</div>
				</div>
			</td>
		</tr>
	</table>
</div>
<script>
	mms.getDisk();
	setInterval(mms.getDisk, disk_interval*1000);
</script>