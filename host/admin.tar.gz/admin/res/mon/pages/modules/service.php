<div id="block-service" class="block-style span5">
<h6> <span class="mif-cogs"></span> Службы <span onclick="mms.reloadBlock('service');" class="refresh service mif-ani-pulse mif-spinner2 float-right"> </span> </h6>
	<table id="service-insert" class="insert-block">

	</table>
</div>
<script>
	mms.getServices();
	setInterval(mms.getServices, service_interval*1000);
</script>