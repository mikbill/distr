<div id="block-nas" class="block-style span5">
<h6> <i class="icon-globe"></i> NAS сервера <span onclick="mms.updateNasPing();" class="refresh nas mif-ani-pulse mif-spinner2 float-right"> </span> </h6>
	<table id="nas-insert" class="insert-block">

	</table>
</div>
<script>
    mms.getNas();
    //setInterval(mms.getNas, nas_interval*1000);
</script>