<div id="memory-block" class="block-style span5">
	<h6> <i class="icon-th-list"></i> Память <span onclick="mms.reloadBlock('memory');" class="refresh memory mif-ani-pulse mif-spinner2 float-right"> </span> </h6> 
	<table id="memory-insert" class="insert-block">
		<tr id="memory-head">
			<td> Total </td><td> Used </td><td> Free </td>
		</tr>
		<tr>
			<td id="memory-total" class=" strong"> </td>
			<td id="memory-used"  class=" strong"> </td>
			<td id="memory-free"  class=" strong"> </td>
		</tr>
	</table>
</div>
<script>
	mms.getMemory();
	setInterval(mms.getMemory, memory_interval*1000);
</script>