<div id="block-switch" class="span10 block-style">
<h6> <span class="mif-shareable"></span> Список устройств </h6>
<table id="switch-insert" class="insert-block">

</table>
</div>
<script>
	mms.getSwitches();
	$("#nav-switches").addClass("active");
</script>