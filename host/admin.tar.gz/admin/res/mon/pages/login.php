<div class="row">
	<div class="span5">
		<div class="auth block-style span3">
			<h6> Войдите под учеткой билинга.</h6>
			<form id="auth" class="form-horizontal" action="index.php" method="post">
			  <div class="control-group">
				  <input type="text" name="login" id="login" placeholder="Логин" form="auth">
			  </div>
			  <div class="control-group">
				  <input type="password" name="password" id="password" placeholder="Пароль" form="auth">
			  </div>
			  <div class="control-group">
				  <button type="submit" class="btn float-right" form="auth">Войти</button>
			  </div>
			</form> 
		</div>
	</div>
</div>