<div id="block-servicePage" class="span6 block-style">
<h6> <span class="mif-cogs"></span> Службы <span onclick="mms.reloadBlock('servicePage');" class="refresh servicePage mif-ani-pulse mif-spinner2 float-right"> </span> </h6>
	<table id="service-insert" class="insert-block">

	</table>
</div>
<script>
	<?php echo "var service_interval = {$Config["refresh_time"]["service"]};"; ?>
	mms.getServicesPage();
	//setInterval(mms.getServicesPage, service_interval*1000);
	$("#nav-service").addClass("active");
</script>