<script>
$(function(){
	$('.gauge').knob({
		'fontWeight': 'normal',
		'format' : function (value) {
			return value + '%';
		}
	});

	$('a.reload').click(function(e){
		e.preventDefault();
	});
});

	<?php 
	echo "
		var system_interval = {$Config["refresh_time"]["system"]};
		var disk_interval = {$Config["refresh_time"]["disk"]};
		var memory_interval = {$Config["refresh_time"]["memory"]};
		var cpu_interval = {$Config["refresh_time"]["cpu"]};
		var service_interval = {$Config["refresh_time"]["service"]};
	";
	?>
	
	$("#nav-home").addClass("active");
</script>

	<div id="right-block" class="span5">
	<?php 
		foreach($Config["modules"] as $module)
		{
			if($module['enabled'] && $module['position'] == "right")
				include("pages/modules/{$module['name']}.php");
		}
	?>
	</div>
	<div id="left-block" class="span5">
	<?php 
		foreach($Config["modules"] as $module)
		{
			if($module['enabled']  && $module['position'] == "left")
				include("pages/modules/{$module['name']}.php");
		}
	?>
	</div>