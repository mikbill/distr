<?php

if($Config['logs']['enable'])
{
	$tabs = '';
	$datas = '';

    if($Config['general']['demo'])
    {
        foreach($DemoData['logs'] as $log)
        {
            $tabs .= "<li><a href='#{$log['name']}_log' data-toggle='tab'>{$log['name']}</a></li>";

            $datas .= "<div class='text-left tab-pane' id='{$log['name']}_log'>";
            $datas .= $log['text'];
            $datas .= "</div>";
        }
    }
    else
    {
        foreach($Config['logs'] as $log)
        {
            if($log['enabled'])
            {
                $tabs .= "<li><a href='#{$log['name']}_log' data-toggle='tab'>{$log['name']}</a></li>";
                exec("{$Config['general']['sudo']} tail -{$log['show_lines']} {$log['file']}", $result);

                $datas .= "<div class='text-left tab-pane' id='{$log['name']}_log'>";
                foreach($result as $text)
                {
                    $datas .= $text.'<br>';
                }
                $datas .= "</div>";
                unset($result);
            }
        }
    }

	
	echo '
            <div class="tabbable tabs-left span10 block-style">
            <h6> Просмотр логов </h6>
              <ul class="nav nav-tabs">
                '.$tabs.'
              </ul>
              <div class="tab-content">
                '.$datas.'
              </div>
            </div>
            <script>
                $(".nav-tabs > li:first").addClass("active");
                $(".tab-content > div:first").addClass("active");
                $("#nav-logs").addClass("active");
            </script>
            ';
}
