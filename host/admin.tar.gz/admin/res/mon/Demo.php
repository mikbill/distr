<?php
/**
 * Created by PhpStorm.
 * User: Nekkoy
 * Date: 20.07.2015
 * Time: 11:18
 */

$DemoData = array (
    'isp_name' => 'ISP.net Demo',

    'OS'            => 'Centos',
    'Revision'      => 'release 6.6 (Final)',
    'Kernel'        => '2.6.32-504.1.3.el6.x86_64',
    'Uptime'        => '1 day 16 hours 42 minutes',
    'ActiveUsers'   => 'root, admin',
    'LastUser'      => 'root Jul 19, 12:23',

    'DiskTotal' => 256,
    'DiskUse'   => 117,

    'RAM_total' => 4096,
    'RAM_used'  => 1274,

    'users' => array (
        '1' => array( //ID локального пользователя
            'enabled' => true, // включен ли пользователь
            'login' => 'demo', // логин
            'passwd'=> 'demo', // пароль
            'name'  => 'local users', // имя
            'access' => 3,  // уровень доступа:
        ),
    ),

    'Services' => array (
        'mikbill' => array(
            'name'   => 'Mikbill',
            'dname'   => 'mikbill',
            'desc'   => 'Ядро билинга',
            'status' => 1,
        ),
        'radiusd' => array(
            'name'   => 'Radius',
            'dname'   => 'radiusd',
            'desc'   => 'Сервер авторизации',
            'status' => 1,
        ),
        'mysqld' => array(
            'name'   => 'MySQL',
            'dname'   => 'mysqld',
            'desc'   => 'Сервер базы данных',
            'status' => 1,
        ),
        'dhcpd' => array(
            'name'   => 'DHCP',
            'dname'   => 'dhcpd',
            'desc'   => 'Раздача адресов в сети',
            'status' => 1,
        ),
        'named' => array(
            'name'   => 'DNS',
            'dname'   => 'named',
            'desc'   => 'DNS сервер',
            'status' => 1,
        ),
        'ntpd' => array(
            'name'   => 'NTP',
            'dname'   => 'ntpd',
            'desc'   => 'Синхронизация времени',
            'status' => 0,
        ),
    ),

    'NAS' => array (
        '1' => array (
            'name' => 'Accel PPP',
            'ip'   => 'localhost',
        ),
        '2' => array (
            'name' => 'Mikrotik Center',
            'ip'   => '172.16.255.101',
        ),
        '3' => array (
            'name' => 'Mikrotik Vokzal',
            'ip'   => '172.16.255.102',
        ),
        '4' => array (
            'name' => 'Accel IPoE',
            'ip'   => '172.16.255.103',
        ),
        '5' => array (
            'name' => 'Mikrotik PPP',
            'ip'   => '172.16.255.104',
        ),
        '6' => array (
            'name' => 'Accel PPP2',
            'ip'   => '172.16.255.105',
        ),
        '7' => array (
            'name' => 'Accel PPP3',
            'ip'   => '172.16.255.106',
        ),
    ),

    'Switches' => array (
        '1' => array (
          'name'   => 'dlink3200-10 1',
          'ip'     => '172.16.250.111',
          'online' => 0,
          'last'   => '2015-07-19 00:00:00'
        ),
        '2' => array (
            'name'   => 'dlink3200-10 2',
            'ip'     => '172.16.250.112',
            'online' => 1,
            'last'   => '2015-07-20 12:03:14'
        ),
        '3' => array (
            'name'   => 'dlink3200-10 3',
            'ip'     => '172.16.250.113',
            'online' => 1,
            'last'   => '2015-07-20 12:03:14'
        ),
        '4' => array (
            'name'   => 'dlink3200-10 4',
            'ip'     => '172.16.250.114',
            'online' => 1,
            'last'   => '2015-07-20 12:03:14'
        ),
        '5' => array (
            'name'   => 'dlink3200-10 5',
            'ip'     => '172.16.250.115',
            'online' => 0,
            'last'   => '2015-07-19 00:00:00'
        ),
        '6' => array (
            'name'   => 'dlink3200-10 6',
            'ip'     => '172.16.250.116',
            'online' => 1,
            'last'   => '2015-07-20 12:03:14'
        ),
        '7' => array (
            'name'   => 'dlink3200-10 7',
            'ip'     => '172.16.250.117',
            'online' => 1,
            'last'   => '2015-07-20 12:03:14'
        ),
        '8' => array (
            'name'   => 'dlink3200-10 8',
            'ip'     => '172.16.250.118',
            'online' => 1,
            'last'   => '2015-07-20 12:03:14'
        ),
        '9' => array (
            'name'   => 'dlink3200-10 9',
            'ip'     => '172.16.250.119',
            'online' => 1,
            'last'   => '2015-07-20 12:03:14'
        ),
        '10' => array (
            'name'   => 'dlink3200-10 10',
            'ip'     => '172.16.250.120',
            'online' => 0,
            'last'   => '2015-07-19 00:00:00'
        ),
        '11' => array (
            'name'   => 'dlink3200-10 11',
            'ip'     => '172.16.250.121',
            'online' => 1,
            'last'   => '2015-07-20 12:03:14'
        ),
    ),

    'logs' => array (
        '1' => array (
            'name' => 'mikbill',
            'text' => 'Bind succsess 0.0.0.0:2007<br>
                       MikBiLL start socket Listen!<br>
                       Daemon run succsess<br>
                       Bind succsess 0.0.0.0:2007<br>
                       MikBiLL start socket Listen!<br>
                       Daemon run succsess<br>
                       Bind succsess 0.0.0.0:2007<br>
                       MikBiLL start socket Listen!<br>
                       Daemon run succsess<br>
                       Bind succsess 0.0.0.0:2007<br>
                       MikBiLL start socket Listen!<br>
                       Daemon run succsess<br>
                       Bind succsess 0.0.0.0:2007<br>
                       MikBiLL start socket Listen!<br>
                       Daemon run succsess<br>
                       Bind succsess 0.0.0.0:2007<br>
                       MikBiLL start socket Listen!<br>
                       Daemon run succsess<br>
                       Bind succsess 0.0.0.0:2007<br>
                       MikBiLL start socket Listen!<br>',
        ),

        '2' => array (
            'name' => 'radius',
            'text' => '  Info: rlm_sql (sql): Driver rlm_sql_mysql (module rlm_sql_mysql) loaded and linked<br>
                         Info: rlm_sql (sql): Attempting to connect to root@localhost:3306/mikbill<br>
                         Info: rlm_sql (sql): Attempting to connect rlm_sql_mysql #0<br>
                         Info: rlm_sql_mysql: Starting connect to MySQL server for #0<br>
                         Error: rlm_sql_mysql: Couldnt connect socket to MySQL server root@localhost:mikbill<br>
                         Error: rlm_sql_mysql: Mysql error Cant connect to local MySQL server through socket /var/lib/mysql/mysql.sock<br>
                         Error: rlm_sql (sql): Failed to connect DB handle #0<br>
                         Error: rlm_sql (sql): There are no DB handles to use! skipped 1, tried to connect 0<br>
                         Error: Failed to load clients from SQL.<br>
                         Info: rlm_sql (sql): Closing sqlsocket 0<br>
                         Error: /etc/raddb/sql.conf[1]: Instantiation failed for module sql<br>
                         Error: /etc/raddb/sites-enabled/mikbill[33]: Failed to load module sql.<br>
                         Error: /etc/raddb/sites-enabled/mikbill[32]: Errors parsing session section.<br>
                         Error: Failed to load virtual server default<br>
                         Info: rlm_sql (sql): Driver rlm_sql_mysql (module rlm_sql_mysql) loaded and linked<br>
                         Info: rlm_sql (sql): Attempting to connect to root@localhost:3306/mikbill<br>
                         Info: rlm_sql (sql): Attempting to connect rlm_sql_mysql #0<br>
                         Info: rlm_sql_mysql: Starting connect to MySQL server for #0<br>
                         Info: rlm_sql (sql): Connected new DB handle, #0<br>
                         Info: Loaded virtual server default<br>
                         Info: Ready to process requests.<br>',
        ),

        '3' => array (
            'name' => 'system',
            'text' => ' dhcpd: No subnet declaration for eth0:0 (172.16.250.1).<br>
                        dhcpd: ** Ignoring requests on eth0:0.  If this is not what<br>
                        dhcpd:    you want, please write a subnet declaration<br>
                        dhcpd:    in your dhcpd.conf file for the network segment<br>
                        dhcpd:    to which interface eth0:0 is attached. **<br>
                        dhcpd:<br>
                        dhcpd: Listening on LPF/eth1/08:01:21:cd:1b:f4/10.2.0.0/24<br>
                        dhcpd: Sending on   LPF/eth1/08:01:21:cd:1b:f4/10.2.0.0/24<br>
                        dhcpd:<br>
                        dhcpd: No subnet declaration for eth0 (172.16.250.1).<br>
                        dhcpd: ** Ignoring requests on eth0.  If this is not what<br>
                        dhcpd:    you want, please write a subnet declaration<br>
                        dhcpd:    in your dhcpd.conf file for the network segment<br>
                        dhcpd:    to which interface eth0 is attached. **<br>
                        dhcpd:<br>
                        dhcpd: Sending on   Socket/fallback/fallback-net<br>',
        ),
    ),
);