//Mikbill Monitor System
var mms = {};


mms.getSystem = function() {

    $.post('index.php', {request:"system"}, function(data) {

        var $box = $('#block-system .insert-block');

        //console.log(data);

        mms.insertDatas($box, 'system', data);
		
		mms.delClass("system", "mif-ani-pulse", "mif-spinner2");
		mms.addText("system");
		mms.addClass("system", "label", "label-info");
    }, 'json');

}


mms.getLoad_average = function() {

    $.post('index.php', {request:"cpu_load"}, function(data) {

        //console.log(data);
        var $box = $('#cpu-block #cpu-insert');
        mms.reconfigureGauge($('input#load_1', $box), data[0]);
        mms.reconfigureGauge($('input#load_5', $box), data[1]);
        mms.reconfigureGauge($('input#load_15', $box), data[2]);
		
		console.log("1min:"+data[0]+", 5min:"+data[1]+", 15min:"+data[2]);
		
		mms.delClass("load_average", "mif-ani-pulse", "mif-spinner2");
		mms.addText("load_average");
		mms.addClass("load_average", "label", "label-info");
    }, 'json');

}


mms.getCpu = function() {

    $.post('index.php', {request:"cpu"}, function(data) {

        var $box = $('#block-hardware #cpu-info');

        mms.insertDatas($box, 'cpu', data);

    }, 'json');
}


mms.getMemory = function() {

    $.post('index.php', {request:"memory"}, function(data) {

		$box = $("#memory-block #memory-insert");
		
        mms.insertDatas($box, 'memory', data);

		mms.delClass("memory", "mif-ani-pulse", "mif-spinner2");
		mms.addText("memory");
		mms.addClass("memory", "label", "label-info");
    }, 'json');

}


mms.getDisk = function() {

    $.post('index.php', {request:"disk"}, function(data) {
		
		var $box = $('#disk-block #disk-insert');
        $box.empty();
		
        for (var line in data)
        {

			
			if(data[line].mount != "")
			{
                //console.log(data[line].total);
                //console.log(data[line].used);
                //console.log(data[line].free);
                //console.log(data[line].used_percent);

				var html = '';
				html += '<tr>';
				html += '	<td class="mount-point"> '+data[line].mount+' <td>';
				html += '	<td class="mount-progress">';
				html += '		<div class="progress">';
				html += '			<div class="bar bar-success" style="width: '+(100-data[line].used_percent)+'%;">'+data[line].free+' free</div>';
				html += '			<div class="bar bar-warning" style="width: '+data[line].used_percent+'%;">'+data[line].used+' used</div>';
				html += '		</div>';
				html += '	</td>';
				html += '</tr>';
				
				$box.append(html);
			}			
		}
		
		mms.delClass("disk", "mif-ani-pulse", "mif-spinner2");
		mms.addText("disk");
		mms.addClass("disk", "label", "label-info");
    }, 'json');

}

mms.getSwitches = function() {

    $.post('index.php', {request:"switch"},  function(data) {
	
		var $box = $('#block-switch #switch-insert');
        $box.empty();

        for (var line in data)
        {
			//console.log(data[line].name);
			
			var html = '';
			html += '<tr>';
			html += '<td class="switch-name"><strong>'+data[line].switch_name[0]+' </strong></td>';
			html += '<td class="switch-ip"> <small> '+data[line].switch_ip[0]+'</small> </td>';
            html += '<td class="switch-btn"> <button id="switch_'+data[line].switch_id[0]+'" onclick="mms.doSwitchPing(\''+data[line].switch_ip[0]+'\', \''+data[line].switch_id[0]+'\');" class="btn btn-info" data-loading-text="..." data-complete-text="ping" > ping </button> </td>';
            html += '<td class="switch-ping switch_'+data[line].switch_id[0]+'"> </td>';
            html += '<td class="check-date_sw'+data[line].switch_id[0]+'"> </td>';
			html += '</tr>';

            $box.append(html);
            mms.getPing(data[line].switch_id[0]);
        }
		
	}, 'json');

}

mms.getTime = function()
{
    $.get('date.php', function(data)
    {
        $('#datetime').text(data);
    });
}

mms.pluralize = function(number, one, two, five) {
    number = Math.abs(number);
    number %= 100;
    if (number >= 5 && number <= 20) {
        return five;
    }
    number %= 10;
    if (number == 1) {
        return one;
    }
    if (number >= 2 && number <= 4) {
        return two;
    }
    return five;
}

mms.calculateDate = function(time)
{
    var now = new Date(); // текущее время
    var fut = Date.parse( time ); // введенное время
    var delta = fut - now; // разница во времени (миллисекунды)
    var k = 1/1000; // формула перевод милисекунд в секунды
    var v = (Math.abs(delta)*k).toFixed(); // переводим в секунды

    var m = v/60%60; //пересчитываем секунды в минуты
    var h = v/60/60%24; //пересчитываем секунды в часы
    var d = v/60/60/24;
    //console.log(d);

    var text = " был доступен ";
    if(d >= 1)
        text += d.toFixed() +" д. ";

    if(h >= 1)
        text += h.toFixed() +" ч. ";

    if(m >= 1)
        text += m.toFixed() +" м. ";

    text += "назад";

    //console.log(d +" => "+text);

    return text;
}

mms.getPing = function(swid)
{
    $.post('index.php', {request:"get_ping", type:"sw", sid:swid }, function(data) {

        var $ping = $('#switch-insert .switch_'+swid);
        var $lastdate = $('#switch-insert .check-date_sw'+swid);

        //alert(data);
        //console.log(data);
        html = "";
        hdate = "";
        if(data.ping != 0)
        {
            html = "<span class='sw_ping color-green'>"+data.ping+" ms</span>";
            hdate = "<span class='check-date'><small>проверен: "+data.date+"</small></span>";
        }
        else
        {
            html = "<span class='sw_ping color-red'>не доступен</span> ";
            hdate = "<span class='check-date'><small>"+ mms.calculateDate(data.date)+"</small></span>";
        }
        $ping.empty();
        $lastdate.empty();
        $ping.append(html);
        $lastdate.append(hdate)
        }, 'json');
}

mms.doSwitchPing = function(swip, swid) {
	
	var $box = $('#switch_'+swid);
    var $ping = $('#switch-insert .switch_'+swid);

    $box.button('loading');
    $box.attr('disabled');
	
	$.post('index.php', {request:"ping_switch", ip:swip}, function(data) {
	
		html = "";
		(data.ping) ? html = "<span class='color-green'>"+data.ping+" ms</span>" : html = "<span class='color-red'>не доступен</span>";
        $ping.empty();
        $ping.append(html);

        $box.button('complete');
        $box.attr('enable');
		//setTimeout(function(){$('#switch_'+swid).text("ping");}, 1000);
		
	}, 'json');
}

mms.getNasOffline = function() {

    $.post('index.php', {request:"nas"}, function(data) {

        var $box = $('#block-nas #nas-insert');
        $box.empty();

        for (var line in data)
        {
			//console.log(data[line].name);
			
			var html = '';
			html += '<tr>';
			html += '<td class="nas-name"> <strong> '+data[line].name[0]+' </strong> </td>';
			html += '<td class="nas-ip"> <small> '+data[line].nasip[0]+'</small> </td>';
			(data[line].ping[0]) ? html += '<td class="nas-status"><span class="label label-success">&nbsp; &nbsp;'+data[line].ping[0]+' ms &nbsp;&nbsp;</span></td>' : html += '<td class="nas-status"><span class="label label-important">Не доступен</span></td>';
			html += '</tr>';

            $box.append(html);
        }
	mms.delClass("nas", "mif-ani-pulse", "mif-spinner2");
	mms.addText("nas");
	mms.addClass("nas", "label", "label-info");
    }, 'json');

}


mms.getNas = function() {

    $.post('index.php', {request:"nas"}, function(data) {

        var $box = $('#block-nas #nas-insert');
        $box.empty();

        console.log(data);

        for (var line in data)
        {

            //console.log(data[line].name);
            //console.log(data[line].nasip);

            //console.log(data[line].name);
            //console.log(data[line].nasip);

            var html = '';
            html += '<tr class="nasid'+data[line].nasid[0]+'">';
            html += '<td class="nas-name"> <strong> '+data[line].name[0]+' </strong> </td>';
            html += '<td class="nas-ip"> <small> '+data[line].nasip[0]+'</small> </td>';
            html += '<td id="nas_id'+data[line].nasid[0]+'" class="nas-status"> <span class="mif-ani-spin mif-spinner4"></span></td>'
            html += '</tr>';

            $box.append(html);

            mms.getNasPing(data[line].nasid[0]);
        }
        mms.delClass("nas", "mif-ani-pulse", "mif-spinner2");
        mms.addText("nas");
        mms.addClass("nas", "label", "label-info");
    }, 'json');

}

mms.updateNasPing = function()
{
    //console.log("Обновляю!");
    $(".nas").empty();
    mms.delClass("nas", "label", "label-info");
    mms.addClass("nas", "mif-ani-pulse", "mif-spinner2");

    $.post('nas_servers.php', function(data) {
        mms.getNas();
    });
    
    // **
    // var ip_array = $('#nas-insert tr .nas-ip small').text();
    //var arr = ip_array.split(' ');
    //for (var i = 0; i < arr.length; i++) {
    //    console.log("NAS IP: "+arr[i]);
    //}
    //setTimeout(mms.doPing(data[line].nasip[0], data[line].nasid[0]), 500);
    // **
}

mms.getNasPing = function(swid)
{
    $.post('index.php', {request:"get_ping", type:"nas", sid:swid }, function(data) {

        var $ping = $('#nas-insert #nas_id'+swid);

        //alert(data);
        //console.log(data);
        html = "";
        if(data.ping != 0)
        {
            html = '<span class="label label-success">&nbsp; &nbsp;'+data.ping+' ms &nbsp;&nbsp;</span>';
        }
        else
        {
            html = '<span class="label label-important">Не доступен</span>';
        }
        $ping.empty();
        $ping.append(html);

    }, 'json');
}

mms.doPing = function(ip, id) {
    $.post('ping.php', {target_ip:ip}, function(data) {
        var $box = $('#nas-insert .nasid'+id+' .nas-status');
        $box.empty();
        //console.log("Result for id:"+id);
        //console.log(data["_round_trip"]["avg"]);

            var html = "";
        if(data["_round_trip"]["avg"] != undefined)
            html += '<td class="nas-status"><span class="label label-success">&nbsp; &nbsp;'+data["_round_trip"]["avg"]+' ms &nbsp;&nbsp;</span></td>';
        else
            html += '<td class="nas-status"><span class="label label-important">Не доступен</span></td>';

        $box.append(html);
    }, 'json');
}

mms.getServices = function() {

    $.post('index.php', {request:"services"}, function(data) {

        var $box = $('#block-service #service-insert');
        $box.empty();

        for (var line in data)
        {
            var html = '';
			
			html += '<tr>';
			(data[line].status) ? html += '<td class="service-status"> <span class="label label-success">Вкл. &nbsp;&nbsp;</span> </td>' : html += '<td class="service-status"><span class="label label-important">Выкл.</span></td>';
			html += '<td class="service-name"> <strong> '+data[line].name+' </strong> </td>';
			html += '<td class="service-description"> <small> '+data[line].desc+' </small> </td>';
			html += '</tr>';
			
            $box.append(html);
        }
		
		mms.delClass("service", "mif-ani-pulse", "mif-spinner2");
		mms.addText("service");
		mms.addClass("service", "label", "label-info");
    }, 'json');

}

mms.getServicesPage = function() {

    $.post('index.php', {request:"services"}, function(data) {

        var $box = $('#block-servicePage #service-insert');
        $box.empty();

        for (var line in data)
        {
            var html = '';

			html += '<tr>';
			(data[line].status) ? html += '<td class="service-status"> <span class="label label-success">Вкл. &nbsp;&nbsp;</span> </td>' : html += '<td class="service-status"><span class="label label-important">Выкл.</span></td>';
			html += '<td class="service-name"> <strong> '+data[line].name+' </strong> </td>';
			//html += '<td class="service-description"> <small> '+data[line].desc+' </small> </td>';
			(data[line].status) ? 
				html += '<td class="service-onoff"> <button onclick="mms.doService(\''+data[line].dname+'\', \'stop\');" id="'+data[line].dname+'_btn_stop" class="btn " data-loading-text="Остановка..." data-complete-text="Выполнено" data-error-text="Ошибка!"> Выключить </button> </td>' : 
				html += '<td class="service-onoff"> <button onclick="mms.doService(\''+data[line].dname+'\', \'start\');" id="'+data[line].dname+'_btn_start" class="btn " data-loading-text="Запуск..." data-complete-text="Выполнено" data-error-text="Ошибка!"> Включить </button> </td>';
				
			html += '<td class="service-restart"> <button onclick="mms.doService(\''+data[line].dname+'\', \'restart\');" id="'+data[line].dname+'_btn_restart" class="btn btn-info" data-loading-text="Перезапуск..." data-complete-text="Выполнено" data-error-text="Ошибка!"> Перезапустить </button> </td>';
			html += '</tr>';
			
            $box.append(html);
        }
		
		mms.delClass("servicePage", "mif-ani-pulse", "mif-spinner2");
		mms.addText("servicePage");
		mms.addClass("servicePage", "label", "label-info");
    }, 'json');

}

mms.doService = function(service, action) {

    var $box = $('#'+service+'_btn_'+action);
    $box.button('loading');
    $box.attr('disabled');

    $.post('index.php', {request:"services", cmd:action, prog:service}, function(data) {

		if(data)
		{
            $box.removeClass('btn-info');
            $box.addClass('btn-success');
            $box.button('complete');
		}
		else
		{
            $box.removeClass('btn-info');
            $box.addClass('btn-danger');
            $box.button('error');
		}	
		//mms.callAlert(service, data, "text");
		setTimeout(mms.getServicesPage, 1000);
	}, 'json');
}

mms.getAll = function() {
    mms.getSystem();
    mms.getCpu();
    mms.getLoad_average();
    mms.getMemory();
    mms.getDisk();
    mms.getNas();
    mms.getServices();
}

mms.addClass = function(block, c1, c2) {
	$("."+block).addClass(c1);
	$("."+block).addClass(c2);
}

mms.delClass = function(block, c1, c2) {
	$("."+block).removeClass(c1);
	$("."+block).removeClass(c2);
}

mms.addText = function(block) {
	$("."+block).html("Обновить");
}

mms.callAlert = function(dname, type, text) {

	$('#alert_'+dname).empty();
	var html = "";
	
	if(type == 1)
		html += '<div class="offset4 span4 alert alert-block alert-success">';
	else
		html += '<div class="offset4 span4 alert alert-block alert-error">';
		
	html += '<button type="button" class="close" data-dismiss="alert">&times;</button>';
	html += '<div>'+text+'</div>';
	html += '</div>';
	
	$('#alert_'+dname).html(html);
}


mms.reloadBlock = function(block) {
	$("."+block).empty();
	mms.delClass(block, "label", "label-info");
	mms.addClass(block, "mif-ani-pulse", "mif-spinner2");
    setTimeout(mms.mapping[block], 2000);
}

mms.insertDatas = function($box, block, datas) {
    for (var item in datas)
    {
        //console.log(datas);
        $('#'+block+'-'+item, $box).html(datas[item]);
    }
}

mms.reconfigureGauge = function($gauge, newValue) {
    // Change colors according to the percentages
    var colors = { green : '#7BCE6C', orange : '#E3BB80', red : '#CF6B6B' };
    var color  = '';

    if (newValue <= 50)
        color = colors.green;
    else if (newValue <= 75)
        color = colors.orange;
    else
        color = colors.red;

    $gauge.trigger('configure', { 
        'fgColor': color,
        'inputColor': color,
        'fontWeight': 'normal',
        'format' : function (value) {
            return value + '%';
        }
    });

    // Change gauge value
    $gauge.val(newValue).trigger('change');
}


mms.mapping = {
    all: mms.getAll,
    system: mms.getSystem,
    load_average: mms.getLoad_average,
    cpu: mms.getCpu,
    memory: mms.getMemory,
    disk: mms.getDisk,
    nas: mms.getNas,
    service: mms.getServices,
	servicePage: mms.getServicesPage
};