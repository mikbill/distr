<?php
/**
 * Created by PhpStorm.
 * User: Nekkoy
 * Date: 14.07.2015
 * Time: 20:58
 */
//ini_set('display_errors',1);
//ini_set('error_reporting',2047);

define ("MAX_CHILD_PROCESSES", 5);
define ("CYCLE_DELAY", 1);
$stop_server = false;

include "Config.php";
if($Config["general"]["demo"])
{
    exit();
}

$start = microtime(true);

include 'DS/lib/ds.php';
include 'DS/lib/tools.ds.php';
include 'libs/Ping.php';

$config_file='../../app/etc/config.xml';

if (file_exists($config_file)) {
    $xml = simplexml_load_file($config_file);
    $TIME_ZONE           = (string) $xml->parameters->timezone;
    $CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
    $CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
    $CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
    $CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;

} else {
    die("config not found");
}

if(isset($TIME_ZONE) && $TIME_ZONE != "")
    date_default_timezone_set($TIME_ZONE);
else
    date_default_timezone_set("Europe/Kiev");

$data = array();

$mysqldb = new PDO( "mysql:host={$CONF_MYSQL_HOST};dbname={$CONF_MYSQL_DBNAME}", $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD,
    array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8") );
$ds = new DS ('./DS/' . 'store');

$QUERY = "SELECT id, nasname, shortname FROM radnas WHERE nasname != ''";
//$res = $mysqldb->query($QUERY, PDO::FETCH_LAZY);
$res = $mysqldb->prepare($QUERY);
$res->execute();
$res = $res->fetchAll();
$current = 0;
$child_processes = array();

$all = count($res);
printf('total tasks: %s, threads: %s' . "\n", $all, MAX_CHILD_PROCESSES);

while (!$stop_server) 
{
	if (!$stop_server and (count($child_processes) < MAX_CHILD_PROCESSES)) 
	{
		//TODO: получаем задачу
		//плодим дочерний процесс			
		if($current >= $all-1)
			$stop_server = true;

		$pid = pcntl_fork();
		if ($pid == -1) 
		{
			//TODO: ошибка - не смогли создать процесс
			printf('%s: error, can`t create process' . "\n", date("g:i:sa"));
		} 
		elseif ($pid) 
		{
			//printf('%s: child pid: %s created! ' . "\n", date("g:i:sa"), $pid);
			$current++;
			$child_processes[$pid] = true;
		} 
		else 
		{
			$pid = getmypid();
			//TODO: дочерний процесс - тут рабочая нагрузка
	
			$sw_id = $res[$current]["id"];
			$sw_name = $res[$current]["shortname"];
			$sw_ip = $res[$current]["nasname"];
			$date = date('Y-m-d H:i:s');
			$sw_ping = 0;
			
			$ping = Net_Ping::factory();
			if (PEAR::isError($ping)) {
				echo $ping->getMessage();
			} else {
				$ping->setArgs(array('count' => 1, 'timeout' => 2));
				$result = $ping->ping($sw_ip);
			}

			$result = (array)$result;
			if(isset($result["_round_trip"]["avg"]))
				$sw_ping = $result["_round_trip"]["avg"];

			if($sw_ping == 0 && file_exists('DS/store/nas/nas_data_'.$sw_id.'.json'))
			{
			   $old = file_get_contents('DS/store/nas/nas_data_'.$sw_id.'.json', true);
			   preg_match_all('/"date":"(.*?)"}"/', $old, $datetime);
			   
			   $date = $datetime[1][0];
			}
	
			printf('request #%s: swid=%s, ping=%s, checked=%s' . "\n",$current , $sw_id, $sw_ping, $date);

			$data = array (
				'id' => $sw_id,
				'ping' => $sw_ping,
				'date' => $date,
			);
			//echo "". var_dump($data) ."<br>";

			$data = json_encode($data);
			if(!file_exists('DS/store/nas/nas_data_'.$sw_id.'.json'))
			{
				//echo "<br> создаю id: {$sw_id}";
				$ds->put($data, 'nas_data_'.$sw_id, 'nas');
			}
			else
			{
					//echo "<br> обновляю id: {$sw_id}";
					$ds->delete('nas_data_'.$sw_id, 'nas');
					//unlink('DS/store/monitoring/sw_data_'.$sw_id.'.json');
					//echo $ds->status();
					$ds->put($data, 'nas_data_'.$sw_id, 'nas');
			}
			exit;
		}
	} 
	else 
	{
		//чтоб не гонять цикл вхолостую
		sleep(CYCLE_DELAY);
	}
	
	//проверяем, живы ли child процессы
	while ($signaled_pid = pcntl_waitpid(-1, $status, WNOHANG)) 
	{
		if ($signaled_pid == -1) 
		{
			//живых процесов нету
			//$stop_server = true;
			$child_processes = array(); 
			break;
		} 
		else 
		{
			//printf('%s: child pid: %s stopped! ' . "\n", date("g:i:sa"), $signaled_pid);
			unset($child_processes[$signaled_pid]);
		}
	}
}

unset($mysqldb);
unset($ds);
//var_dump($result);

$time = microtime(true) - $start;
printf('Скрипт выполнялся %.4F сек.', $time);

?>
