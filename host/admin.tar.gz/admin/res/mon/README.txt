﻿Установка:
1. Все уже находиться в  www/mikbill/admin/res/mon
2. добавить в крон скрипты для обновления информации об NAS/Switch:

# Monitoring
# Update switch info
0-59/5 * * * * root /var/www/mikbill/admin/res/mon/scripts/switches.sh > /dev/null 2>&1
# Update NAS info
0-59/5 * * * * root /var/www/mikbill/admin/res/mon/scripts/nas.sh > /dev/null 2>&1


3. Проверить права на файлы/скрипты.
4. Настроить Config.php под себя.
5. Запустить скрипт обновления информации или же подождать запуска из крона.
6. Открыть мониторинг по адресу http(s)://admin.ispnet.demo/res/mon/
7. Зайти под учеткой билинга.