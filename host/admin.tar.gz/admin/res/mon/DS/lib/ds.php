<?php

	/*
	* @package Data Store
	* @author Matvey Pravossudov / Crate
	* @version 1.0.0
	* JSON Data Base
	*/
	
	class DS {
		public $status_code = 0;
		public $status_msg = array ();
		
		protected $path;
		protected $ds = DIRECTORY_SEPARATOR;
		protected $version = '1.0.0';
		
		/* Settings path; securing DS */
		public function __construct ($path) {
			$this->path = rtrim ($path, '\\/');
			$this->secure();
			
			// Defines
			if ( ! defined ('DS_VERSION')) {define ('DS_VERSION', '1.0.0');}
		}
		
		/* Cleaning data */
		public function clean ($data) {
			if (is_array ($data)) {
				$result = array ();
				foreach ($data as $key => $value) {
					$result[$key] = escapeshellcmd (addslashes (trim ($value)));
				}
			}
			else if (is_string ($data)) {
				$result = escapeshellcmd (addslashes (trim ($value)));
			}
			else {$result = $data;}
			return $result;
		}
		
		/* Creating new table (directory) */
		public function create ($table) {
			$this->statusCODE = 0;
			$this->statusMSG = array ();
			
			if ( ! file_exists ($this->path . $this->ds . $table)) {
				mkdir ($this->path . $this->ds . $table);
				
				$config = array (
					'created' => date ('Y-m-d h:i:s')
				);
				
				return file_put_contents ($this->path . $this->ds . $table . $this->ds . 'config.ds.json', json_encode ($config));
			}
			else {
				$this->status_code = 101;
				$this->status_msg[] = 'Table "' . $table . '" already exists.';
				return false;
			}
		}
		
		/* Deleting item (directory) */
		public function delete ($item, $table) {
			$this->statusCODE = 0;
			$this->statusMSG = array ();
			
			if (file_exists ($this->path . $this->ds . $table . $this->ds . $item . '.json')) {
				return unlink ($this->path . $this->ds . $table . $this->ds . $item . '.json');
			}
			else {return false;}
		}
		
		/* Deleting table (directory) */
		public function drop ($table) {
			$this->statusCODE = 0;
			$this->statusMSG = array ();
			
			if (file_exists ($this->path . $this->ds . $table)) {
				foreach (glob ($this->path . $this->ds . $table . $this->ds . "*.json") as $item) {
					unlink ($this->path . $this->ds . $table . $this->ds . basename ($item));
				}
				return rmdir ($this->path . $this->ds . $table);
			}
			else {
				$this->status_code = 102;
				$this->status_msg[] = 'Table "' . $table . '" doesn\'t exists.';
				return false;
			}
		}
		
		/* Checking for exists */
		public function exists ($name, $type = 'table') {
			if ($type == 'item' && is_array ($name)) {
				if (file_exists ($this->path . $this->ds . $name[0] . $this->ds . $name[1] . '.json')) {return true;}
				else {return false;}
			}
			else if ($type == 'table') {
				if (file_exists ($this->path . $this->ds . $name)) {return true;}
				else {return false;}
			}
			else {return false;}
		}
		
		/* Getting data from item (directory) */
		public function get ($select = '*', $item, $table) {
			$this->statusCODE = 0;
			$this->statusMSG = array ();
			
			if (file_exists ($this->path . $this->ds . $table . $this->ds . $item . '.json')) {
				$file = file_get_contents ($this->path . $this->ds . $table . $this->ds . $item . '.json');
				$data = json_decode ($file, true);
				
				if ($select || $select == '*') {
					$result = array ();
					foreach ($select as $key) {
						$result[$key] = $data[$key];
					}
					return $result;
				}
				else {return $data;}
			}
			else {
				$this->status_code = 103;
				$this->status_msg[] = 'Item "' . $item . '" doesn\'t exists.';
				return false;
			}
		}
		
		/* Getting config rom table (directory) */
		public function getConfig ($table) {
			$this->statusCODE = 0;
			$this->statusMSG = array ();
			
			if (file_exists ($this->path . $this->ds . $table)) {
				$file = file_get_contents ($this->path . $this->ds . $table . $this->ds . 'config.ds.json');
				return json_decode ($file, true);
			}
			else {
				$this->status_code = 102;
				$this->status_msg[] = 'Table "' . $table . '" doesn\'t exists.';
				return false;
			}
		}
		
		/* Merging tables (directories) */
		public function merge ($tables = array (), $name = false) {
			$this->statusCODE = 0;
			$this->statusMSG = array ();
			
			$items = array ();
			foreach ($tables as $table) {
				if (file_exists ($this->path . $this->ds . $table)) {
					foreach (glob ($this->path . $this->ds . $table . $this->ds . '*.json') as $item) {
						$items[$this->bn($item)] = file_get_contents ($item);
					}
					$this->drop($table);
				}
				else {
					$this->status_code = 102;
					$this->status_msg[] = 'Table "' . $table . '" doesn\'t exists.';
					return false;
				}
			}
			
			if ($name) {
				if ( ! file_exists ($this->path . $this->ds . $name)) {
					$this->create($name);
                    unset ($items['config.ds']);
					foreach ($items as $key => $value) {
						file_put_contents ($this->path . $this->ds . $name . $this->ds . $key . '.json', $value);
					}
				}
				else {
					$this->status_code = 101;
					$this->status_msg[] = 'Table "' . $name . '" already exists.';
					return false;
				}
			}
			else {
				mkdir ($this->path . $this->ds . $tables[0]);
				foreach ($items as $key => $value) {
					file_put_contents ($this->path . $this->ds . $tables[0] . $this->ds . $key . '.json', $value);
				}
			}
		}
		
		/* Putting data to item (directory) */
		public function put ($data, $item, $table) {
			$this->statusCODE = 0;
			$this->statusMSG = array ();
			
			if ( ! file_exists ($this->path . $this->ds . $table . $this->ds . $item . '.json')) {

				$result = json_encode ($data);
				$result = str_replace ('\\', '', $result); // FM
				return file_put_contents ($this->path . $this->ds . $table . $this->ds . $item . '.json', $result);
			}
			else {
				$this->status_code = 104;
				$this->status_msg[] = 'Item "' . $item . '" already exists.';
				return false;
			}
		}
		
		/* Searching data from table (directory) */
		public function search ($needle, $table) {
			$result = array ();
			foreach (glob ($this->path . $this->ds . $table . $this->ds . "*.json") as $item) {
				$file = file_get_contents ($this->path . $this->ds . $table . $this->ds . basename ($item));
				if (strpos ($file, $needle)) {$result[] = $this->bn($item);}
			}
			return $result;
		}
		
		/* Setting data in item (directory) */
		public function set ($data, $item, $table) {
			if (file_exists ($this->path . $this->ds . $table . $this->ds . $item . '.json')) {
				$file = file_get_contents ($this->path . $this->ds . $table . $this->ds . $item . '.json');
				$result = array_merge (json_decode ($file, true), $data);
				return file_put_contents ($this->path . $this->ds . $table . $this->ds . $item . '.json', json_encode ($result));
			}
			else {return false;}
		}
		
		/*
		 * Get status of last request.
		 * $flag - true or false.
		 * if true - return text message
		 * if fasle - return status code.
		 *
		 * Status codes:
		 * 0 - All OK.
		 * 101 - Table already exists.
		 * 102 - Table doesn't exists.
		 * 103 - Item already exists.
		 * 104 - Item doesn't exists. 
		 * 105 - Unknown property.
		 * 201 - Key already exists.
		 * 202 - Keys doesn't exists. 
		*/
		public function status ($flag = false){
			return ( ! $flag) ? $this->status_code : implode ('; ', $this->status_msg);	
		}
		
		/* Truncating table (directory) */
		public function truncate ($table) {
			if (file_exists ($this->path . $this->ds . $table)) {
				foreach (glob ($this->path . $this->ds . $table . $this->ds . '*.json') as $item) {
					unlink ($this->path . $this->ds . $table . $this->ds . basename ($item));
				}
			}
			else {return false;}
		}
		
		/* DS version */
		public function version () {
			return $this->version;
		}
		
		/* Basename */
		protected function bn ($name) {
			if (is_array ($name)) {
				$result = array ();
				foreach ($name as $item) {
					$result[$item] = str_replace ('.json', '', basename ($item));
				}
				return $result;
			}
			else if (is_string ($name)) {return str_replace ('.json', '', basename ($name));}
			else {return $name;}
		}
		
		/* Securing DS */
		private function secure () {
			if ( ! file_exists ($this->path . $this->ds . '.htaccess')) {
				$data = "<Files *>\n\tOrder Allow,Deny\n\tDeny from All\n</Files>";
				file_put_contents ($this->path . $this->ds . '.htaccess', $data);
			}
			else {return false;}
		}
	}
?>