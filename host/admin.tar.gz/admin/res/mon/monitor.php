<!DOCTYPE html>
<html lang="ru-en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $Config["general"]["isp_name"]; ?></title>
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Mikbill monitor -->
    <link href="css/mms.css" rel="stylesheet">
    <!-- Metro Icons -->
    <link href="css/metro-icons.css" rel="stylesheet">

    <script src="js/jquery-latest.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.knob.js"></script>
    <script src="js/mms.js"></script>

    <script>
        <?php echo "var currentTime = new Date('".date('F d, Y H:i:s')."');"; ?>
        var hours   = currentTime.getHours();
        var minutes = currentTime.getMinutes();
        var seconds = currentTime.getSeconds();

        var hoursQ;
        var minutesQ;
        var secondsQ;
        function updateTime()
        {
            if(seconds<59)
                seconds++;
            else
            {
                seconds=0;
                if(minutes <59)
                    minutes++;
                else
                {
                    minutes=0;
                    hours++;
                    if(hours>=24)
                        hours=0;
                }
            }
            if(hours <=9)
                hoursQ = "0"+hours;
            else
                hoursQ = hours;
            if(minutes <=9)
                minutesQ = "0"+minutes;
            else
                minutesQ = minutes;
            if(seconds <=9)
                secondsQ = "0"+seconds;
            else
                secondsQ = seconds;

            $('#datetime').text(hoursQ+":"+minutesQ+":"+secondsQ);
        }
        setInterval(updateTime, 1000);
    </script>
</head>
<body>

<div class="row">
    <div class="block-style span10">
        <h3 class="lead"> <?php echo $Config["general"]["isp_name"]; ?> </h3><span id="server-datetime"><small>Время на сервере: <span id="datetime"></span></small> </span>
        <ul class="nav nav-pills">
            <li id="nav-home"><a href="index.php"> <i class="icon-home"></i> Главная </a></li>
            <!-- <li id="nav-cpu"><a href="#"> <i class="icon-random"></i> Процессы </a></li> -->
            <!-- <li id="nav-users"><a href="#"> <span class="mif-users"></span> Пользователи </a></li> -->
            <?php
            if($user->getAccess() == 3)
                echo '<li id="nav-service"><a href="index.php?page=services"> <span class="mif-cogs"></span> Службы </a></li>';

            if($Config["switch"]["enable"] && $user->getAccess() >= 2)
                echo '<li id="nav-switches"><a href="index.php?page=switches"> <span class="mif-shareable"></span> Устройства </a></li>';

            if($Config["logs"]["enable"] && $user->getAccess() >= 1)
                echo '<li id="nav-logs"><a href="index.php?page=logs"> <i class="icon-time"></i> Логи сервера </a></li>';

            if($Config["general"]["billing_auth"])
                echo '<li id="nav-exit"><a href="index.php?page=logout"> <span class="mif-switch"></span> Выход </a></li>';
            ?>
        </ul>
    </div>
</div>

<div id="content" class="row">
    <div class="span10">

        <?php
        if(isset($_GET["page"]))
        {
            switch($_GET["page"])
            {
                case "logout":
                    {
                        session_destroy();
                        header( 'Location: index.php', true, 307 );
                        break;
                    }

                case "services":
                    {
                        if($user->getAccess() == 3)
                            include ("pages/services.php");
                        break;
                    }
                case "switches":
                    {
                        if($Config["switch"]["enable"] && $user->getAccess() >= 2)
                            include ("pages/switches.php");
                        break;
                    }
                case "logs":
                    {
                        if($Config["logs"]["enable"] && $user->getAccess() >= 1)
                            include ("pages/logs.php");
                        break;
                    }
                default:
                    include ("pages/module-container.php");
            }
        }
        else
        {
            include ("pages/module-container.php");
        }
        ?>

    </div>
</div>


<div id="footer"></div>
</body>
</html>