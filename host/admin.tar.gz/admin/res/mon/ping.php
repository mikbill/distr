<?php
session_start();

if($_SESSION["logged"] == true)
{
    require_once "libs/Ping.php";
    $ping = Net_Ping::factory();
    if (PEAR::isError($ping)) {
        echo $ping->getMessage();
    } else {
        $ping->setArgs(array('count' => 1, 'timeout' => 3));
        $result = $ping->ping($_POST["target_ip"]);
    }

    echo json_encode($result);
}

