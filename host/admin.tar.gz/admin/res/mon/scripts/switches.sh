#!/bin/bash

OS=`uname`
PHP=`which php`

if [ "$OS" == "Linux" ]; then
#for linux
cd /var/www/mikbill/admin/res/mon/
else
#for BSD
cd /usr/local/www/mikbill/admin/res/mon/
fi

$PHP ./switch_threads.php
