<?php
$Config = array (
	/** Общие настройки **/
	'general' => array (
		'isp_name' => 'ISP.net мониторинг', /** Название провайдера **/
		'sudo'	=> '/usr/bin/sudo', /** путь к sudo (узнать which sudo)**/	
		'billing_auth' => true, /** Использовать аунтификацию из билинга**/
		'debug' => false,
        'demo'  => false,
		),
    // пользователи
    'users' => array (
    /*
        '1' => array( //ID локального пользователя
			'enabled' => true, // включен ли пользователь
            'login' => 'admin', // логин
            'passwd'=> 'admin', // пароль
            'name'  => 'local users', // имя
            'access' => 3,  // уровень доступа:
        ),
        */
    ),
	/** Время автообновления модулей **/
	'refresh_time' => array (
		'system' => 60, // блок system, обновление 60 сек
		'disk'	=> 300, // блок disk, обновление 300 сек
		'memory' => 60, // блок memory, обновление 60 сек
		'cpu'	=> 60, // блок cpu, обновление 60 сек
		'service' => 60, // блок service, обновление 60 сек
		),
	/** Настройка модулей **/
	'modules' => array (
		'1' => array (
			'name' => 'system', // имя модуля
			'enabled' => true,  // включен ли модуль
			'position' => 'right'), // положение модуля
		
		'3' => array (
			'name' => 'cpu', // имя модуля
			'enabled' => true,  // включен ли модуль
			'position' => 'left'), // положение модуля
		
		'4' => array (
			'name' => 'disk', // имя модуля
			'enabled' => true,  // включен ли модуль
			'position' => 'left'), // положение модуля
		
		'2' => array (
			'name' => 'memory', // имя модуля
			'enabled' => true,  // включен ли модуль
			'position' => 'right'), // положение модуля
			
		'5' => array (
			'name' => 'service', // имя модуля
			'enabled' => true,  // включен ли модуль
			'position' => 'right'), // положение модуля
		
		'6' => array (
			'name' => 'nas', // имя модуля
			'enabled' => true,  // включен ли модуль
			'position' => 'left'), // положение модуля
			
		),
	/** Отображать подкачку в инфе о дисках **/
	'disk' => array (
		'show_tmpfs' => false,
		),
	/** Статус свичей **/
	'switch' => array (
		'enable' => true, // Вкл/Выкл
	),		
	/** Настройка логов **/
	'logs' => array (
		'enable' => true, // включено ли отображение логов

		'1' => array( // ID лога
		'enabled' => true, // выключен ли
		'name'	=> 'mikbill', // имя
		'file'	=> '/var/log/mikbill.log', // путь к файлу лога
		'show_lines' => 10), // сколько строк с конца отображать
		
		'2' => array ( // ID лога
		'enabled' => true, // выключен ли
		'name'	=> 'radius', // имя
		'file'	=> '/var/log/radius/radius.log', // путь к файлу лога
		'show_lines' => 20), // сколько строк с конца отображать
		
		'3' => array ( // ID лога
		'enabled' => true, // выключен ли
		'name'	=> 'system',
		'file'	=> '/var/log/messages', // путь к файлу лога
		'show_lines' => 30), // сколько строк с конца отображать
		
		'4' => array ( // ID лога
		'enabled' => true, // выключен ли
		'name'	=> 'cron', // имя
		'file'	=> '/var/log/cron', // путь к файлу лога
		'show_lines' => 20), // сколько строк с конца отображать
		
		'5' => array ( // ID лога
		'enabled' => false, // выключен ли
		'name'	=> 'Admin_access', // имя
		'file'	=> '/var/log/httpd/admin.ispnet.demo_access_log', // путь к файлу лога
		'show_lines' => 30), // сколько строк с конца отображать
		
		'6' => array ( // ID лога
		'enabled' => false, // выключен ли
		'name'	=> 'Admin_error', // имя
		'file'	=> '/var/log/httpd/admin.ispnet.demo_error_log', // путь к файлу лога
		'show_lines' => 30), // сколько строк с конца отображать
		

		),
	/** Настройка сервисов **/
	'services' => array (
		'1' => array (  
            'enabled' => true, // включено ли слежение за сервисом
            'name'	=> 'Mikbill', // имя сервиса
            'description' => 'Ядро билинга', // описание
            'daemon_name' => 'mikbill'), // точное название ( как в /etc/init.d/)
		
		'2' => array (
            'enabled' => true, // включено ли слежение за сервисом
            'name'	=> 'Radius', // имя сервиса
            'description' => 'Сервер авторизации', // описание
            'daemon_name' => 'radiusd'), // точное название ( как в /etc/init.d/)
		
		'3' => array (
            'enabled' => true, // включено ли слежение за сервисом
            'name'	=> 'MySQL', // имя сервиса
            'description' => 'Сервер базы данных', // описание
            'daemon_name' => 'mysqld'), // точное название ( как в /etc/init.d/)
		
		'4' => array (
            'enabled' => true, // включено ли слежение за сервисом
            'name'	=> 'DHCP', // имя сервиса
            'description' => 'Раздача адресов в сети', // описание
            'daemon_name' => 'dhcpd'), // точное название ( как в /etc/init.d/)
		
		'5' => array (
            'enabled' => false, // включено ли слежение за сервисом
            'name'	=> 'PKH', // имя сервиса
            'description' => 'Модуль РосКомНадзора', // описание
            'daemon_name' => 'mikbill_rkn'), // точное название ( как в /etc/init.d/)
		
		'6' => array (
            'enabled' => true, // включено ли слежение за сервисом
            'name'	=> 'DNS', // имя сервиса
            'description' => 'DNS сервер', // описание
            'daemon_name' => 'named'), // точное название ( как в /etc/init.d/)

        '11' => array (
            'enabled' => false, // включено ли слежение за сервисом
            'name'	=> 'Bind9', // имя сервиса
            'description' => 'DNS сервер', // описание
            'daemon_name' => 'bind9'), // точное название ( как в /etc/init.d/)

		'7' => array (
            'enabled' => false, // включено ли слежение за сервисом
            'name'	=> 'SSH', // имя сервиса
            'description' => 'Удаленное управление', // описание
            'daemon_name' => 'sshd'), // точное название ( как в /etc/init.d/)
		
		'9' => array (
            'enabled' => false, // включено ли слежение за сервисом
            'name'	=> 'Cron', // имя сервиса
            'description' => 'Выполнение скриптов по расписанию.', // описание
            'daemon_name' => 'crond'), // точное название ( как в /etc/init.d/)

        '10' => array (
            'enabled' => true, // включено ли слежение за сервисом
            'name'	=> 'NTP', // имя сервиса
            'description' => 'Синхронизация времени', // описание
            'daemon_name' => 'ntpd'), // точное название ( как в /etc/init.d/)


		),
);