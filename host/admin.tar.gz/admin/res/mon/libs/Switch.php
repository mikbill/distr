<?php
/**
 * Created by PhpStorm.
 * User: nekkoy
 * Date: 04.07.2015
 * Time: 15:11
 */

class Switches
{
    public function do_ping($ip)
    {
        exec("/bin/ping -qc 1 -w 3 {$ip} | awk -F/ '/^rtt/ { print $5 }'", $result);
        if (!isset($result[0]))
            $result[0] = 0;

        $data = array('ping' => $result[0]);

        return json_encode($data);
    }

    public function getJSON()
    {

        //Получаем список NASов
        $send = new Utility;
        $response = $send->sendRequest(Links::swList, false, $_SESSION["cookie"], "");
        $data = array();

        if($response != null)
        {
            $xml = new SimpleXMLElement($response);

            foreach($xml->element as $switch)
            {
                //var_dump($nas);
                if($switch["ip"] == null || $switch["ip"] =='')
                    continue;

                $data[] = array(
                    'switch_id'   => $switch["swid"],
                    'switch_ip'   => $switch["ip"],
                    'switch_name' => $switch["nameswitch"],
                );

                unset($switch);
            }
        }
        else
        {
            $data[] = array(
                'switch_id'   => 0,
                'switch_ip'   => "null",
                'switch_name' => "error",
            );
        }
        unset($send);
        return json_encode($data);
    }
}