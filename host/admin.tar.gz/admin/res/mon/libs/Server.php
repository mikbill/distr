<?php
/**
 * Created by PhpStorm.
 * User: nekkoy
 * Date: 04.07.2015
 * Time: 11:56
 */
error_reporting(0);

class Server
{
    public static function getHostname()
    {
        return php_uname('n');
    }

    public static function getLanIp()
    {
        return $_SERVER['SERVER_ADDR'];
    }

    public static function getKernel()
    {
        return php_uname("r");
    }

    public static function getUptime()
    {
        if (!($totalSeconds = shell_exec('/usr/bin/cut -d. -f1 /proc/uptime')))
            $uptime = 'N.A';
        else
        {
            $totalMin   = $totalSeconds / 60;
            $totalHours = $totalMin / 60;

            $days  = floor($totalHours / 24);
            $hours = floor($totalHours - ($days * 24));
            $min   = floor($totalMin - ($days * 60 * 24) - ($hours * 60));

            $uptime = '';
            if ($days != 0)
                $uptime .= $days.' day'.Utility::pluralize($days).' ';

            if ($hours != 0)
                $uptime .= $hours.' hour'.Utility::pluralize($hours).' ';

            if ($min != 0)
                $uptime .= $min.' minute'.Utility::pluralize($min);
        }

        return $uptime;
    }

    public static function getOS()
    {
        if(PHP_OS == "Linux") {
            if (!($os = shell_exec('/usr/bin/lsb_release -ds | cut -d= -f2 | tr -d \'"\''))) {
                if (!($os = shell_exec('cat /etc/system-release | cut -d= -f2 | tr -d \'"\''))) {
                    if (!($os = shell_exec('find /etc/*-release -type f -exec cat {} \; | grep NAME | tail -n 1 | cut -d= -f2 | tr -d \'"\''))) {
                        $os = 'N.A';
                    }
                }
            }
            $os = trim($os, '"');
            $os = str_replace("\n", '', $os);
        }
        elseif(PHP_OS == "FreeBSD")
        {
            $os = PHP_OS;
        }

        return $os;
    }

    public static function getActiveUsers()
    {
        if (($current_users = shell_exec('who | grep pts | awk \'{ print $1 $6 }\' | sort')))
        {
            $users = explode("\n", $current_users);
            $current_users = "";
            foreach($users as $user)
            {
                $user_ = explode("(",  $user);
                $ip_ = explode(")", $user_[1]);

                $current_users .= "<abbr title='IP:{$ip_[0]}'>{$user_[0]}</abbr>  &nbsp;";
            }
        }
        else
            $current_users = "&nbsp;";

        return $current_users;
    }

    public static function getLastUser()
    {
        $last_user = "N.A";
        if (($upt_tmp = shell_exec('last | awk \'NR==1 {print $1"("$3") " $5 " " $6 ", " $7}\'')))
        {
            $user_step1 = explode("(", $upt_tmp);
            $user_step2 = explode(")", $user_step1[1]);
            if($user_step1[0] !== "reboot")
                $last_user = "<abbr title='IP:{$user_step2[0]}'>{$user_step1[0]}{$user_step2[1]}</abbr>";
        }

        return $last_user;
    }

    public static function getDate()
    {
        if (!($server_date = shell_exec('/bin/date')))
            $server_date = date('Y-m-d H:i:s');

        return $server_date;
    }

    public function getSystemJSON()
    {
        $data = array(
            'uptime' => $this->getUptime(),
            'last'   => $this->getLastUser(),
            'active' => $this->getActiveUsers(),
        );

        return json_encode($data);
    }

    private $mem_total = 0;
    private $mem_used = 0;
    private $mem_free = 0;

    public function initialize_memory()
    {
        $this->updateMemoryFree();
        $this->updateMemoryTotal();
        $this->updateMemoryUsed();
    }

    public function updateMemoryFree()
    {
        if (shell_exec('cat /proc/meminfo'))
        {
            $free    = shell_exec('grep MemFree /proc/meminfo | awk \'{print $2}\'');
            $buffers = shell_exec('grep Buffers /proc/meminfo | awk \'{print $2}\'');
            $cached  = shell_exec('grep Cached /proc/meminfo | awk \'{print $2}\'');

            $this->mem_free = (int)$free + (int)$buffers + (int)$cached;
        }

        return $this->mem_free;
    }

    public function updateMemoryTotal()
    {
        if (!($this->mem_total = shell_exec('grep MemTotal /proc/meminfo | awk \'{print $2}\'')))
        {
            $this->mem_total = 0;
        }
        return $this->mem_total;
    }

    public function updateMemoryUsed()
    {
        return $this->mem_used = $this->mem_total - $this->mem_free;
    }


    public function getMemoryBSDJSON()
    {
        $page = shell_exec('/sbin/sysctl hw.pagesize');
        $page_ = explode(" ", $page);

        $physic_mem = shell_exec('/sbin/sysctl hw.physmem');
        $physic_ = explode(" ", $physic_mem);
        $mem_hw     = $physic_[1];

        $mem_inactive  = shell_exec('/sbin/sysctl vm.stats.vm.v_inactive_count');
        $mem_cache     = shell_exec('/sbin/sysctl vm.stats.vm.v_cache_count');
        $mem_free      = shell_exec('/sbin/sysctl vm.stats.vm.v_free_count');

        $inactive  = explode(" ", $mem_inactive);
        $cache     = explode(" ", $mem_cache);
        $free      = explode(" ", $mem_free);

        $mem_inactive  = $inactive[1] * $page_[1];
        $mem_cache     = $cache[1] * $page_[1];
        $mem_free      = $free[1] * $page_[1];

        $mem_total = round($mem_hw/1024/1024, 2);
        $mem_avail = round(($mem_inactive + $mem_cache + $mem_free)/1024/1024, 2);
        $mem_used  = round($mem_total - $mem_avail, 2);

        $data = array(
            'used'          => $mem_used,
            'free'          => $mem_avail,
            'total'         => $mem_total,
            'used_percent'  => 0,
            'free_percent'  => 0,
        );

        return json_encode($data);
    }

    public function getMemoryJSON()
    {
        $data = array(
            'used'          => Utility::getSize($this->mem_used * 1024),
            'free'          => Utility::getSize($this->mem_free * 1024),
            'total'         => Utility::getSize($this->mem_total * 1024),
            'used_percent'  => 0,
            'free_percent'  => 0,
        );

        return json_encode($data);
    }

    // CPU info
    private $model      = 'N.A';
    private $frequency  = 'N.A';
    private $cache      = 'N.A';
    private $bogomips   = 'N.A';

    public static function getCpuCoresNumber()
    {
		static $num_cores;
		
		if ( !isset($num_cores) ) 
		{
			if (!($num_cores = shell_exec('/bin/grep -c ^processor /proc/cpuinfo')))
			{
				if (!($num_cores = trim(shell_exec('/usr/bin/nproc'))))
				{
					$num_cores = 1;
				}
			}

			if ((int)$num_cores <= 0)
				$num_cores = 1;
		}

        return (int)$num_cores;
    }

    public function getProcessorJSON()
    {
        if ($cpuinfo = shell_exec('cat /proc/cpuinfo')) {
            $processors = preg_split('/\s?\n\s?\n/', trim($cpuinfo));

            foreach ($processors as $processor) {
                $details = preg_split('/\n/', $processor, -1, PREG_SPLIT_NO_EMPTY);
                foreach ($details as $detail) {
                    list($key, $value) = preg_split('/\s*:\s*/', trim($detail));

                    switch (strtolower($key)) {
                        case 'model name':
                        case 'cpu model':
                        case 'cpu':
                        case 'processor':
                            $this->model = $value;
                            break;

                        case 'cpu mhz':
                        case 'clock':
                            $this->frequency = $value . ' MHz';
                            break;

                        case 'cache size':
                        case 'l2 cache':
                            $this->cache = $value;
                            break;

                        case 'bogomips':
                            $this->bogomips = $value;
                            break;
                    }
                }
            }
        }

        $result = array(
            'name'      =>  $this->model,
            'frequency'  => $this->frequency,
            'cache'      => $this->cache,
            'bogomips'   => $this->bogomips,
        );

        return json_encode($result);
    }

	public function getProcessorLoadJSON()
    {
        $cpun = $this->getCpuCoresNumber();
        $load_avg = exec("/bin/cat /proc/loadavg | /usr/bin/awk '{print ($1*100)/{$cpun} \",\" ($2*100)/{$cpun} \",\"($3*100)/{$cpun}}'");
        $lavg = explode(",", $load_avg);
        return json_encode($lavg);
        //return json_encode(sys_getloadavg());
    }

    public function getDiskJSON($show_tmpfs = false)
    {
        $data = array();

        if (!(exec('/bin/df -T | awk -v c=`/bin/df -T | grep -bo "Type" | awk -F: \'{print $1}\'` \'{print substr($0,c);}\' | tail -n +2 | awk \'{print $1","$2","$3","$4","$5","$6}\'', $df)))
        {
            $data[] = array(
                'total'         => 'N.A',
                'used'          => 'N.A',
                'free'          => 'N.A',
                'percent_used'  => 0,
                'mount'         => 'N.A',
            );
        }
        else
        {
            $mounted_points = array();

            foreach ($df as $mounted)
            {
                list($type, $total, $used, $free, $percent, $mount) = explode(',', $mounted);

                if (strpos($type, 'tmpfs') !== false && $show_tmpfs === false)
                    continue;

                if (!in_array($mount, $mounted_points))
                {
                    $mounted_points[] = trim($mount);

                    $data[] = array(
                        'total'         => Utility::getSize($total * 1024),
                        'used'          => Utility::getSize($used * 1024),
                        'free'          => Utility::getSize($free * 1024),
                        'used_percent'  => trim($percent, '%'),
                        'mount'         => $mount,
                    );
                }
            }
        }

        return json_encode($data);
    }
}