<?php
/**
 * Created by PhpStorm.
 * User: nekkoy
 * Date: 03.07.2015
 * Time: 15:21
 */

ini_set('display_errors',1);
ini_set('error_reporting',2047);

class Utility
{
    // Отправка запросов на билинг
	public function sendRequest($url, $post = false, $cookie, $data = "")
	{		
		//echo "<br> URL:{$url} POST:{$post} COOKIE:{$cookie} DATA:{$data}";
		if( $curl = curl_init() ) {
			$host = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[SERVER_NAME]";
			curl_setopt($curl, CURLOPT_URL, $host . $url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			if($post)
            {
                curl_setopt($curl, CURLOPT_HEADER, true);
                curl_setopt($curl, CURLOPT_POST, true);
            }
			if($data)
				curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

            if($cookie !="no-cookie")
			    curl_setopt($curl, CURLOPT_COOKIE, "PHPSESSID=" . $cookie);

			$result = curl_exec($curl);
			curl_close($curl); 
		}
		//var_dump($result);
		return $result;
	}


    // Обрезка результата и конвертация в понимаемый для SimpleXML вид.
	public function cuteXML($data)
	{
		preg_match('/<users>(.*?)<\/resources>/', $data, $result);
		$xml = "<root Version='1.0'><users>{$result[1]}</resources></root>";
		$xml = new SimpleXMLElement($xml);
		//var_dump($xml);
		$result = array(
			'login'  => $xml->users->user->login,
			'active' => $xml->users->user->active,
			'res_3'	 => $xml->resources->res_3,
		);
		
		return $result;
	}

    // Перевод в человеческие системы исчисления
    public static function getSize($filesize, $precision = 2)
    {
        $units = array('', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y');

        foreach ($units as $idUnit => $unit) {
            if ($filesize > 1024)
                $filesize /= 1024;
            else
                break;
        }

        return round($filesize, $precision) . ' ' . $units[$idUnit] . 'B';
    }

    public static function pluralize($nb, $plural = 's', $singular = '')
    {
        return $nb > 1 ? $plural : $singular;
    }
}

class User
{
	private $_isLogined = false;
	private $_name = "null";
	private $_access = 0;
	private $_cookieAuth;
    private $_local = false;

    public function isLocal()
    {
        return $this->_local;
    }

    public function setLocal($local)
    {
        $this->_local = $local;
    }

	public function setLogined($var)
	{
		$this->_isLogined = $var;
	}
	
	public function isLogined()
	{
		return $this->_isLogined;
	}
	
	public function setName($var)
	{
		$this->_name = $var;
	}
	
	public function getName()
	{
		return $this->_name;
	}
	
	public function setAccess($var)
	{
		$this->_access = $var;
	}
	
	public function getAccess()
	{
		return $this->_access;
	}

    public function setCookie($name)
    {
        $this->_cookieAuth = $name;
        SetCookie("PHPSESSID", $name);
    }

    public function delCookie()
    {
        SetCookie("PHPSESSID", '');
    }

    public function parserCookie($input)
    {
        preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $input, $cookies);

        if (isset($cookies[1][0])) {
            $valueCookie = explode('=', $cookies[1][0]);

            return $valueCookie['1'];
        } else {
            return null;
        }
    }
}

abstract class Links
{
    const Auth    = '/ajax/index/authfl';
    const Access  = '/ajax/index/getstaffdatafl';
    const NasList = '/ajax/options/naslistfl';
    const swList  = '/ajax/users/switchlistflex';
}