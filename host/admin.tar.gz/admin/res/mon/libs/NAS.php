<?php
/**
 * Created by PhpStorm.
 * User: nekkoy
 * Date: 04.07.2015
 * Time: 14:39
 */

class NAS
{
    private function do_ping($ip)
    {
        exec("/bin/ping -qc 1 -w 3 {$ip} | awk -F/ '/^rtt/ { print $5 }'", $result);
        return $result;
    }

    public function getNasList()
    {
        $send = new Utility;
        $response = $send->sendRequest(Links::NasList, false, $_SESSION["cookie"], "");
        $data = array();

        if($response != null)
        {
            $xml = new SimpleXMLElement($response);

            foreach($xml->nas as $nas)
            {

                $data[] = array(
                    'nasid' => $nas["id"],
                    'nasip' => $nas["nasname"],
                    'name'	=> $nas["shortname"],
                );

                unset($nas);
            }
        }
        else
        {
            $data = array (
                'nasid' => '0',
                'nasip' => "null",
                'name'	=> "error",
            );
        }
        unset($send);
        return json_encode($data);
    }

    public function getJSON()
    {

        //Получаем список NASов
        $send = new Utility;
        $response = $send->sendRequest(Links::NasList, false, $_SESSION["cookie"], "");
        $data = array();

        if($response != null)
        {
            $xml = new SimpleXMLElement($response);

            foreach($xml->nas as $nas)
            {
                //var_dump($nas);
                $ping = $this->do_ping($nas["nasname"]);

                if ($ping === null)
                {
                    $ping = 0;
                }

                $data[] = array(
                    'nasip' => $nas["nasname"],
                    'name'	=> $nas["shortname"],
                    'ping' => $ping,
                );

                unset($nas);
            }
        }
        else
        {
            $data = array (
                'nasip' => "null",
                'name'	=> "error",
                'ping' => 0,
            );
        }
        unset($send);
        return json_encode($data);
    }

}