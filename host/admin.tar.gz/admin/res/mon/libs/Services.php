<?php
/**
 * Created by PhpStorm.
 * User: nekkoy
 * Date: 04.07.2015
 * Time: 14:09
 */

class Services
{
    public function getOne()
    {
        return 1;
    }

    public function getJSON($Config = array())
    {
        $data = array();

        if (count($Config['services']) > 0)
        {
            foreach ($Config['services'] as $service)
            {
                if(isset($_POST["cmd"]) && isset($_POST["prog"]) && $service['daemon_name'] == $_POST["prog"])
                {
                    $success = 0;

                    switch($_POST["cmd"])
                    {
                        case "stop": {
                            if(PHP_OS == "FreeBSD")
                            {
                                exec("{$Config['general']['sudo']} /etc/rc.d/{$service['daemon_name']} stop &>/dev/null 2>&1");
                                sleep(2);
                                $pid = exec("pgrep -n {$service['daemon_name']}"); //NEW
                            }
                            else
                            {
                                exec("{$Config['general']['sudo']} /etc/init.d/{$service['daemon_name']} stop &>/dev/null 2>&1");
                                sleep(2);
                                $pid = exec("pgrep -n {$service['daemon_name']}"); //NEW
                            }

                            if( $pid == "" && $pid != "Exit 1") //NEW
                                $success = 1;

                            //var_dump($pid);

                            break;
                        }
                        case "start": {

                            if(PHP_OS == "FreeBSD")
                            {
                                exec("{$Config['general']['sudo']} /etc/rc.d/{$service['daemon_name']} start &>/dev/null 2>&1");
                                sleep(2);
                                $pid = exec("pgrep -n {$service['daemon_name']}"); //NEW
                            }
                            else
                            {
                                exec("{$Config['general']['sudo']} /etc/init.d/{$service['daemon_name']} start &>/dev/null 2>&1");
                                sleep(2);
                                $pid = exec("pgrep -n {$service['daemon_name']}"); //NEW
                            }
 
                            if( $pid != "" && $pid != "Exit 1") //NEW
                                $success = 1;

                            //var_dump($pid);

                            break;
                        }
                        case "restart": {
                            if(PHP_OS == "FreeBSD")
                            {
                                $pid1 = exec("pgrep -n {$service['daemon_name']}"); //NEW
                                exec("{$Config['general']['sudo']} /etc/rc.d/{$service['daemon_name']} restart &>/dev/null 2>&1");
                                sleep(2);
                                $pid2 = exec("pgrep -n {$service['daemon_name']}"); //NEW
                            }
                            else
                            {
                                $pid1 = exec("pgrep -n {$service['daemon_name']}"); //NEW
                                exec("{$Config['general']['sudo']} /etc/init.d/{$service['daemon_name']} restart &>/dev/null 2>&1");
                                sleep(2);
                                $pid2 = exec("pgrep -n {$service['daemon_name']}"); //NEW
                            }

							// pid1[0] != $pid2[0]  означает что номер процеса изменился
							// $pid2[0] != ""       означает что процесс не упал после ребута
                            if($pid1 != $pid2 && $pid2 != "" && $pid2 != "Exit 1") //NEW
                                $success = 1;

                            //var_dump($pid1);
                            //var_dump($pid2);

                            break;
                        }
                        default: break;
                    }
                    return $success;
                }

                if($service['enabled'])
                {
                    $daemon = $service['daemon_name'];

					$status = exec("pgrep -n {$daemon}"); //NEW
					if ($status != "" && $status != "Exit 1") //NEW
					{
						$data[] = array(
							'desc'      => $service['description'],
							'name'      => $service['name'],
							'dname'		=> $service['daemon_name'],
							'status'    => 1,
						);
					}
					else
					{
						$data[] = array(
							'desc'      => $service['description'],
							'name'      => $service['name'],
							'dname'		=> $service['daemon_name'],
							'status'    => 0,
						);
					}

                    unset($daemon);
                }
            }
        }

        return json_encode($data);
    }


}