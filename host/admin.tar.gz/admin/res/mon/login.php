<!DOCTYPE html>
<html lang="ru-en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $Config["general"]["isp_name"]; ?></title>
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Mikbill monitor -->
    <link href="css/mms.css" rel="stylesheet">

</head>
<body>

<div class="row">
	<div class="span5">
		<div class="auth block-style span3">
			<h6> Войдите под учеткой билинга.</h6>
			<form id="auth" class="form-horizontal" action="index.php" method="post">
                  <input type="hidden" name="request" value="auth" form="auth">
			  <div class="control-group">
				  <input type="text" name="login" id="login" placeholder="Логин" form="auth">
			  </div>
			  <div class="control-group">
				  <input type="password" name="password" id="password" placeholder="Пароль" form="auth">
			  </div>
			  <div class="control-group">
				  <button type="submit" class="btn float-right" form="auth">Войти</button>
			  </div>
			</form> 
		</div>
	</div>
</div>

<div id="footer"></div>
</body>
</html>
