<?php
session_start();

ini_set('display_errors',1);
ini_set('error_reporting',2047);

include_once "libs/Utility.php";
include_once "libs/Server.php";
include_once "libs/Services.php";
include_once "libs/NAS.php";
include_once "libs/Switch.php";
include_once "Config.php";
include_once "Demo.php";
/***

***/
$user = new User;
$util = new Utility;
$server = new Server;

function randomFloat($min = 0, $max = 1) {
    return $min + mt_rand() / mt_getrandmax() * ($max - $min);
}

if($Config["general"]["demo"])
{
    if(isset($_POST["request"]) && $_POST["request"] == "auth" && !$_SESSION["logged"])
    {
        foreach ($DemoData["users"] as $user_)
        {
            if ($user_["login"] == $_POST['login'] && $user_["passwd"] == $_POST['password'] && $user_["enabled"] == true)
            {
                echo "<!-- local auth -->";
                $_SESSION["local"] = true;
                $_SESSION["logged"] = true;
                $_SESSION["access"] = $user_["access"];
                break;
            }
        }
    }

    if($_SESSION["logged"] == true)
    {
        $user->setLogined($_SESSION["logged"]);
        $user->setAccess($_SESSION["access"]);
        $user->setLocal($_SESSION["local"]);
        $_SESSION["demo"] = true;
    }

    if($_SESSION["logged"])
    {
        if(isset($_POST["request"]) && $_POST["request"] != "auth")
        {
            switch($_POST["request"])
            {
                case "system": {
                    $data = array(
                        'uptime' => $DemoData['Uptime'],
                        'last'   => $DemoData['LastUser'],
                        'active' => $DemoData['ActiveUsers'],
                    );
                    echo json_encode($data);
                    break;
                }
                case "memory": {
                    $rand_ = rand(-50, 100);

                    $total = $DemoData["RAM_total"];
                    $used = $DemoData["RAM_used"]+$rand_;
                    $free = $total - $used;
                    $data = array(
                        'used'          => $used . " MB",
                        'free'          => $free . " MB",
                        'total'         => $total . " MB",
                        'used_percent'  => 0,
                        'free_percent'  => 0,
                    );
                    echo json_encode($data);
                    break;
                }
                case "disk": {
                    $data[] = array(
                        'total'         => $DemoData["DiskTotal"] . " GB",
                        'used'          => $DemoData["DiskUse"] . " GB",
                        'free'          => $DemoData["DiskTotal"]-$DemoData["DiskUse"] . " GB",
                        'used_percent'  => round($DemoData["DiskUse"] / ($DemoData["DiskTotal"] / 100))  . "",
                        'mount'         => '/',
                    );
                    echo json_encode($data);
                    break;
                }
                case "cpu_load": {
                    echo json_encode(array("0.0".rand(0, 9), "0.0".rand(0, 7), "0.0".rand(0, 3)));
                    break;
                }
                case "services": {

                    if (!isset($_SESSION["services"]))
                    {
                        $_SESSION["services"] = $DemoData['Services'];
                    }

                    foreach ($_SESSION["services"] as $service)
                    {
                        if(isset($_POST["cmd"]) && isset($_POST["prog"]) && $service['dname'] == $_POST["prog"])
                        {
                            $success = 1;
                            switch($_POST["cmd"])
                            {
                                case "stop": {
                                    $_SESSION["services"][$service['dname']]['status'] = 0;
                                    break;
                                }
                                case "start": {
                                    $_SESSION["services"][$service['dname']]['status'] = 1;
                                    break;
                                }
                                case "restart": {
                                    $_SESSION["services"][$service['dname']]['status'] = 1;
                                    break;
                                }
                                default: break;
                            }

                            echo $success;
                            exit();
                        }

                        $data[] = array(
                            'desc'      => $_SESSION["services"][$service['dname']]['desc'],
                            'name'      => $_SESSION["services"][$service['dname']]['name'],
                            'dname'		=> $_SESSION["services"][$service['dname']]['dname'],
                            'status'    => $_SESSION["services"][$service['dname']]['status'],
                        );

                    }
                   // echo "<!-- " . var_dump($_SESSION["services"]) . "-->";
                    echo json_encode($data);
                    break;
                }
                case "nas": {
                    $data = array();
                    $nas_id = 0;
                    foreach ($DemoData["NAS"] as $nas) {

                        $data[] = array (
                            'nasid' =>  array($nas_id++),
                            'nasip' => array($nas["ip"]),
                            'name'	=> array($nas["name"]),
                        );
                    }
                    echo json_encode($data);
                    break;
                }
                case "switch": {
                    $data = array();
                    $sw_id = 0;
                    foreach ($DemoData["Switches"] as $sw) {

                        $data[] = array (
                            'switch_id'   => array($sw_id++),
                            'switch_ip'   => array($sw["ip"]),
                            'switch_name' => array($sw["name"]),
                        );
                    }
                    echo json_encode($data);
                    break;
                }
                case "ping_switch": {
                    if(isset($_POST["ip"]))
                    {
                        if(rand(0, 9) <= 3)
                            echo json_encode(array('ping' => 0));
                        else
                            echo json_encode(array('ping' => round(randomFloat(0, 50), 2)));
                    }
                    break;
                }
                case "get_ping": {

                    if($_POST["type"]=="sw")
                    {
                        if(rand(0, 9) <= 3)
                            $text = array("id"=>$_POST["sid"],"ping"=>0,"date"=>date("2015-07-".rand(1, 19)." 00:00:00"));
                        else
                            $text = array("id"=>$_POST["sid"],"ping"=>round(randomFloat(0,50), 2),"date"=>date("Y-m-d H:i:s"));
                    }
                    elseif($_POST["type"]=="nas")
                    {
                        if(rand(0, 9) <= 3)
                            $text = array("id"=>$_POST["sid"],"ping"=>0,"date"=>date("2015-07-".rand(1, 19)." 00:00:00"));
                        else
                            $text = array("id"=>$_POST["sid"],"ping"=>round(randomFloat(0,50), 2),"date"=>date("Y-m-d H:i:s"));
                    }
                    echo json_encode($text);
                    break;
                }
                case "test": { echo json_encode(array('test' => 'tested!')); break; }
                default:    echo "wrong request";
            }
        }
        else
        {
            echo "<!-- Страница мониторинга. user access={$user->getAccess()}-->";
            include "monitor.php";
        }
    }
    else
    {
        include "login.php";
    }

    exit();
}











if(isset($_POST["request"]) && $_POST["request"] == "auth" && !$_SESSION["logged"])
{
    switch($_POST["request"])
    {
        case "auth":
        {
            $data = "login={$_POST['login']}&password={$_POST['password']}";
            $result = $util->sendRequest(Links::Auth, true, "no-cookie", $data); // Логинемся в билинг
            $cookie = $user->parserCookie($result);

            preg_match_all('/<user><enable>([0-9])<\/enable>/', $result, $cookies);
            //echo "<br> Прошел авторизацию ?:" . $cookies[1][0];
            if($cookies[1][0] != "0" && $cookies[1][0] != "")  // Если реультат пустой, пользователь ввел не правильные данные.
            {
                //session_regenerate_id();
                $_SESSION["cookie"] = $cookie;

                $result = $util->sendRequest(Links::Access, false, $cookie, "");
                //var_dump($cookie);
                //var_dump($result);
                if($result != null)  // Если реультат пустой, пользователь ввел не правильные данные.
                {
                    $data = $util->cuteXML($result);
                    //var_dump($data);
                    // Активен ли пользователь
                    if ($data["active"]) {
                        // Имеет ли права на перезапуск
                        if ($data["res_3"])
                            $_SESSION["access"] = 3;
                        else
                            $_SESSION["access"] = 0;

                        $_SESSION["logged"] = true;
                    }

                }
                else
                {
                    $_SESSION["logged"] = false;
                }
                $_SESSION["local"] = false;
            }
            else
            {
                foreach ($Config["users"] as $user_) {
                    if ($user_["login"] == $_POST['login'] && $user_["passwd"] == $_POST['password'] && $user_["enabled"] == true)
                    {
						echo "<!-- local auth -->";
                        $_SESSION["local"] = true;
                        $_SESSION["logged"] = true;
                        $_SESSION["access"] = $user_["access"];
                        break;
                    }
                }
            }
            break;
        }
        default:
            echo "error";
            exit();
    }
}

if($_SESSION["logged"] == true)
{
    $user->setLogined($_SESSION["logged"]);
    $user->setAccess($_SESSION["access"]);
    $user->setLocal($_SESSION["local"]);
}

if($user->isLogined())
{
    if(isset($_POST["request"]) && $_POST["request"] != "auth")
    {
        switch($_POST["request"])
        {

            case "system": {
                echo $server->getSystemJSON();
                unset($server);
                break;
            }
            case "memory": {
                if(PHP_OS == "FreeBSD")
                {
                    echo $server->getMemoryBSDJSON();
                    unset($server);
                }
                else
                {
                    $server->initialize_memory();
                    echo $server->getMemoryJSON();
                    unset($server);
                }
                break;
            }
            case "disk": {
                echo $server->getDiskJSON($Config["disk"]["show_tmpfs"]);
                unset($server);
                break;
            }
            case "cpu_load": {
                echo $server->getProcessorLoadJSON();
                unset($server);
                break;
            }
            case "services": {
                $service = new Services;
                echo $service->getJSON($Config);
                unset($service);
                break;
            }
            case "nas": {
                    $nas = new NAS;
                    echo $nas->getNasList();
                    unset($nas);
                break;
            }
            case "switch": {
                    $switch = new Switches;
                    echo $switch->getJSON();
                    unset($switch);
                break;
            }
            case "ping_switch": {
                if(isset($_POST["ip"]))
                {
                    $switch = new Switches;
                    echo $switch->do_ping($_POST["ip"]);
                    unset($switch);
                }
                break;
            }
            case "get_ping": {

                if($_POST["type"]=="sw")
                {
                    $text = file_get_contents("DS/store/sw/sw_data_{$_POST["sid"]}.json","r");
                    $text = trim($text, " \".");
                    echo $text;
                }
                elseif($_POST["type"]=="nas")
                {
                    $text = file_get_contents("DS/store/nas/nas_data_{$_POST["sid"]}.json","r");
                    $text = trim($text, " \".");
                    echo $text;
                }
                break;
            }
            case "test": { echo json_encode(array('test' => 'tested!')); break; }
            default:    echo "wrong request";
        }
    }
    else
    {
        echo "<!-- Страница мониторинга. user access={$user->getAccess()}-->";
        include "monitor.php";
    }
}
else
{
	echo "<!-- Страница авторизации. Main -->";
	include "login.php";
}

unset($server);
unset($util);
unset($user);