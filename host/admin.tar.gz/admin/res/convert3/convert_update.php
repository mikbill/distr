<?php

define ("OLD_PAKETS","dd_pacets");
define ("OLD_USERS","m_Users");
define ("OLD_PASS","radcheck");
define ("OLD_CITY","dd_city");
define ("OLD_LANE","dd_street");

define ("OLD_USERS_MIGRATE","migrate");

define ("BILL_AUTH_TABLE","users");
define ("BILL_NAS_TABLE", "radnas" );
define ("BILL_NASLOG_TABLE", "radnaslog" );
define ("BILL_SYSPOTS_TABLE", "sysopts" );
define ("BILL_PACKET_TABLE", "packets" );
define ("BILL_MIGRATE_TABLE", "migratenodeny" );
define ("BILL_SECTORS_TABLE", "sectors" );
define ("BILL_LANES_TABLE", "lanes" );
define ("BILL_HOUSES_TABLE", "lanes_houses" );


$config_file='../../app/etc/config.xml';

if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_LOG  = (string) $xml->parameters->kernel->log;
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;

} else {
	die("config not found");
}

function open_logs($CONF_LOG)
{
	return 	fopen($CONF_LOG, "a");
}

$stdlog = open_logs($CONF_LOG);


function do_log($stdlog,$text_log)
{
	fputs($stdlog, get_date()." ".$text_log."\n");
}

function do_log_sql($stdlog,$text_log,&$LINK)
{
	if (!mysql_ping($GLOBALS["LINK"]))
	{
		$do_mysql_reconect=1;
		fputs($stdlog, get_date()." MySQL Connect failed"."\n");
	}else{
		fputs($stdlog, get_date()." ".$text_log."\n");
	}

	while ($do_mysql_reconect==1)
	{
		$config_file='../../app/etc/config.xml';

		if (file_exists($config_file)) {
			$xml = simplexml_load_file($config_file);
			$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
			$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
			$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
			$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
		}
		$GLOBALS["LINK"] = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
		mysql_select_db ( $CONF_MYSQL_DBNAME , $GLOBALS["LINK"] );

		if (mysql_ping($GLOBALS["LINK"])){
			$do_mysql_reconect=0;
			fputs($stdlog, get_date()." MySQL Connect restored"."\n");
		}


	}
	return "1";
}


function get_date()
{
	return date ( 'd.m.Y H:i:s' );
}

function init_nas($LINK,$stdlog)
{

	$result = mysql_query ( "SELECT * FROM " . BILL_NAS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#2 ".mysql_error ( $LINK ),$LINK );

	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$nases[$i]=$res;
	}

	mysql_free_result ( $result );

	return $nases;
}

function init_sysopts($LINK,$stdlog)
{
	$result = mysql_query ( "SELECT * FROM " . BILL_SYSPOTS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#6 ".mysql_error ( $LINK ),$LINK );
	$res = mysql_fetch_array ( $result );
	mysql_free_result ( $result );

	return $res;
}



function billing_init_users_migrate($LINK,$stdlog)
#�������� ������ �� ����������
{
	$packets = array();
	$query =  "SELECT * FROM " . OLD_USERS_MIGRATE . " WHERE 1 ";

	$result = mysql_query ($query, $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$packets[$i]=$res;
	}
	mysql_free_result($result);
	return $packets;
}


function update_user($LINK,$stdlog,$value)
{
	mysql_query ( "UPDATE " . BILL_AUTH_TABLE . " SET gid='".$value['gid']."',	deposit='".$value['summa']."' WHERE uid='".$value['login']."'", $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
}

global $LINK;

$LINK = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
if (!$LINK) {
	do_log($stdlog,"Cant connect to DB ".$CONF_MYSQL_HOST);
	exit();
}

mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK ) or die('Could not select database.');
mysql_query("SET NAMES koi8r", $LINK );
mysql_query("SET CHARSET koi8r", $LINK );


$users_old_list=billing_init_users_migrate($LINK,$stdlog);

foreach ($users_old_list as $key=>$value)
{

	update_user($LINK,$stdlog,$value);
}

mysql_close($LINK);




