<?php

$OLD_LOGIN="login";
$OLD_PASS="pass";
$OLD_HOST="ip";
$OLD_DB="db";

define ("OLD_PAKETS","dd_pacets");
define ("OLD_USERS","m_Users");
define ("OLD_PASS","radcheck");
define ("OLD_CITY","dd_city");
define ("OLD_LANE","dd_street");

define ("BILL_AUTH_TABLE","users");
define ("BILL_NAS_TABLE", "radnas" );
define ("BILL_NASLOG_TABLE", "radnaslog" );
define ("BILL_SYSPOTS_TABLE", "sysopts" );
define ("BILL_PACKET_TABLE", "packets" );
define ("BILL_MIGRATE_TABLE", "migratenodeny" );
define ("BILL_SECTORS_TABLE", "sectors" );
define ("BILL_LANES_TABLE", "lanes" );
define ("BILL_HOUSES_TABLE", "lanes_houses" );


$config_file='../../app/etc/config.xml';

if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_LOG  = (string) $xml->parameters->kernel->log;
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;

} else {
	die("config not found");
}

function open_logs($CONF_LOG)
{
	return 	fopen($CONF_LOG, "a");
}

$stdlog = open_logs($CONF_LOG);


function do_log($stdlog,$text_log)
{
	fputs($stdlog, get_date()." ".$text_log."\n");
}

function do_log_sql($stdlog,$text_log,&$LINK)
{
	if (!mysql_ping($GLOBALS["LINK"]))
	{
		$do_mysql_reconect=1;
		fputs($stdlog, get_date()." MySQL Connect failed"."\n");
	}else{
		fputs($stdlog, get_date()." ".$text_log."\n");
	}

	while ($do_mysql_reconect==1)
	{
		$config_file='../../app/etc/config.xml';

		if (file_exists($config_file)) {
			$xml = simplexml_load_file($config_file);
			$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
			$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
			$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
			$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
		}
		$GLOBALS["LINK"] = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
		mysql_select_db ( $CONF_MYSQL_DBNAME , $GLOBALS["LINK"] );

		if (mysql_ping($GLOBALS["LINK"])){
			$do_mysql_reconect=0;
			fputs($stdlog, get_date()." MySQL Connect restored"."\n");
		}


	}
	return "1";
}


function get_date()
{
	return date ( 'd.m.Y H:i:s' );
}

function init_nas($LINK,$stdlog)
{

	$result = mysql_query ( "SELECT * FROM " . BILL_NAS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#2 ".mysql_error ( $LINK ),$LINK );

	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$nases[$i]=$res;
	}

	mysql_free_result ( $result );

	return $nases;
}

function init_sysopts($LINK,$stdlog)
{
	$result = mysql_query ( "SELECT * FROM " . BILL_SYSPOTS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#6 ".mysql_error ( $LINK ),$LINK );
	$res = mysql_fetch_array ( $result );
	mysql_free_result ( $result );

	return $res;
}

function billing_init_lanes($LINK,$LINK2,$stdlog)
#�������� ���� � �����
{
	$lanes = array();

	mysql_query ( "delete FROM " . BILL_LANES_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );

	$lanes = array();
	$querry="SELECT * FROM " . OLD_LANE . " WHERE 1 ";

	$result = mysql_query ($querry , $LINK2 ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$lanes[$res["id"]]=$res;
	}
	mysql_free_result($result);

	foreach ( $lanes as $key=>$value)
	{
		$querry="INSERT INTO ".BILL_LANES_TABLE." ( `laneid` , `lane` ) VALUES ('".$value['id']."', '".$value['name']."');";
		mysql_query ($querry , $LINK );
	}

	$house=array();
	mysql_query ( "delete FROM " . BILL_HOUSES_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	
	$querry="SELECT DISTINCT (`dd_Street`), `House` FROM ".OLD_USERS." WHERE House != ''";

	$result = mysql_query ($querry , $LINK2 ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$house[$i]=$res;
	}


	foreach ($house as $key => $value)
	{
		$querry="INSERT INTO " . BILL_HOUSES_TABLE . " (`houseid` ,`laneid` ,`house`) VALUES ( NULL , '".$value['dd_Street']."', '".$value['House']."' );";

		mysql_query ($querry , $LINK );
	}

}

function get_houseid_by_laneid_HOUSE($LINK,$laneid,$HOUSE){
	
	$querry="SELECT houseid FROM ".BILL_HOUSES_TABLE." WHERE laneid=".$laneid." AND house ='".$HOUSE."'";
	
	$result = mysql_query ($querry , $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	$res = mysql_fetch_array($result);
	mysql_free_result($result);
	return $res['houseid'];
}

function billing_init_sectors($LINK,$LINK2,$stdlog)
#�������� ��������
{

	mysql_query ( "delete FROM " . BILL_SECTORS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );

	$city = array();
	$querry="SELECT * FROM " . OLD_CITY . " WHERE 1 ";

	$result = mysql_query ($querry , $LINK2 ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$city[$res["id"]]=$res;
	}
	mysql_free_result($result);

	foreach ( $city as $key=>$value)
	{
		$querry="INSERT INTO ".BILL_SECTORS_TABLE." ( `sectorid` , `sector` , `iface` ,`dhcp_ranges` ) VALUES ('".$value['id']."', '".$value['name']."', '".$value['id']."','');";
		mysql_query ($querry , $LINK );
	}

}


function billing_delete_packets($LINK,$stdlog)
#�������� ���� �������
{
	mysql_query ( "delete FROM " . BILL_PACKET_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );

}
function billing_delete_all_users($LINK,$stdlog)
#�������� ���� �������������
{

	mysql_query ( "delete FROM " . BILL_AUTH_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );

}

function billing_insert_user($LINK,$stdlog,$value)
#������� ������
{
	$uid=$value['id_Users'];
	
	$user=$value['Username'];
	$pass=$value['Password'];
	$deposit='0';
	$gid=$value['id_pacets'];
	$phone=$value['Telephone'];

	$address=$value['name']." ".$value['House']."/".$value['Flet'];
	$sectorid=$value['sectorid'];
	$user_real='0';
	$local_mac=$value['MAC'];
	$fio=$value['SeName']." ".$value['Name']." ".$value['PB'];
	
	$laneid=$value['dd_Street'];
	$houseid=get_houseid_by_laneid_HOUSE($LINK,$laneid,$value['House']);
	$app=$value['Flet'];

	$prim='';
	$email=$value['Email'];
	$add_date=$value['DataDobavl'];

	$numdogovor=$value['ndogovoru'];

	if ($numdogovor!=''){
		$dogovor='1';
	}else{
		$dogovor='0';
	}

	$inn='';
	$mob_tel=$value['mobilephone'];
	$sms_tel=$value['mobilephone'];

	$date_abonka='1';
	$querry="INSERT INTO " . BILL_AUTH_TABLE . "  (`uid`,`user`, `password`,`gid`, `deposit`,`phone`,`address`,`sectorid`,`local_mac`,`real_ip`,`fio`,`prim`,`email`,`add_date`,`inn`,`mob_tel`,`sms_tel`,`date_abonka`,`numdogovor`,`app`,`dogovor`,`houseid`) VALUES ('".$uid."','".$user."','".$pass."',".$gid.",".$deposit.",'".$phone."','".$address."',".$sectorid.",'".$local_mac."',".$user_real.",'".$fio."','".$prim."','".$email."','".$add_date."','".$inn."','".$mob_tel."','".$sms_tel."',".$date_abonka.",'".$numdogovor."','".$app."','".$dogovor."','".$houseid."'); ";

	#		var_dump($querry);

	mysql_query ($querry , $LINK ) or do_log_sql($stdlog,"#user ".mysql_error($LINK),$child );

}

function billing_insert_packet($LINK,$stdlog,$value)
#������� ������
{
	$gid=$value['id'];
	$packet=iconv("CP1251","KOI8-U",$value['name']);
	$packet=$value['name'];
	$speed_rate=$value['baza_client'];
	$speed_burst=$value['client_baza'];
	$fixed_cost=round($value['suma'],2);
	$querry="INSERT INTO " . BILL_PACKET_TABLE . "  (`packet`, `gid`,`fixed`, `fixed_cost`,`speed_rate`,`speed_burst`,`do_shapers`,`do_mik_rad_shapers`,`use_change_pass`,`use_change_data`) VALUES ('".$packet."',".$gid.",8,".$fixed_cost.",".$speed_rate.",".$speed_burst.",1,1,1,1); ";

	#		var_dump($querry);

	mysql_query ($querry , $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );

}

function billing_init_packets($LINK,$stdlog)
{
	$packets = array();
	$result = mysql_query ( "SELECT * FROM " . BILL_PACKET_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$packets[$res["gid"]]=$res;
	}
	mysql_free_result($result);
	return $packets;
}

function billing_init_packets_old($LINK2,$stdlog)
#�������� ������ ������ �������
{
	$packets = array();
	$querry="SELECT * FROM " . OLD_PAKETS . " WHERE 1 ";

	$result = mysql_query ($querry , $LINK2 ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$packets[$res["id"]]=$res;
	}
	mysql_free_result($result);
	return $packets;
}

function billing_init_users_old($LINK2,$stdlog)
#�������� ������ ������ �������������
{
	$packets = array();
	#		$query =  "SELECT * FROM " . OLD_USERS . " WHERE 1 ";

	$query = "SELECT `m_pacets`.id_Users,Username,Password,
`m_Users`.Name,SeName,PB,Email,Telephone,mobilephone,IP,MAC,
dd_Street,`dd_street`.name,House,Flet,dd_city as sectorid ,DataDobavl,txt,ndogovoru,id_pacets,d_begin,d_end,suma,PovnaSuma,
oplacheno,stamp
FROM `m_pacets`,`m_Users`,`dd_street`
WHERE `m_pacets`.id_Users=`m_Users`.IdUser and `m_pacets`.id_pacets!=90 and `dd_street`.id=`m_Users`.dd_Street
GROUP BY `m_pacets`.id_Users
ORDER BY `m_pacets`.`d_end` DESC";

	#		$query = "SELECT * FROM ".OLD_USERS." U , ".OLD_PASS." P WHERE U.username=P.UserName and attribute='Cleartext-Password';";
	$result = mysql_query ($query, $LINK2 ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$packets[$i]=$res;
	}
	mysql_free_result($result);
	return $packets;
}

function get_users_by_gid($LINK,$stdlog,$gid )
{
	$result = mysql_query ( "SELECT * FROM " . BILL_AUTH_TABLE . " WHERE gid=".$gid." ", $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
	$res = mysql_fetch_array ( $result );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$users[$res["uid"]]=$res;
	}

	mysql_free_result ( $result );

	return $users;
}
function get_all_users($LINK,$stdlog)
{
	$result = mysql_query ( "SELECT * FROM " . BILL_AUTH_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$users[$res["uid"]]=$res;
	}

	mysql_free_result ( $result );

	return $users;
}

function update_user($LINK,$stdlog,$uid,$framed_ip)
{
	mysql_query ( "UPDATE " . BILL_AUTH_TABLE . " SET framed_ip='".$framed_ip."' WHERE uid=".$uid, $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
}

global $LINK;

$LINK = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
if (!$LINK) {
	do_log($stdlog,"Cant connect to DB ".$CONF_MYSQL_HOST);
	exit();
}

mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK ) or die('Could not select database.');
mysql_query("SET NAMES koi8r", $LINK );
mysql_query("SET CHARSET koi8r", $LINK );

global $LINK2;

$LINK2 = mysql_connect ( $OLD_HOST ,  $OLD_LOGIN, $OLD_PASS );
if (!$LINK2) {
	do_log($stdlog,"Cant connect to DB2 ".$OLD_HOST);
	exit();
}

mysql_query("SET NAMES koi8u", $LINK2 );
mysql_query("SET CHARSET koi8u", $LINK2 );
mysql_select_db ( $OLD_DB , $LINK2 ) or die('Could not select database2.');

/*
$users_list=get_all_users($LINK,$stdlog);
foreach ($users_list as $key2=>$value2)
{
if ($value2['framed_ip']!=''){
$ip=explode(".",trim($value2['framed_ip']));
$ip2=explode(".",trim($value2['local_ip']));
$ip_itog=$ip[0].".31.".$ip2[2].".".$ip[3];
echo $ip_itog."\n";
update_user($LINK,$stdlog,$value2['uid'],$ip_itog);
}
}
*/

#������ �������

billing_delete_all_users($LINK,$stdlog);

#�������� �������
#billing_delete_packets($LINK,$stdlog);

#billing_init_sectors($LINK,$LINK2,$stdlog);

#billing_init_lanes($LINK,$LINK2,$stdlog);

$packets_old=billing_init_packets_old($LINK2,$stdlog);

foreach ($packets_old as $key=>$value)
{
#	billing_insert_packet($LINK,$stdlog,$value);
	#		var_dump($value['id']);
	#		var_dump($value['name']);
	#		var_dump($value['baza_client']);
	#		var_dump($value['client_baza']);
	#		var_dump($value);
}


$users_old_list=billing_init_users_old($LINK2,$stdlog);

foreach ($users_old_list as $key=>$value)
{

	#		var_dump($value['expiration']);
	#		$var1=explode(" ", $value['expiration']);
	#		$var2=explode("-", $var1[0]);

	#		$value['date_abonka']=$var2[2];

	#		if (is_numeric($value['date_abonka'])){
	#			billing_insert_user($LINK,$stdlog,$value);
	#		}else{
	#			$value['date_abonka']='1';
#	var_dump($value);
#	die();
	billing_insert_user($LINK,$stdlog,$value);
	#		}

}


var_dump(count($users_old_list));


mysql_close($LINK);
mysql_close($LINK2);



