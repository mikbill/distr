/**
 * INSPINIA - Responsive Admin Theme
 *
 * Main controller.js file
 * Define controllers with data used in Inspinia theme
 *
 *
 * Functions (controllers)
 *  - MainCtrl
 *  - dashboardFlotOne
 *  - dashboardFlotTwo
 *  - dashboardFlotFive
 *  - dashboardMap
 *  - flotChartCtrl
 *  - rickshawChartCtrl
 *  - sparklineChartCtrl
 *  - widgetFlotChart
 *  - modalDemoCtrl
 *  - ionSlider
 *  - wizardCtrl
 *  - CalendarCtrl
 *  - chartJsCtrl
 *  - GoogleMaps
 *  - ngGridCtrl
 *  - codeEditorCtrl
 *  - nestableCtrl
 *  - notifyCtrl
 *  - translateCtrl
 *  - imageCrop
 *  - diff
 *  - idleTimer
 *  - liveFavicon
 *  - formValidation
 *  - agileBoard
 *  - draggablePanels
 *  - chartistCtrl
 *  - metricsCtrl
 *  - sweetAlertCtrl
 *  - selectCtrl
 *  - toastrCtrl
 *
 *
 */

/**
 * MainCtrl - controller
 * Contains severals global data used in diferent view
 *
 */
function MainCtrl() {

    /**
     * daterange - Used as initial model for data range picker in Advanced form view
     */
    this.daterange = {startDate: null, endDate: null}

    /**
     * slideInterval - Interval for bootstrap Carousel, in milliseconds:
     */
    this.slideInterval = 5000;

    /**
     * addAlert, closeAlert  - used to manage alerts in Notifications and Tooltips view
     */
    this.addAlert = function() {
        this.alerts.push({msg: 'Another alert!'});
    };

    this.closeAlert = function(index) {
        this.alerts.splice(index, 1);
    };

    /**
     * randomStacked - used for progress bar (stacked type) in Badges adn Labels view
     */
    this.randomStacked = function() {
        this.stacked = [];
        var types = ['success', 'info', 'warning', 'danger'];

        for (var i = 0, n = Math.floor((Math.random() * 4) + 1); i < n; i++) {
            var index = Math.floor((Math.random() * 4));
            this.stacked.push({
                value: Math.floor((Math.random() * 30) + 1),
                type: types[index]
            });
        }
    };
    /**
     * initial run for random stacked value
     */
    this.randomStacked();

};

/**
 * translateCtrl - Controller for translate
 */
function translateCtrl($translate, $scope) {
    $scope.changeLanguage = function (langKey) {
        $translate.use(langKey);
    };
}

/**
 * idleTimer - Controller for Idle Timer
 */
function idleTimer($scope, Idle, notify) {

    // Custm alter
    $scope.customAlert = false;

    // Start watching idle
    Idle.watch();

    // Config notify behavior
    notify.config({
        duration: '5000'
    });

    // function you want to fire when the user goes idle
    $scope.$on('IdleStart', function () {
        notify({
            message: 'Idle time - You can call any function after idle timeout.',
            classes: 'alert-warning',
            templateUrl: 'views/common/notify.html'
        });
        $scope.customAlert = true;

    });

    // function you want to fire when the user becomes active again
    $scope.$on('IdleEnd', function () {
        notify({
            message: 'You are back, Great that you decided to move a mouse.',
            classes: 'alert-success',
            templateUrl: 'views/common/notify.html'
        });
        $scope.customAlert = false;
    });

}

/**
 * sweetAlertCtrl - Function for Sweet alerts
 */
function sweetAlertCtrl($scope, SweetAlert) {


    $scope.demo1 = function () {
        SweetAlert.swal({
            title: "Welcome in Alerts",
            text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
        });
    }

    $scope.demo2 = function () {
        SweetAlert.swal({
            title: "Good job!",
            text: "You clicked the button!",
            type: "success"
        });
    }

    $scope.demo3 = function () {
        SweetAlert.swal({
                title: "Are you sure?",
                text: "Your will not be able to recover this imaginary file!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function () {
                SweetAlert.swal("Ok!");
            });
    }

    $scope.demo4 = function () {
        SweetAlert.swal({
                title: "Are you sure?",
                text: "Your will not be able to recover this imaginary file!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "No, cancel plx!",
                closeOnConfirm: false,
                closeOnCancel: false },
            function (isConfirm) {
                if (isConfirm) {
                    SweetAlert.swal("Deleted!", "Your imaginary file has been deleted.", "success");
                } else {
                    SweetAlert.swal("Cancelled", "Your imaginary file is safe :)", "error");
                }
            });
    }

}

function selectCtrl($scope) {

    $scope.person = {};
    $scope.people = [
        { name: 'Adam',      email: 'adam@email.com',      age: 12, country: 'United States' },
        { name: 'Amalie',    email: 'amalie@email.com',    age: 12, country: 'Argentina' },
        { name: 'Estefanía', email: 'estefania@email.com', age: 21, country: 'Argentina' },
        { name: 'Adrian',    email: 'adrian@email.com',    age: 21, country: 'Ecuador' },
        { name: 'Wladimir',  email: 'wladimir@email.com',  age: 30, country: 'Ecuador' },
        { name: 'Samantha',  email: 'samantha@email.com',  age: 30, country: 'United States' },
        { name: 'Nicole',    email: 'nicole@email.com',    age: 43, country: 'Colombia' },
        { name: 'Natasha',   email: 'natasha@email.com',   age: 54, country: 'Ecuador' },
        { name: 'Michael',   email: 'michael@email.com',   age: 15, country: 'Colombia' },
        { name: 'Nicolás',   email: 'nicolas@email.com',    age: 43, country: 'Colombia' }
    ];

    $scope.option = {};
    $scope.options = [
        { number: '1',      text: 'Option 1' },
        { number: '2',      text: 'Option 2' },
        { number: '3',      text: 'Option 3' },
        { number: '4',      text: 'Option 4' },
        { number: '5',      text: 'Option 5' },
        { number: '6',      text: 'Option 6' }
    ];

    $scope.availableColors = ['Red','Green','Blue','Yellow','Magenta','Maroon','Umbra','Turquoise'];

    $scope.multipleDemo = {};
    $scope.multipleDemo.colors = ['Blue','Red'];

}



function toastrCtrl($scope, toaster){

    $scope.demo1 = function(){
        toaster.success({ body:"Hi, welcome to Inspinia. This is example of Toastr notification box."});
    };

    $scope.demo2 = function(){
        toaster.warning({ title: "Title example", body:"This is example of Toastr notification box."});
    };

    $scope.demo3 = function(){
        toaster.pop({
            type: 'info',
            title: 'Title example',
            body: 'This is example of Toastr notification box.',
            showCloseButton: true

        });
    };

    $scope.demo4 = function(){
        toaster.pop({
            type: 'error',
            title: 'Title example',
            body: 'This is example of Toastr notification box.',
            showCloseButton: true,
            timeout: 600
        });
    };

}

function loadingCtrl($scope, $timeout){


    $scope.runLoading = function() {
        // start loading
        $scope.loading = true;

        $timeout(function(){
            // Simulate some service
            $scope.loading = false;
        },2000)
    };


    // Demo purpose actions
    $scope.runLoading1 = function () {
        // start loading
        $scope.loading1 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading1 = false;
        }, 2000)
    };
    $scope.runLoading2 = function () {
        // start loading
        $scope.loading2 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading2 = false;
        }, 2000)
    };
    $scope.runLoading3 = function () {
        // start loading
        $scope.loading3 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading3 = false;
        }, 2000)
    };
    $scope.runLoading4 = function () {
        // start loading
        $scope.loading4 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading4 = false;
        }, 2000)
    };
    $scope.runLoading5 = function () {
        // start loading
        $scope.loading5 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading5 = false;
        }, 2000)
    };
    $scope.runLoading6 = function () {
        // start loading
        $scope.loading6 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading6 = false;
        }, 2000)
    };
    $scope.runLoading7 = function () {
        // start loading
        $scope.loading7 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading7 = false;
        }, 2000)
    };
    $scope.runLoading8 = function () {
        // start loading
        $scope.loading8 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading8 = false;
        }, 2000)
    };
    $scope.runLoading9 = function () {
        // start loading
        $scope.loading9 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading9 = false;
        }, 2000)
    };
    $scope.runLoading10 = function () {
        // start loading
        $scope.loading10 = true;

        $timeout(function () {
            // Simulate some service
            $scope.loading10 = false;
        }, 2000)
    };
    $scope.runLoading11 = function () {
        // start loading
        $timeout(function() {
            $scope.loading11 = 0.1;
        }, 500);
        $timeout(function() {
            $scope.loading11 += 0.2;
        }, 1000);
        $timeout(function() {
            $scope.loading11 += 0.3;
        }, 1500);
        $timeout(function() {
            $scope.loading11 = false;
        }, 2000);

    };
    $scope.runLoading12 = function () {
        // start loading
        $timeout(function() {
            $scope.loading12 = 0.1;
        }, 500);
        $timeout(function() {
            $scope.loading12 += 0.2;
        }, 1000);
        $timeout(function() {
            $scope.loading12 += 0.3;
        }, 1500);
        $timeout(function() {
            $scope.loading12 = false;
        }, 2000);

    };

    $scope.runLoadingDemo = function() {
        // start loading
        $scope.loadingDemo = true;

        $timeout(function(){
            // Simulate some service
            $scope.loadingDemo = false;
        },2000)
    };


}

/**
 * Login controller
 *
 * @param $scope
 * @param $http
 * @param toaster
 * @constructor
 */
function Login($scope, $http){
    var busy = false;

    $scope.url = 'api.php';

    $scope.logged = false;
    $scope.username = "";
    $scope.useracl = 0;
    $scope.userfio = "N.A";

    $scope.error = "has-error";
    $scope.doLogin = function() {
        busy = true;
        $http.post($scope.url, { "request" : "whoami"})
            .success(function(data, status) {
                if (data.result == '1'){
                    if (data.status == '1'){
                        $scope.logged = true;
                        $state.go('mb.main');
                    }
                }
                busy = false;
            })
            .error(function(data, status) {
                busy = false;
                console.log(data || "Request failed");
            });
    };
}

/**
 * Server Time and Date
 *
 * @param $scope
 * @param $http
 * @constructor
 */
function ServerTime($scope, $http, $interval, $state){

    $scope.url = 'api.php'; // The url of our search
    $scope.textTime = 'N.A.';
    $scope.textZone = 'N.A';
    $scope.textDate = 'Дата: N.A.';
    var busy = false;

    function getServerTime(){
        $http.post($scope.url, { "request" : "time" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.textZone = data.tzone;
                    $scope.textTime =  data.time;
                    $scope.textDate =  data.date;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }
    //
    getServerTime();
    var intervalPromise = $interval(getServerTime, 60000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}

/**
 * System User active/last
 * @param $scope
 * @param $http
 * @constructor
 */
function SystemUsers($scope, $http, $interval){

    $scope.url = 'api.php'; // The url of our search
    $scope.activeUsers = {};
    $scope.lastUsers = {};

    function getUsers(){

        $http.post($scope.url, { "request" : "sysusers" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.activeUsers = data.active;
                    $scope.lastUsers = data.last;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    //getUsers();
    //var intervalPromise = $interval(getUsers, 10000);
    //$scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}


/**
 * Server Uptime
 *
 * @param $scope
 * @param $http
 * @constructor
 */
function ServerUpTime($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.textUpTime = 'N.A.';

    function getServerTime(){

        $http.post($scope.url, { "request" : "uptime" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.textUpTime =  data.uptime;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getServerTime();
    var intervalPromise = $interval(getServerTime, 60000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}

/**
 * Mikbill On-line
 *
 * @param $scope
 * @param $http
 * @constructor
 */
function MikbillOnline($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.textOnline = 'N.A.';

    function getOnlineTime(){

        $http.post($scope.url, { "request" : "online" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.textOnline =  data.online;
                }else{
                    $scope.textOnline = 'N.A.';
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getOnlineTime();
    var intervalPromise = $interval(getOnlineTime, 30000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });

}


/**
 * System Info
 *
 * @param $scope
 * @param $http
 * @constructor
 */
function SystemInfo($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.textOS = 'N.A.';
    $scope.textKernell = 'N.A.';
    $scope.textPhp = 'N.A.';

    function getSystemInfo(){

        $http.post($scope.url, { "request" : "sysinfo" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.textOS =  data.os;
                    $scope.textKernell =  data.kernel;
                    $scope.textPhp =  data.php;
                }else{
                    $scope.textOS = 'N.A.';
                    $scope.textKernell = 'N.A.';
                    $scope.textPhp = 'N.A.';
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getSystemInfo();
    //var intervalPromise = $interval(getSystemInfo, 60000);
    //$scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });

}

/**
 * System CPU
 *
 * @param $scope
 * @param $http
 * @constructor
 */
function SystemCPU($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.value = "0";
    $scope.idle = "0";
    $scope.total = "0";
    $scope.bartype = "bar-default";

    function getCPU(){
        $http.post($scope.url, { "request" : "syscpunow", "idle": $scope.idle, "total": $scope.total }).
            success(function(data, status) {
                if (data.result == '1'){
                    $scope.value = data.value;
                    $scope.idle = data.idle;
                    $scope.total = data.total;

                    if(data.value > 85)
                    {
                        $scope.bartype = "bar-danger";
                    }
                    else if(data.value > 60)
                    {
                        $scope.bartype = "bar-warning";
                    }
                    else
                    {
                        $scope.bartype = "bar-default";
                    }
                }else{
                    $scope.value = "0";
                }
            }).error(function(data, status) {
                $scope.value = "0";
                console.log(data || "Request failed");
            });
    }

    getCPU();
    var intervalPromise = $interval(getCPU, 2000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });

}

function SystemCpuAVG($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.value = "N.A.";

    function getCPU(){

        $http.post($scope.url, { "request" : "syscpu" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.average1 = data.average1;
                    $scope.average5 = data.average5;
                    $scope.average15 = data.average15;
                }else{
                    $scope.average1 = "N.A";
                    $scope.average5 = "N.A";
                    $scope.average15 = "N.A";
                }
            })
            .
            error(function(data, status) {
                $scope.average1 = "N.A";
                $scope.average5 = "N.A";
                $scope.average15 = "N.A";
                console.log(data || "Request failed");
            });
    }

    getCPU();
    var intervalPromise = $interval(getCPU, 15000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });

}

function SystemRAM($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.value = 0;
    $scope.used = "N.A.";
    $scope.free = "N.A.";
    $scope.total = "N.A";

    function getRAM(){

        $http.post($scope.url, { "request" : "sysram" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.value = data.used_percent;
                    $scope.used = data.used;
                    $scope.free = data.free;
                    $scope.total = data.total;
                }else{
                    $scope.value = "0";
                    $scope.used = "N.A";
                    $scope.free = "N.A";
                    $scope.total = "N.A";
                }
            })
            .
            error(function(data, status) {
                $scope.value = "0";
                $scope.used = "N.A";
                $scope.free = "N.A";
                $scope.total = "N.A";
                console.log(data || "Request failed");
            });
    }

    getRAM();
    var intervalPromise = $interval(getRAM, 30000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}


function SystemHDD($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.value = 0;
    $scope.used = "N.A.";
    $scope.free = "N.A.";
    $scope.total = "N.A";

    function getMemoryHDD(){

        $http.post($scope.url, { "request" : "syshdd" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.value = data.data.percent;
                    $scope.used = data.data.used;
                    $scope.free = data.data.avail;
                    $scope.total = data.data.size;
                }else{
                    $scope.value = "0";
                    $scope.used = "N.A";
                    $scope.free = "N.A";
                    $scope.total = "N.A";
                }
            })
            .
            error(function(data, status) {
                $scope.value = "0";
                $scope.used = "N.A";
                $scope.free = "N.A";
                $scope.total = "N.A";
                console.log(data || "Request failed");
            });
    }

    getMemoryHDD();
    var intervalPromise = $interval(getMemoryHDD, 60000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}

function ServersNAS($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.arrayNAS = {};

    function getNAS(){

        $http.post($scope.url, { "request" : "naslist" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.arrayNAS = data.nases;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    function updateNAS(){
        $http.post($scope.url, { "request" : "nasupdate" });
    }

    updateNAS();
    getNAS();

    var intervalPromiseGet = $interval(getNAS, 60000);
    var intervalPromiseUpdate = $interval(updateNAS, 55000);

    $scope.$on('$destroy', function () {
        $interval.cancel(intervalPromiseGet);
        $interval.cancel(intervalPromiseUpdate);
    });
}

function OnlineNAS($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.count = 0;
    $scope.count_all = 0;

    function getOnlineNAS(){

        $http.post($scope.url, { "request" : "nasonline" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.count = data.count;
                    $scope.count_all = data.count_all;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getOnlineNAS();
    var intervalPromise = $interval(getOnlineNAS, 60000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}


/**
 * Service Daemon
 *
 * @param $scope
 * @param $http
 * @constructor
 */
function ServiceDaemon($scope, $http, $interval, toaster, $timeout){

    /**
     * initial
     */
    var statusService = 'down'; //DEMO
    var busy = false;
    var intervalPromise;

    $scope.daemonIndex = ''; // The service name
    $scope.url = 'api.php'; // The url of our search
    $scope.textService = 'Инициализация...'; //DEMO
    $scope.stateServiceText = 'N.A.';
    $scope.stateServiceClass = 'warning';
    $scope.stateServiceClass2 = 'warning';
    $scope.stateServiceIcon = '';
    $scope.btnClass = 'btn-primary';
    $scope.btnText  = 'Запустить';

    // Refresh Status Button Start/Stop
    function refreshView(){
        if (statusService == 'up'){
            $scope.btnClass = 'btn-danger';
            $scope.btnText  = 'Остановить';

            $scope.stateServiceText = 'ВКЛ';
            $scope.stateServiceClass = 'primary';
            $scope.stateServiceClass2 = 'navy';
            $scope.stateServiceIcon = 'fa fa-play fa-rotate-270';

        }

        if (statusService == 'down'){
            $scope.btnClass = 'btn-primary';
            $scope.btnText  = 'Запустить';

            $scope.stateServiceText = 'ВЫКЛ';
            $scope.stateServiceClass = 'danger';
            $scope.stateServiceClass2 = 'danger';
            $scope.stateServiceIcon = 'fa fa-play fa-rotate-90';
        }

        if (statusService == 'unknow'){
            $scope.btnClass = 'btn-primary';
            $scope.btnText  = 'Запустить';

            $scope.stateServiceText = 'N.A.';
            $scope.stateServiceClass = 'warning';
            $scope.stateServiceClass2 = 'warning';
            $scope.stateServiceIcon = '';
        }
    }


    // Send Run
    function sendRun() {

        busy = true;
        $scope.textService = 'Запуск сервиса...'; //

        $http.post($scope.url, { "request" : "service", "daemon" : $scope.daemonIndex, "action": "run" }).
            success(function(data, status) {

                if (data.result == '1'){
                    if (data.status == '1'){
                        statusService = 'up';
                        $scope.textService = 'Сервис запущен'; //
                        toaster.pop({
                            type: 'success',
                            title: 'Успех',
                            body: 'Сервис '+ data.daemon +' успешно запущен'
                        });
                    } else {
                        $scope.textService = 'Ошибка запуска сервиса'; //
                        toaster.pop({
                            type: 'error',
                            title: 'Ошибка',
                            body: 'Не удалось запустить сервис '+ data.daemon
                        });
                    }
                }
                refreshView();
                busy = false;
            })
            .error(function(data, status) {
                busy = false;
                $scope.laddaStopStart = false;
                console.log(data || "Request failed");
            });
    }

    // Send Stop
    function sendStop() {
        busy = true;
        $scope.textService = 'Остановка сервиса...'; //

        $http.post($scope.url, { "request" : "service", "daemon" : $scope.daemonIndex, "action": "stop" }).
            success(function(data, status) {

                if (data.status == '1'){
                    statusService = 'down';
                    $scope.textService = 'Сервис остановлен'; //DEMO
                    toaster.pop({
                        type: 'success',
                        title: 'Успех',
                        body: 'Сервис '+ data.daemon +' успешно остановлен'
                    });
                } else {
                    $scope.textService = 'Ошибка остановки сервиса'; //DEMO
                    toaster.pop({
                        type: 'error',
                        title: 'Ошибка',
                        body: 'Не удалось остановить сервис '+ data.daemon
                    });
                }

                refreshView();
                busy = false;
            })
            .error(function(data, status) {
                console.log(data || "Request failed");
                busy = false;
                $scope.laddaStopStart = false;
            });
    }

    // Send Restart
    function sendRestart() {
        busy = true;
        $scope.textService = 'Перезагрузка сервиса...'; //

        $http.post($scope.url, { "request" : "service", "daemon" : $scope.daemonIndex, "action": "restart" }).
            success(function(data, status) {

                if (data.status == '1'){
                    statusService = 'up';
                    $scope.textService = 'Сервис успешно перезагружен';
                    toaster.pop({
                        type: 'success',
                        title: 'Успех',
                        body: 'Сервис '+ data.daemon +' успешно перезапущен'
                    });
                } else {
                    $scope.textService = 'Ошибка перезагрузки сервиса';
                    toaster.pop({
                        type: 'error',
                        title: 'Ошибка',
                        body: 'Не удалось перезапустить сервис '+ data.daemon
                    });
                }

                refreshView();
                busy = false;
            })
            .error(function(data, status) {
                console.log(data || "Request failed");
                busy = false;
                $scope.laddaReload = false;
            });
    }

    // Send get Status
    function sendGetStatus() {
        busy = true;
        $http.post($scope.url, { "request" : "service", "daemon" : $scope.daemonIndex, "action": "status" }).
            success(function(data, status) {

                if (data.result == '1'){
                    if (data.status == '1'){
                        statusService = 'up';
                        $scope.textService = 'Сервис запущен'; //DEMO
                    }

                    if (data.status == '0'){
                        statusService = 'down';
                        $scope.textService = 'Сервис остановлен'; //DEMO
                    }
                }
                else{
                    statusService = 'unknow';
                    $scope.textService = 'Состояние не определено...'; //DEMO
                }

                refreshView();
                busy = false;
            })
            .error(function(data, status) {
                statusService = 'unknow';
                console.log(data || "Request failed");
            });
    }

    // Кнопка клик Run/Stop
    $scope.btnClick = function() {
        if (statusService == 'up'){
            sendStop();
        }else {
            sendRun();
        }
    };

    // Кнопка клик "Рестарт сервиса"
    $scope.btnRestartClick = function() {
        sendRestart();
    };

    // RefreshStatus Service
    function refreshStatusService() {
        if(busy == false) {
            sendGetStatus();
        }
    }

    $scope.runLoadingDemo = function() {
        // start loading
        console.log("ladda debug start");
        $scope.loadingDemo = true;
        $timeout(function(){
            // Simulate some service and stop loading
            $scope.loadingDemo = false;
        },2000);
        console.log("ladda debug stop");
    };

    $scope.$watch(ServiceDaemon.daemonIndex, function(val) {
        refreshStatusService();
        intervalPromise = $interval(refreshStatusService, 15000);
    });

    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}


/**
 * System service list
 * @param $scope
 * @param $http
 * @constructor
 */

function ServiceList($scope, $http, $state){

    $scope.url = 'api.php'; // The url of our search
    $scope.services = {};

    function getServiceList(){

        $http.post($scope.url, { "request" : "service", "daemon" : 0, "action": "list" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.services = data.services;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getServiceList();
    //setInterval(getServiceList, 60000);
}

/**
 * System User active/last
 * @param $scope
 * @param $http
 * @constructor
 */
function ProcessList($scope, $http, $interval){

    $scope.url = 'api.php'; // The url of our search
    $scope.proclist = {};

    function getProcessList(){

        $http.post($scope.url, { "request" : "proclist"}).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.proclist = data.proclist;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getProcessList();
    //var intervalPromise = $interval(getProcessList, 30000);
    //$scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}

function DiskStat($scope, $http, $interval){

    $scope.url = 'api.php'; // The url of our search
    $scope.partitions = {};
    $scope.iostat = {};

    function getPartitions(){
        $http.post($scope.url, { "request" : "diskstat"}).
            success(function(data, status) {
                if (data.result == '1'){
                    $scope.partitions = data.data;
                }
            })
            .error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    function getIOStat(){
        $http.post($scope.url, { "request" : "iostat"}).
            success(function(data, status) {
                if (data.result == '1'){
                    $scope.iostat = data.data;
                }
            })
            .error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getPartitions();
    getIOStat();
    var intervalPromise = $interval(getIOStat, 5000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });
}

function ServersSwitch($scope, $http, $interval, $state){
    $scope.url = 'api.php'; // The url of our search
    $scope.arraySW = {};

    function getSW(){

        $http.post($scope.url, { "request" : "switchlist" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.arraySW = data.switches;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    function updateSW(){
        $http.post($scope.url, { "request" : "switchupdate" });
    }

    getSW();
    //updateSW();

    //var intervalPromiseGet = $interval(getSW, 10000);
    //var intervalPromiseUpdate = $interval(updateSW, 30000);

    //$scope.$on('$destroy', function () {
     //   $interval.cancel(intervalPromiseGet);
     //   $interval.cancel(intervalPromiseUpdate);
    //});

}

function OnlineSW($scope, $http, $interval){
    $scope.url = 'api.php'; // The url of our search
    $scope.swcount = 0;
    $scope.swcount_all = 0;

    function getOnlineSW(){

        $http.post($scope.url, { "request" : "switchonline" }).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.swcount = data.count;
                    $scope.swcount_all = data.count_all;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getOnlineSW();
    var intervalPromise = $interval(getOnlineSW, 60000);
    $scope.$on('$destroy', function () { $interval.cancel(intervalPromise); });

}

function SystemLogs($scope, $http, $state){

    $scope.url = 'api.php'; // The url of our search
    $scope.systemlogs = "";

    function getSysLogs(){

        $http.post($scope.url, { "request" : "logs"}).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.systemlogs = data.logs;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getSysLogs();
}

function SystemPHPmodules($scope, $http){

    $scope.url = 'api.php'; // The url of our search
    $scope.text = "Состояние:";
    $scope.modules= ["Все ок."];
    $scope.btn_type = "primary";
    function getModules(){

        $http.post($scope.url, { "request" : "phpmodules"}).
            success(function(data, status) {

                if (data.result == '1'){
                    $scope.modules = data.modules;
                    $scope.btn_type = "danger";
                    $scope.text = data.text;
                }
            })
            .
            error(function(data, status) {
                console.log(data || "Request failed");
            });
    }

    getModules();
}
/**
 *
 * Pass all functions into module
 */
angular
    .module('inspinia')
    .controller('MainCtrl', MainCtrl)
    .controller('Login', Login)
    .controller('ServiceList', ServiceList)
    .controller('ServiceDaemon', ServiceDaemon)
    .controller('ServerTime', ServerTime)
    .controller('ServerUpTime', ServerUpTime)
    .controller('ServersNAS', ServersNAS)
    .controller('ServersSwitch', ServersSwitch)
    .controller('SystemLogs', SystemLogs)
    .controller('OnlineNAS', OnlineNAS)
    .controller('OnlineSW', OnlineSW)
    .controller('MikbillOnline', MikbillOnline)
    .controller('SystemInfo', SystemInfo)
    .controller('SystemUsers', SystemUsers)
    .controller('SystemCPU', SystemCPU)
    .controller('SystemCpuAVG', SystemCpuAVG)
    .controller('SystemRAM', SystemRAM)
    .controller('SystemHDD', SystemHDD)
    .controller('ProcessList', ProcessList)
    .controller('DiskStat', DiskStat)
    .controller('SystemPHPmodules', SystemPHPmodules)
    .controller('sweetAlertCtrl', sweetAlertCtrl)
    .controller('selectCtrl', selectCtrl)
    .controller('toastrCtrl', toastrCtrl);

