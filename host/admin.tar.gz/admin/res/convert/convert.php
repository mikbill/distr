<?php
	define ("BILL_AUTH_TABLE","users");
	define ("BILL_NAS_TABLE", "radnas" );
	define ("BILL_NASLOG_TABLE", "radnaslog" );
	define ("BILL_SYSPOTS_TABLE", "sysopts" );
	define ("BILL_PACKET_TABLE", "packets" );	
	$config_file='../../app/etc/config.xml';

	if (file_exists($config_file)) {
		$xml = simplexml_load_file($config_file);
		$CONF_LOG  = (string) $xml->parameters->kernel->log;
		$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
		$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
		$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
		$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;

	} else {
		die("config not found");
	}

	function open_logs($CONF_LOG)
	{
		return 	fopen($CONF_LOG, "a");
	}

	$stdlog = open_logs($CONF_LOG);


	function do_log($stdlog,$text_log)
	{
		fputs($stdlog, get_date()." ".$text_log."\n");
	}

	function do_log_sql($stdlog,$text_log,&$LINK)
	{
		if (!mysql_ping($GLOBALS["LINK"]))
		{
			$do_mysql_reconect=1;
			fputs($stdlog, get_date()." MySQL Connect failed"."\n");
		}else{
			fputs($stdlog, get_date()." ".$text_log."\n");
		}

		while ($do_mysql_reconect==1)
		{
			$config_file='../../app/etc/config.xml';

			if (file_exists($config_file)) {
				$xml = simplexml_load_file($config_file);
				$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
				$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
				$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
				$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
			}
			$GLOBALS["LINK"] = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
			mysql_select_db ( $CONF_MYSQL_DBNAME , $GLOBALS["LINK"] );

			if (mysql_ping($GLOBALS["LINK"])){
				$do_mysql_reconect=0;
				fputs($stdlog, get_date()." MySQL Connect restored"."\n");
			}


		}
		return "1";
	}


	function get_date()
	{
		return date ( 'd.m.Y H:i:s' );
	}

	function init_nas($LINK,$stdlog)
	{

		$result = mysql_query ( "SELECT * FROM " . BILL_NAS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#2 ".mysql_error ( $LINK ),$LINK );

		for ($i = 0; $i < mysql_num_rows ($result); $i++) {
			$res = mysql_fetch_array ( $result );
			$nases[$i]=$res;
		}

		mysql_free_result ( $result );

		return $nases;
	}

	function init_sysopts($LINK,$stdlog)
	{
		$result = mysql_query ( "SELECT * FROM " . BILL_SYSPOTS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#6 ".mysql_error ( $LINK ),$LINK );
		$res = mysql_fetch_array ( $result );
		mysql_free_result ( $result );

		return $res;
	}

	function billing_init_packets($LINK,$stdlog)
	{
        $packets = array();
	$result = mysql_query ( "SELECT * FROM " . BILL_PACKET_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
	    $res = mysql_fetch_array($result);
	    $packets[$res["gid"]]=$res;
	}
	    mysql_free_result($result);
	    return $packets;
	}
	
	function get_users_by_gid($LINK,$stdlog,$gid )
	{
	    $result = mysql_query ( "SELECT * FROM " . BILL_AUTH_TABLE . " WHERE gid=".$gid." ", $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
	    $res = mysql_fetch_array ( $result );
		for ($i = 0; $i < mysql_num_rows($result); $i++) {
	        	$res = mysql_fetch_array($result);
			$users[$res["uid"]]=$res;
		}

	    mysql_free_result ( $result );
	    
	    return $users;
	}
	function get_all_users($LINK,$stdlog)
	{
	    $result = mysql_query ( "SELECT * FROM " . BILL_AUTH_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
		for ($i = 0; $i < mysql_num_rows($result); $i++) {
	        	$res = mysql_fetch_array($result);
			$users[$res["uid"]]=$res;
		}

	    mysql_free_result ( $result );
	    
	    return $users;
	}
	function update_user($LINK,$stdlog,$uid,$framed_ip)
	{
	    mysql_query ( "UPDATE " . BILL_AUTH_TABLE . " SET framed_ip='".$framed_ip."' WHERE uid=".$uid, $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
	}
							
	global $LINK;

	$LINK = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
	if (!$LINK) {
		do_log($stdlog,"Cant connect to DB ".$CONF_MYSQL_HOST);
		exit();
	}

	mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK ) or die('Could not select database.');

	    $users_list=get_all_users($LINK,$stdlog);
		foreach ($users_list as $key2=>$value2)
		{
		    if ($value2['framed_ip']!=''){
			$ip=explode(".",trim($value2['framed_ip']));
			$ip2=explode(".",trim($value2['local_ip']));
			$ip_itog=$ip[0].".31.".$ip2[2].".".$ip[3];
			echo $ip_itog."\n";
			update_user($LINK,$stdlog,$value2['uid'],$ip_itog);
		    }
		}



