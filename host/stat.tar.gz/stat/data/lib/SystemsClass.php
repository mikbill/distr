<?php

# Установка языка
function setLanguage($config)
{
	$locales = array();
	$lang_cookie = '';

	# Получаем локаль из куков
	if (isset($_COOKIE['lang'])) {
		$lang_cookie = $_COOKIE['lang'];
	}

	#Запись выбранного языка в куки
	if (isset($_GET['lang'])) {
		$lang_cookie = $_GET['lang'];
		SetCookie("lang", $lang_cookie, time() + (1000 * 24 * 60 * 60));
	}

	if (isset($config['config']['locales'])){
		foreach ($config['config']['locales'] as $k => $v) {
			if (stristr($k, 'name_') !== false) {
				$key_name = str_replace('name_', '', $k);
				$val_en = 'enable_' . $key_name;
				$val_file = 'file_' . $key_name;
				$locales[$v] = array(
					'file'   => $config['config']['locales'][$val_file],
					'enable' => $config['config']['locales'][$val_en]
				);
			}
		}
	}

	# Базовый язык ru-RU (на случай если по умолчанию язык недоступен или не включен)
	$defaultNameLocale = 'ru_RU';
	$defaultFileLocale = 'original';

	# Локализациия по умолчанию.
	if (isset($config['config']['locales_options']['default']) and $config['config']['locales_options']['default'] <> '') {
		$temp_default = $config['config']['locales_options']['default'];
		# Проверяем активированна ли локализация по умолчанию
		if (isset($locales[$temp_default])) {
			$defaultNameLocale = $temp_default;
			$defaultFileLocale = $locales[$temp_default]['file'];
		}
	}

	# Если включен автодетект
	if (isset($config['config']['locales_options']['autoDetect']) and $config['config']['locales_options']['autoDetect'] == 1) {

		$langDetect = new LangDetect();

		$langs = array(
			'ru_RU' => array('ru'),
			'uk_UA' => array('uk'),
			'en_GB' => array('en')
		);

		$detectNameLocale = $langDetect->getBestMatch($defaultNameLocale, $langs);

		# Проверяем активированна ли определенная локаль
		if (isset($locales[$detectNameLocale]) and $locales[$detectNameLocale]['enable'] == 1) {
			$nameLocale = $detectNameLocale;
			$fileLoacale = $locales[$detectNameLocale]['file'];
		} else {
			$nameLocale = $defaultNameLocale;
			$fileLoacale = $defaultFileLocale;
		}
	} else {
		$nameLocale = $defaultNameLocale;
		$fileLoacale = $defaultFileLocale;
	}

	#Если язык из куков включен то используем его
	if (isset($locales[$lang_cookie]) and $locales[$lang_cookie]['enable'] == 1) {
		$nameLocale = $lang_cookie;
	}

	if(empty($fileLoacale)){
		$fileLoacale = $defaultFileLocale;
	}

	T_setlocale(LC_MESSAGES, $nameLocale);
	T_bindtextdomain($fileLoacale, './data/locale');
	T_bind_textdomain_codeset($fileLoacale, 'UTF-8');
	T_textdomain($fileLoacale);
}


class SystemsClass
{
	function get_input_data()
	{
		$params_input = array();

		if (!empty($_POST) AND is_array($_POST)) {
			foreach ($_POST as $k => $v) {
				$params_input[$k] = $v;
			}
		}

		if (!empty($_GET) AND is_array($_GET)) {
			foreach ($_GET as $k => $v) {
				$params_input[$k] = $v;
			}
		}

		return $params_input;
	}

	public function getBillLink($cabinetPath)
	{
		$result_array = array(
			'getserverdate'                  => $cabinetPath . '/ajax/index/getserverdate',
			'usevaucherfl'                   => $cabinetPath . '/ajax/users/usevaucherfl',
			'authfl'                         => $cabinetPath . '/ajax/index/authfl',
			'logoutfl'                       => $cabinetPath . '/ajax/index/logoutfl',
			'getticketslist2x'               => $cabinetPath . '/ajax/ticketview/getticketslist2x',
			'getmessages'                    => $cabinetPath . '/ajax/ticketview/getmessages',
			'addticket'                      => $cabinetPath . '/ajax/ticketedit/addticket',
			'updateticket'                   => $cabinetPath . '/ajax/ticketedit/updateticket',
			'addmessage'                     => $cabinetPath . '/ajax/ticketedit/addmessage',
			'statpaymfl'                     => $cabinetPath . '/ajax/users/statpaymfl',
			'getcabinetnews'                 => $cabinetPath . '/ajax/users/getcabinetnewsdb',
			'stattrafflex'                   => $cabinetPath . '/ajax/users/stattrafflex',
			'tarifchangelistflex'            => $cabinetPath . '/ajax/users/tarifchangelistflex',
			'howmatchpayperehodflex'         => $cabinetPath . '/ajax/users/howmatchpayperehodflex',
			'dochangerealipflex'             => $cabinetPath . '/ajax/users/dochangerealipflex',
			'dochangetarifflex'              => $cabinetPath . '/ajax/users/dochangetarifflex',
			'getturboflex'                   => $cabinetPath . '/ajax/users/getturboflex',
			'getcreditflex'                  => $cabinetPath . '/ajax/users/getcreditflex',
			'getcreditprocentflex'           => $cabinetPath . '/ajax/users/getcreditprocentflex',
			'dochangedataflex'               => $cabinetPath . '/ajax/users/dochangedataflex',
			'dochangepassflex'               => $cabinetPath . '/ajax/users/dochangepassflex',
			'getuserdatafl'                  => $cabinetPath . '/ajax/users/getuserdatafl',
			'dofreezeuserfl'                 => $cabinetPath . '/ajax/users/dofreezeuserfl',
			'dounfreezeuserfl'               => $cabinetPath . '/ajax/users/dounfreezeuserfl',
			'doperevodfl'                    => $cabinetPath . '/ajax/users/doperevodfl',
			'dochangedatebirthflex'          => $cabinetPath . '/ajax/users/dochangedatebirthflex',
			'config_xml'                     => $cabinetPath . '/res/config.xml',
			'getconfightml'                  => $cabinetPath . '/ajax/index/getconfightml',
			'getcopaycourl'                  => $cabinetPath . '/ajax/users/getcopaycourl',
			'authip'                         => $cabinetPath . '/ajax/index/authip',
			'getotphtml'                     => $cabinetPath . '/ajax/index/getotphtml',
			'applyotphtml'                   => $cabinetPath . '/ajax/index/applyotphtml',
			'getpacketslistregistrationhtml' => $cabinetPath . '/ajax/index/getpacketslistregistrationhtml',
			'registrationType2'              => $cabinetPath . '/ajax/index/registrationType2',
			'restorepasswordsms'             => $cabinetPath . '/ajax/index/restorepasswordsms',
			'checkloggedin'                  => $cabinetPath . '/ajax/users/checkloggedin',
			'checkchangemac'                 => $cabinetPath . '/ajax/users/checkchangemac'
		);

		return $result_array;
	}
}