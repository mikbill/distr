<?php
/**
 * @version 2.7.23
 */
 
$error_text='ERROR';

if (isset($_POST['uid'])){
	$uid = $_POST['uid'];
}else{
	die($error_text);
	
}
if (!is_numeric($uid)){
	die($error_text);
}
define ( "BILL_SYSTEM_OPTIONS_TABLE", "system_options" );
define ( "BILL_ONPAY_TABLE", "addons_onpay" );

if (isset($_POST['summa'])){
	$summa = $_POST['summa'];
}else{
	$summa=100;
}

if (!is_numeric($summa)){
	die($error_text);
}

if (isset($_POST['fio'])){
	$fio = $_POST['fio'];
}else{
	$fio = "";
}
$sum=$summa;

$config_file='./app/etc/config.xml';

if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
} else {
	die();
}

$LINK = mysql_connect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK );

if (!mysql_ping($LINK)){
	die();
}

function billing_init_system_options($LINK)
{
	$result = mysql_query ( "SELECT * FROM ".BILL_SYSTEM_OPTIONS_TABLE." WHERE 1 ", $LINK ) or die();
	$options= array();
	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$options[$res['key']]=$res['value'];
	}
	mysql_free_result($result);
	return $options;
}

function to_float($sum) {
	if (strpos($sum, ".")) {
		$sum = round($sum, 2);
	} else {
		$sum = $sum.".0";
	}
	return $sum;
}

$sys_options = billing_init_system_options($LINK);

$login = $sys_options['onpay_login'];
$secret = $sys_options['onpay_secret'];

$curency =  $sys_options['onpay_ccy'];
$url_result = $sys_options['onpay_url_success'];

# �������� ���������� �������
$price_final = 'false';

if (isset($sys_options['onpay_commission_by_provider']) AND $sys_options['onpay_commission_by_provider'] == 1) {
	$price_final = 'true';
}

$fio2 =  $uid;
$description = $uid;
$text=iconv ("CP1251","UTF-8","��������� ���� �� �����: ".$summa." ".$curency);
$text2=iconv ("CP1251","UTF-8","���������");
$title=iconv ("CP1251","UTF-8","���������� OnPay");
$text3=iconv ("CP1251","UTF-8","�������� � ");
$text4=iconv ("CP1251","UTF-8","���������");
$fio=iconv ("CP1251","UTF-8",$fio);

mysql_query ( "INSERT INTO " . BILL_ONPAY_TABLE . "  (`payid` ,`uid` ,`order_amount` ,`order_currency` ,`type` ,`comment` ,`paymentDateTime` ,`onpay_id`,`user_phone` ) VALUES (NULL, '".$uid."','".$summa."','".$curency."','','".$uid."',CURRENT_TIMESTAMP,'',''); ", $LINK ) or die(mysql_error($LINK));

$tranzakt_onpay_payid = mysql_insert_id();
mysql_close($LINK);

# http://wiki.onpay.ru/doku.php?id=payment-links-specs
# pay_mode;price;currency;pay_for;convert;secret_key

$md5check = md5("fix;".to_float($sum).";$curency;$tranzakt_onpay_payid;yes;$secret");

//������� ������� ��� �������
$utl_text="pay_mode=fix&price=$sum&currency=$curency&pay_for=$tranzakt_onpay_payid&convert=yes&price_final=$price_final&md5=$md5check&url_success=".$url_result;

$url = "http://secure.onpay.ru/pay/".$login."?".$utl_text;

header('Location: '.$url);
