<?php

$error_text='ERROR';

if (isset($_POST['uid'])){
	$uid = $_POST['uid'];
}else{
	die($error_text);
}
if (!is_numeric($uid)){
	die($error_text);
}

define ( "BILL_SYSTEM_OPTIONS_TABLE", "system_options" );
define ( "BILL_LIQPAY_TABLE", "addons_liqpay" );

if (isset($_POST['summa'])){
	$summa = $_POST['summa'];
}else{
	$summa=100;
}

if (!is_numeric($summa)){
	die($error_text);
}

if (isset($_POST['fio'])){
	$fio = $_POST['fio'];
}else{
	$fio = "";
}


$config_file='./app/etc/config.xml';

if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
} else {
	die();
}

$LINK = mysql_connect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK );

if (!mysql_ping($LINK)){
	die();
}

function billing_init_system_options($LINK)
{
$result = mysql_query ( "SELECT * FROM ".BILL_SYSTEM_OPTIONS_TABLE." WHERE 1 ", $LINK ) or die();
	$options= array();
	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$options[$res['key']]=$res['value'];
	}
	mysql_free_result($result);
	return $options;
}

$sys_options = billing_init_system_options($LINK);


$merchant_id = $sys_options['merchant_id'];
$phone_pay = $sys_options['phone_pay'];
$merc_sign = $sys_options['merc_sign'];
$merc_sign_other = $sys_options['merc_sign_other'];

$curency =  $sys_options['liqpay_curency'];
$url_result = $sys_options['url_result'];
$url_server = $sys_options['url_server'];

$fio2 =  $uid;
$description = $uid;


mysql_query ( "INSERT INTO " . BILL_LIQPAY_TABLE . " (`order_id`, `order_date`, `merchant_id`, `currency`, `uid`, `amount`, `description`, `status`, `code`,`transaction_id`, `pay_way`, `sender_phone`) VALUES (NULL, CURRENT_TIMESTAMP,'".$merchant_id."', '".$curency."', '".$uid."', '".$summa."', '".$fio2."', '', '', '', '', ''); ", $LINK ) or die(mysql_error($LINK));

$tranzakt_liqpay_id = mysql_insert_id();

$xml="<request>
      <version>1.2</version>
      <merchant_id>".$merchant_id."</merchant_id>
      <result_url>".$url_result."</result_url>
      <server_url>".$url_server."</server_url>
      <order_id>".$tranzakt_liqpay_id."</order_id>
      <amount>".$summa."</amount>
      <currency>".$curency."</currency>
      <description>".$description."</description>
      <default_phone></default_phone>
      <pay_way></pay_way>
      <goods_id></goods_id>
</request>";
#      <default_phone>".$phone_pay."</default_phone>
$sign = base64_encode(sha1($merc_sign_other.$xml.$merc_sign_other,1));
$xml_encoded = base64_encode($xml);

$url="https://www.liqpay.com/?do=clickNbuy";
$text=iconv ("CP1251","UTF-8","��������� ���� �� �����: ".$summa." ".$curency);
$text2=iconv ("CP1251","UTF-8","���������");
$title=iconv ("CP1251","UTF-8","���������� LiqPay");
#$fio=iconv ("CP1251","UTF-8",$fio);
if (mb_detect_encoding($fio, 'UTF-8', true) === FALSE) {
 $fio=iconv ("CP1251","UTF-8",$fio);
}
echo("
<html lang=\"en\">
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<title>".$title."</title>
</head>
<body scroll=\"no\" >
<center>
</br>
".$title."</br>
</br>
".$fio."</br>
</br>
".$text."</br>
</br>
<form action='$url' method='POST'>
<input type='hidden' name='operation_xml' value='$xml_encoded' />
<input type='hidden' name='signature' value='$sign' />
<input type='submit' value='".$text2."'/>
</form>
</center>
</body></html>");

mysql_close($LINK);