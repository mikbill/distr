<?php
header('Content-Type: text/html; charset=utf-8');
$sTaId = @$_GET['ta_id'];
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> <html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <title>CoPayCo shop</title>
</head>
<body>
    <h1>CoPayCo пополнение</h1>
    <p style="color:#006600;">Пополнение счета  по заказу <b><?=$sTaId?></b>, произошло успешно.</p>
    <p><a href="/">Вернуться на главную</a></p>
</body></html>