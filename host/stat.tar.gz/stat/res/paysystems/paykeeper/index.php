<?php

$orderid = startTransaction($LINK, $user, $amount, 'addons_paykeeper');

# Получаем логин з UID
$userFromDB = getUser($LINK, $user['uid']);
if ($userFromDB){
	$clientid = $userFromDB[0]['user'];
}else{
	$clientid = $user['uid'];
}

$queryArray = array(
	"clientid" => $clientid,
	"orderid"  => $orderid,
	"sum"      => $amount,
);

if (isset($user['phone'])) {
	$queryArray["phone"] = $user['phone'];
}

$payment_parameters = http_build_query($queryArray);
$curl=curl_init();
curl_setopt($curl, CURLOPT_URL, $systemOptions['paykeeper_urlpay']);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $payment_parameters);
curl_setopt($curl, CURLOPT_HTTPHEADER, array(
    "Content-type: application/x-www-form-urlencoded; charset='utf-8'"
));
$response = curl_exec($curl);

if ($response === false) {
	$response = 'Не удалось связаться с сервером оплаты';
}