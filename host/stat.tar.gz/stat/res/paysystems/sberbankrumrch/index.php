<?php
/**
 * Created by PhpStorm.
 * User: Maxim
 * Date: 27.05.2016
 * Time: 12:26
 */

//  sberbank.ru class
require(dirname(__FILE__) . '/lib/sberbank.class.php');

$order_id = startTransaction($LINK, $user, $amount, 'addons_sberbankru_mrch');

$merchant_id = $systemOptions[$systemName . '_mrch_id']; // идентификатор точки продажи
$merchant_login_api = $systemOptions[$systemName . '_login_api']; //  логин мерчанта
$merchant_pass_api = $systemOptions[$systemName . '_pass_api']; //  пароль системы

if (!empty($systemOptions[$systemName . '_test']) and $systemOptions[$systemName . '_test'] == '1') {
	$mode = false;
} else {
	$mode = true;
}

if (!empty($systemOptions[$systemName . '_return_url'])) {
	$returnUrl = $systemOptions[$systemName . '_return_url'];
} else {
	$returnUrl = "http://example.com/pay/ok/";
}

if (!empty($systemOptions[$systemName . '_fail_url'])) {
	$failUrl = $systemOptions[$systemName . '_fail_url'];
} else {
	$failUrl = "http://example.com/pay/no/";
}

$SberBankClass = new Sberbank($merchant_id, $merchant_login_api, $merchant_pass_api, $returnUrl, $failUrl, $mode);

$action_url = $SberBankClass->getFormUrl($order_id, $user['uid'], $amount, 'Пополнение баланса, UID: ' . $user['uid']);

if ($action_url) {
	header('Location: ' . $action_url);
} else {
	# Название ПС
	$form->setLabelForm('SberBank.ru');

	# заполняем форму полями
	$form->addFieldForm($form->_h('Ошибка. Попробуйте позже...'));
	$form->addFieldForm($form->_hr());
}
