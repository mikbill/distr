<?php
/**
 * Created by PhpStorm.
 * User: noname
 * Date: 02.11.2015
 * Time: 9:19
 */

/**
 * П А Р А М Е Т Р Ы   Ф О Р М Ы
 */

$tranzakt_liqpay_id = startTransaction($LINK, $user, $amount, 'addons_liqpay', 'order_date');

$merchant_id = $systemOptions['merchant_id'];
$merc_sign_other = $systemOptions['merc_sign_other'];
$curency =  $systemOptions['liqpay_curency'];
$url_result = $systemOptions['url_result'];
$url_server = $systemOptions['url_server'];

$fio2 =  $user['uid'];
$description = $user['uid'];

$action_url = 'https://www.liqpay.com/?do=clickNbuy';

$xml="<request>
      <version>1.2</version>
      <merchant_id>".$merchant_id."</merchant_id>
      <result_url>".$url_result."</result_url>
      <server_url>".$url_server."</server_url>
      <order_id>".$tranzakt_liqpay_id."</order_id>
      <amount>".$amount."</amount>
      <currency>".$curency."</currency>
      <description>".$description."</description>
      <default_phone></default_phone>
      <pay_way></pay_way>
      <goods_id></goods_id>
</request>";

$sign = base64_encode(sha1($merc_sign_other.$xml.$merc_sign_other,1));
$xml_encoded = base64_encode($xml);

/**
 * К О Н С Т Р У К Т О Р   Ф О Р М Ы
 */

# Название ПС
$form->setLabelForm('LiqPay');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('POST');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_input('operation_xml', $xml_encoded));
$form->addFieldForm($form->_input('signature', $sign));

$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' '.$curency, 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
