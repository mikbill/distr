<?php

# основные параметры
# все параметры есть в системных опциях, кроме $cancelURL
$callbackURL = '';
$returnURL = '';
$cancelURL = '';
# текст
$headerText = '<img src="./res/logo/paypal_logo.jpg">
<br /><br />
<span style="font-size: 18px;">Пополнение счёта через PayPal<br />
' . $user['fio'] . '<br />
Сумма: ' . $systemOptions['paypal_currency'] . $amount . '</span><br /><br />';

# дополнительные параметры
$locale = 'ru_RU';
$description = 'Internet Service';
$country = 'RU';
$sandbox = '';


# проверка существования callbackURL
if ($callbackURL == '') {
	if (isset($systemOptions['paypal_ipn_callback_url']) AND $systemOptions['paypal_ipn_callback_url'] != '') {
		$callbackURL = $systemOptions['paypal_ipn_callback_url'];
	} else {
		die('Не указан IPN callback URL');
	}
}

if ($returnURL == '' AND isset($systemOptions['paypal_return_url']) AND $systemOptions['paypal_return_url'] != '') {
	$returnURL = $systemOptions['paypal_return_url'];
}

if ($cancelURL == '') {
	$cancelURL = $returnURL;
}

if (isset($systemOptions['paypal_locale']) AND $systemOptions['paypal_locale'] != '') {
	$locale = $systemOptions['paypal_locale'];
}

if (isset($systemOptions['paypal_description']) AND $systemOptions['paypal_description'] != '') {
	$description = $systemOptions['paypal_description'];
}

if (isset($systemOptions['paypal_country']) AND $systemOptions['paypal_country'] != '') {
	$country = $systemOptions['paypal_country'];
}

if (isset($systemOptions['paypal_sandbox']) AND $systemOptions['paypal_sandbox'] == 1) {
	$sandbox = 'data-env="sandbox"';
}

# пример передачи UID'а абонента параметром:
# data-return="' . $returnURL . '?mbuid=' . $user['uid'] . '"

$response = $headerText . '
<script src="https://www.paypalobjects.com/js/external/paypal-button.min.js?merchant=' . $systemOptions['paypal_merchant'] . '"
    ' . $sandbox . '
    data-callback="' . $callbackURL . '/ajax/index/paypal" 
	data-return="' . $returnURL . '"
	data-cancel_return="' . $cancelURL . '"
    data-shipping="0" 
    data-custom="' . $user['uid'] . '" 
    data-currency="' . $systemOptions['paypal_currency'] . '" 
    data-amount="' . $amount . '" 
    data-quantity="1" 
    data-name="' . $description . '" 
    data-button="paynow" 
    data-locale="' . $locale . '" 
    data-no_shipping="1" 
    data-no_note="1" 
	data-country="' . $country . '"
	async="async"
></script>';
