<?php 
/*
Oplata.com Dashboard
*/
$order_desc = "test order";

#Формируем ордер
$order_id = startTransaction($LINK, $user, $amount, 'addons_oplata');

$amount = preg_replace('~\D+~','', $amount);

$params = array(
    'amount' => $amount,
    'currency' =>$systemOptions[$systemName . '_currency'],
    'order_id' =>$order_id,
    'order_desc' =>$order_desc,
    'merchant_id' => $systemOptions[$systemName . '_merchant_id'],
    'response_url' => $systemOptions[$systemName . '_response_url'],
    'server_callback_url' => $systemOptions[$systemName . '_server_callback_url'],
    
);


$signature = getSignature($params, $systemOptions[$systemName . '_secret_seed']);

function getSignature($inputData, $secret_seed)
{
    if(empty($inputData))
        return false;
        
    ksort($inputData);
    
    $array = array_values($inputData);
    $str = implode('|', $array);
    $str = $secret_seed . '|' . $str;
    //return $str;
    return sha1($str);
}

print $signature;
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
  </head>
  <body>
    <form name="tocheckout" method="POST" action="https://api.oplata.com/api/checkout/redirect/">
      <input type="hidden" name="server_callback_url" value="<?php echo $params['server_callback_url'];?>">
      <input type="hidden" name="response_url" value="<?php echo $params['response_url'];?>">
      <input type="hidden" name="order_id" value="<?php echo $params['order_id'];?>">
      <input type="text" name="order_desc" value="<?php echo $params['order_desc'];?>">
      <input type="hidden" name="currency" value="<?php echo $params['currency'];?>">
      <input type="hidden" name="amount" value="<?php echo $params['amount'];?>">
      <input type="hidden" name="signature" value="<?php echo $signature;?>">
      <input type="hidden" name="merchant_id" value="<?php echo $params['merchant_id'];?>">
      <input type="submit" />
    </form>
  </body>
</html>