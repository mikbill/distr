<?php
/*
iPay Dashboard
*/

//  ipay class
require(dirname(__FILE__) . '/lib/ipay.class.php');

$order_id = startTransaction($LINK, $user, $amount, 'addons_ipay');
$merchant_id = $systemOptions[$systemName . '_merchant_id']; // идентификатор точки продажи
$key_merchant = $systemOptions[$systemName . '_key_merchant']; //  ключ мерчанта
$key_system = $systemOptions[$systemName . '_key_system']; //  ключ системы
$amoun = $amount * 100;

if (!empty($systemOptions[$systemName . '_test']) AND $systemOptions[$systemName . '_test'] == 1){
    $mode = "test";
}else{
    $mode = "real";
}

if (!empty($systemOptions[$systemName . '_success_url'])){
    $success_url =  $systemOptions[$systemName . '_success_url'];
}else{
    $success_url = "http://example.com/pay/ok/";
}

if (!empty($systemOptions[$systemName . '_failure_url'])){
    $failure_url =  $systemOptions[$systemName . '_failure_url'];
}else{
    $failure_url = "http://example.com/pay/no/";
}


$iPay = new iPay( $merchant_id , $key_merchant , $key_system);
$iPay->set_urls($success_url, $failure_url);
$iPay->set_transaction($amoun,'Пополнение баланса, UID: '.$user['uid'], '['.$order_id.']');
$iPay->set_mode($mode);

$xml_result = $iPay->create_payment();
$data_result = xmlParser($xml_result);

if(!empty($data_result)) {
    $action_url = $data_result['url'];
}else{
    $action_url = $failure_url;
}

# Название ПС
$form->setLabelForm('iPay');

# Заполняем action URL для формы
$form->setUrlForm($action_url);

# POST form
$form->setMethodForm('GET');

# заполняем форму полями
$form->addFieldForm($form->_h('Информация по платежу:'));
$form->addFieldForm($form->_hr());

$form->addFieldForm($form->_group($form->_inputLabel(false,$user['fio'], 'ФИО:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$user['uid'], 'UID:')));
$form->addFieldForm($form->_group($form->_inputLabel(false,$amount.' грн.', 'Cумма:')));
$form->addFieldForm($form->_hr());
$form->addFieldForm($form->_group($form->_button()));
