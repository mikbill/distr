<?php

/**
 * Устанавливаем соединение с БД
 *
 * @param $configFilePath
 *
 * @return mysqli
 */
function connectToDB($configFilePath)
{
	if (file_exists($configFilePath) AND is_readable($configFilePath)) {
		$xml = simplexml_load_file($configFilePath);

		$CONF_MYSQL_HOST = (string) $xml->parameters->mysql->host;
		$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
		$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
		$CONF_MYSQL_DBNAME = (string) $xml->parameters->mysql->dbname;
	} else {
		die('Нет файла конфига или он нечитаем.');
	}
	$link = new mysqli($CONF_MYSQL_HOST, $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD, $CONF_MYSQL_DBNAME);

	if ($link->connect_error) {
		echo 'Connect Error (' . $link->connect_errno . ') ' . $link->connect_error;
		die();
	}

	return $link;
}

function billingInitSystemOptions(&$link, $condition = '')
{
	$result = array();

	if ($condition != '') {
		#$condition = 'WHERE ' . addslashes($condition);
		$condition = 'WHERE ' . $condition;
	}

	$query = "SELECT * FROM `" . BILL_SYSTEM_OPTIONS_TABLE . "` $condition;";
	//print $query;
	$resultTmp = getAllBySQL($query, $link, 'koi8-r');

	foreach ($resultTmp as $row) {
		$result[$row['key']] = $row['value'];
	}

	return $result;
}

function billingInitSystemOptionsByKey(&$link, $keyCondition)
{
	$condition = "`key` LIKE '$keyCondition'";

	$result = billingInitSystemOptions($link, $condition);

	return $result;
}

function getAllBySQL($query, mysqli &$link, $iconv = '')
{
	$rows = array();

	$result = $link->query($query);

	if ($result->num_rows != 0) {
		while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
			$rows[] = $row;
		}

		# если указана кодировка, то изменяем её
		if ($iconv != '') {
			foreach ($rows as $k => $row) {
				foreach ($row as $k2 => $attr) {
					$row[$k2] = iconv($iconv, 'utf-8', $attr);
				}

				$rows[$k] = $row;
			}
		}
	}

	$result->free();

	return $rows;
}

/**
 * Формируем страницу контентом и заголовком страницы
 *
 * @param $response
 * @param $title
 *
 * @return string
 */
function setResponse($response, $title = 'Пополнение счёта')
{
	return '<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>' . $title . '</title>
</head>
<body>
	<table align="center" height="100%">
		<tr><td valign="middle" align="center">
		' . $response . '
		</td></tr>
	</table>
</body></html>';
}

/**
 * Получаем данные абонента из POST
 *
 * @return array
 */
function getUserDataFromPOST()
{
	$user = array(
		'fio'   => '',
		'email' => '',
	);

	# UID
	if (isset($_POST['uid'])) {
		$user['uid'] = intval($_POST['uid']);
	} elseif (isset($_GET['uid'])) {
		$user['uid'] = intval($_GET['uid']);
	} else {
		die('User not defined');
	}

	# ФИО
	if (isset($_POST['fio'])) {
		$user['fio'] = $_POST['fio'];
	} elseif (isset($_GET['fio'])) {
		$user['fio'] = $_GET['fio'];
	}

	# e-mail
	if (isset($_POST['email'])) {
		$user['email'] = $_POST['email'];
	} elseif (isset($_GET['email'])) {
		$user['email'] = $_GET['email'];
	}

	# phone
	if (isset($_POST['phone'])) {
		$user['phone'] = $_POST['phone'];
	} elseif (isset($_GET['phone'])) {
		$user['phone'] = $_GET['phone'];
	}

	return $user;
}

function getUser(mysqli &$LINK, $uid, $tables = array(
	1,
	2
))
{

	$result = false;

	$usersTables = array(
		1 => 'users',
		2 => 'usersfreeze',
		3 => 'usersblok',
		4 => 'usersdel'
	);

	foreach ($tables as $tableID) {
		$query = 'SELECT `uid`, `deposit`, `fio`, `user` FROM ' . $usersTables[$tableID] . ' WHERE `uid` = ' . $uid . ';';

		$result = getAllBySQL($query, $LINK);

		if (!empty($result)) {
			break;
		}
	}

	return $result;
}

function startTransaction(mysqli $LINK, $user, $amount, $table, $columnDate = 'server_time', $columnAmount = 'amount')
{
	# занести запись в платежи
	$query = "INSERT INTO  `$table`( uid , " . $columnAmount . ", " . $columnDate . ") VALUES ( " . $LINK->escape_string($user['uid']) . ", '" . $LINK->escape_string($amount) . "', NOW());";
	$LINK->query($query);

	if ($LINK->errno) {
		#SQLFail($LINK, $query); # debug
		SQLFail($LINK);
		die();
	}

	return $LINK->insert_id;
}

function SQLFail($link, $query = '')
{
	echo 'SQL ERROR: STATE ' . $link->sqlstate . ' (' . $link->errno . ') ' . $link->error . "<br />\n$query";
}

/**
 * Добавляет абоненту баланс
 *
 * @param        $uid
 * @param        $amount
 * @param mysqli $LINK
 * @param        $systemOptions
 * @param        $bughtypeid
 * @param array  $tables
 */
function addUserBalance($uid, $amount, mysqli &$LINK, &$systemOptions, $bughtypeid, $tables = array(
	1,
	2
))
{
	$usersTables = array(
		1 => 'users',
		2 => 'usersfreeze',
		3 => 'usersblok',
		4 => 'usersdel'
	);

	foreach ($tables as $tableID) {
		$query = 'SELECT `uid`, `deposit`, `local_mac` FROM ' . $usersTables[$tableID] . ' WHERE `uid` = ' . $uid . ';';

		$result = getAllBySQL($query, $LINK);

		if (!empty($result)) {
			$deposit = $result[0]['deposit'];
			$mac = $result[0]['local_mac'];
			# увеличиваем депозит абонента
			$query = 'UPDATE `' . $usersTables[$tableID] . '` SET `deposit` = `deposit` + ' . $amount . ' WHERE `uid` = ' . $uid . ';';
			$LINK->query($query);

			# занести запись в логи платежей
			$query = "INSERT INTO `bugh_plategi_stat` ( uid , date , who , bughtypeid , before_billing , summa , comment ) VALUES ( $uid , NOW(), NULL, $bughtypeid, $deposit , $amount, '' );";
			$LINK->query($query);
			# @TODO всяко разно

			$script_dir = './sys/scripts/mb_after_pay.sh ';
			# вызываем скрипт после пополнения счёта из админки
			$execCommand = $systemOptions['sudo'] . ' ' . $script_dir . ' ' . $uid . ' ' . $mac;
			exec($execCommand);

			break;
		}
	}
}

function getPostParam($param, $default = null)
{
	if (isset($_POST[$param])) {
		return $_POST[$param];
	} elseif (isset($_GET[$param])) {
		return $_GET[$param];
	} else {
		return $default;
	}
}

function xmlParser($input_xml)
{
	$xml = simplexml_load_string($input_xml);
	$json = json_encode($xml);
	$result = json_decode($json, true);

	return $result;
}

/**
 * Округляет/преобразует строковое значение $sum в тип float с 2-я знаками после запятой.
 *
 * @param string $sum
 * @return float
 */
function to_float($sum)
{
	$sum = round(floatval($sum), 2);
	$sum = sprintf('%01.2f', $sum);

	if (substr($sum, -1) == '0') {
		$sum = sprintf('%01.1f', $sum);
	}

	return $sum;
}