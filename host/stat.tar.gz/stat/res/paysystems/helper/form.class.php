<?php

class formClass
{
	private $_charsetHeader = 'utf-8';


	public $_field = '';
    public $_nameSystem = 'Unknow';
    public $_formUrl = '';
    public $_formMethod = 'POST';

    public $_fullForm = false;

	public $_namePage = 'Оплата';
	public $_pathTempate = 'data/template/olson';


    public function setLabelForm($name = 'Unknow')
    {
        $this->_nameSystem = $name;
    }

    public function setUrlForm($url = '')
    {
        $this->_formUrl = $url;
    }

    public function setMethodForm($method = 'POST')
    {
        $this->_formMethod = $method;
    }

    public function addFieldForm($formElement)
    {
        $this->_field .= $formElement;
    }


    public function _input($nameInput, $valueInput, $type = 'hidden')
    {

        $inputHideField =  '
        <input class="form-control" type="'.$type.'" name="'.$nameInput.'" value="'. $valueInput .'" /> ';

        return $inputHideField;
    }


    public function _button($label='Оплатить', $class = 'btn btn-primary btn-block', $type='submit')
    {

        $button  =  '<button type="'.$type.'" class="'.$class.'">'.$label.'</button>';
        return $button;
    }

    public function _selectLabel($nameInput = false, $optionArray = array() , $nameLabel= '' , $readonly = true, $colLabelSize = 4, $colInputSize = 8)
    {
        $option = '';

        if($nameInput){
            $name = ' name="'.$nameInput.'" ';
        }else {
            $name = '';
        }

        if ($readonly){
            $readonly = 'readonly';
        }else{
            $readonly = '';
        }
        foreach($optionArray as  $value => $label){
            $option .= '
            <option  value="'.$value.'">'.$label.'</option>';
        }


        $select='
             <label class="col-lg-'.$colLabelSize.' control-label " >'.$nameLabel. '</label>

            <div class="col-lg-'.$colInputSize.'">
                <select class="form-control" '.$name.' '.$readonly.'>
                    '.$option.'
                </select>
            </div>';

        return $select;
    }

    public function _inputLabel($nameInput = false, $valueInput = '', $nameLabel= '' , $readonly = true, $colLabelSize = 4, $colInputSize = 8){

        if($nameInput){
            $name = ' name="'.$nameInput.'" ';
        }else{
            $name = '';
        }

        if ($readonly){
            $readonly = 'readonly';
        }else{
            $readonly = '';
        }

        $inputShowField = '
                <label class="col-lg-'.$colLabelSize.' control-label text-left">'.$nameLabel. '</label>
                <div class="col-lg-'.$colInputSize.'">
                    <input type="text" class="form-control" '.$name.' value="'.$valueInput.'" '.$readonly.' >
                </div>';

        return $inputShowField;
    }

    public function _hr(){
        $hr = '
        <hr/> ';
        return $hr;
    }

    public function _h($input, $size= 3){
        $h = '
        <h'.$size.'>'.$input.'</h'.$size.'> ';
        return $h;
    }

    public function _group($formElement){

        $formGroup = '
        <div class="form-group">
            <div class="col-lg-12">
                '.$formElement.'
            </div>
        </div>';

        return $formGroup;
    }

	public function getForm(){


        if($this->_fullForm){
            $body = $this->_fullForm;
        }else{
            $body = '
                <div class="page-content blocky">
                    <div class="container">

                        <div class="row">
                            <div class="col-md-12">
                                <div class="awidget login-reg">
                                    <div class="awidget-head">

                                    </div>
                                    <div class="awidget-body">
                                        <!-- Page title -->
                                        <div class="page-title text-center">
                                            <h2>'.$this->_nameSystem.'</h2>
                                            <hr/>
                                        </div>
                                        <!-- Page title -->

                                        <div class="row setup-content" id="step-1">
                                            <div class="col-xs-12">
                                                <div class="col-md-12 well text-center">
                                                    <form class="form-horizontal" role="form" action="'.$this->_formUrl.'" method="'.$this->_formMethod.'">
                                                        '.$this->_field.'
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ';
        }

        $tempate = '
            <!DOCTYPE html>
            <html>
            <head>
                <!-- Title here -->
                <title>'.$this->_namePage.'</title>
                <!-- Description, Keywords and Author -->
                <meta charset="'.$this->_charsetHeader.'">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">

                <!-- Styles -->
                <!-- Bootstrap CSS -->
                <link href="'.$this->_pathTempate.'/css/bootstrap.min.css" rel="stylesheet">

                <!-- Font awesome CSS -->
                <link href="'.$this->_pathTempate.'/css/font-awesome.min.css" rel="stylesheet">

                <!-- Custom CSS -->
                <link href="'.$this->_pathTempate.'/css/style.css" rel="stylesheet">

                <!-- Favicon -->
                <link rel="shortcut icon" href="#">
            </head>

            <body>
                '.$body.'
            </body>
            </html>';

		return $tempate;
	}
}
