<?php
if (isset($_POST['uid'])){
	$uid = $_POST['uid'];
}else{
	die();
}

define ( "BILL_SYSTEM_OPTIONS_TABLE", "system_options" );
define ( "BILL_PRIVAT24_TABLE", "addons_privat24" );

if (isset($_POST['summa'])){
	$summa = $_POST['summa'];
}else{
	$summa=100;
}
if (isset($_POST['fio'])){
	$fio = $_POST['fio'];
}else{
	$fio = "";
}


$config_file='./app/etc/config.xml';

if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
} else {
	die();
}

$LINK = mysql_connect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK );

if (!mysql_ping($LINK)){
	die();
}

function billing_init_system_options($LINK)
{
$result = mysql_query ( "SELECT * FROM ".BILL_SYSTEM_OPTIONS_TABLE." WHERE 1 ", $LINK ) or die();
	$options= array();
	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$options[$res['key']]=$res['value'];
	}
	mysql_free_result($result);
	return $options;
}

$sys_options = billing_init_system_options($LINK);


$merchant_id = $sys_options['privat24_merchantid'];
$merc_sign = $sys_options['privat24_sign'];

$curency =  $sys_options['privat24_ccy'];
$url_result = $sys_options['privat24_server_url'];
$url_server = $sys_options['privat24_return_url'];
$procent = $sys_options['privat24_procent']; 

$fio2 =  $uid;
$description = $uid;


$result = mysql_query ( "INSERT INTO " . BILL_PRIVAT24_TABLE . "  (`order_id` ,`order_date` ,`merchant_id` ,`currency` ,`uid` ,`amount` ,`details` ,`status` ,`transaction_id` ,`pay_way` ,`sender_phone` ) VALUES (NULL, CURRENT_TIMESTAMP,'".$merchant_id."', '".$curency."', '".$uid."', '".$summa."', '".$uid."', '', '', 'privat24', ''); ", $LINK ) or die(mysql_error($LINK));

$tranzakt_privat24_id = mysql_insert_id();

$url="https://api.privatbank.ua/p24api/ishop";

$text=iconv ("CP1251","UTF-8","��������� ���� �� �����: ".$summa." ".$curency);
$text2=iconv ("CP1251","UTF-8","���������");
$title=iconv ("CP1251","UTF-8","���������� ������24");
$text3=iconv ("CP1251","UTF-8","�������� � ");
#$fio=iconv ("CP1251","UTF-8",$fio);
if (mb_detect_encoding($fio, 'UTF-8', true) === FALSE) {
 $fio=iconv ("CP1251","UTF-8",$fio);
}

if ($procent!=0){
	$summa=$summa*($procent+100)/100;
}

echo("
<html lang=\"en\">
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<title>".$title."</title>
</head>
<body scroll=\"no\" >
<center>
</br>
".$title."</br>
</br>
".$fio."</br>
</br>
".$text."</br>
</br>
<form method='POST' action='$url'>
<input type='hidden' name='amt' value='$summa' />
<input type='hidden' name='ccy' value='$curency' />
<input type='hidden' name='merchant' value='$merchant_id' />
<input type='hidden' name='order' value='$tranzakt_privat24_id' />
<input type='hidden' name='details' value='internet $uid' />
<input type='hidden' name='ext_details' value='' />
<input type='hidden' name='pay_way' value='privat24' />
<input type='hidden' name='return_url' value='$url_server' />
<input type='hidden' name='server_url' value='$url_result' />
<button type='submit'><h2>$text3</h2><img src='/res/api_logo_1.jpg' border='0' /></button>
</form>
</center>
</body></html>");
mysql_close($LINK);