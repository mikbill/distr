#!/bin/sh

OS=`uname`
PHP=`which php`

if [ "$OS" == "Linux" ]; then
#for linux
cd /var/www/mikbill/admin/
else
#for BSD
cd /usr/local/www/mikbill/admin/
fi

$PHP ./index.php changetarifuser $1 $2 $3

