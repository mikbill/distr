<?php

/**
 * @MikBill
 * @MikBill PSCB payment
 * @version 1.2
 * @http://www.mikbill.ru/
 * @copyright Copyright (C) 2014. All rights reserved.
 */


$config_file='./app/etc/config.xml';
define ( "BILL_SYSTEM_OPTIONS_TABLE", "system_options" );
define ( "BILL_PSCB_TABLE", "addons_pscb" );

// Для изменения текста страницы 
define ( "TITLE", "Пополнение PSCB" );
define ( "TEXT0", "Оплата интернета" );
define ( "TEXT1", "Пополнить счет на сумму: " );
define ( "TEXT2", "Оплатить " );


if (isset($_POST['uid'])){
	$uid = $_POST['uid'];
}else{
	die();
}


if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
} else {
	die();
}

$LINK = mysql_connect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK );

if (!mysql_ping($LINK)){
	die();
}

function billing_init_system_options($LINK)
{
	$result = mysql_query ( "SELECT * FROM ".BILL_SYSTEM_OPTIONS_TABLE." WHERE 1 ", $LINK ) or die();
	$options= array();
	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$options[$res['key']]=$res['value'];
	}
	mysql_free_result($result);
	return $options;
}

function get_url_payment($mode)
{
	$url = '';
	if ($mode == 0) {
		// Рабочий URL
		$url = "https://oos.pscb.ru/pay/";
	} else {
		// Тестовый URL
		$url = "https://oosdemo.pscb.ru/pay/";
	}
	return $url;
}


$sys_options = billing_init_system_options($LINK);

// Проверка: -Активна ли PSCB в системных опциях админки
if (isset($sys_options['pscb_on']) && ($sys_options['pscb_on'] == 1)) {
	if (isset($_POST['summa']) && $_POST['summa'] > 0) {
		$amount = round($_POST['summa'], 2);
	} else {
		$amount = 100;
	}

	if (isset($_POST['fio'])) {
		$fio = $_POST['fio'];
	} else {
		$fio = "";
	}
	
	$test_mode 	= isset($sys_options['pscb_test']) ? $sys_options['pscb_test'] : 0;	
	$result 	= mysql_query("INSERT INTO `".BILL_PSCB_TABLE."` (`order_id`, `order_date`, `uid`, `amount` , `status`) VALUES (NULL, CURRENT_TIMESTAMP, '".$uid."', '".$amount."', '0');", $LINK) or die(mysql_error($LINK));
	$order_id 	= mysql_insert_id();
	
	// Параметры вызова платежной страницы OOS PSCB
	$merchant_key	 = $sys_options['pscb_MrchKey'];
	$market_place_id = $sys_options['pscb_marketPlace'];
	$url_payment     = get_url_payment($test_mode);
	$message = array(
		"details" => TEXT0 ,
		"amount" => $amount,
		"customerRating" => "5",
		"customerAccount" => $uid,
		"orderId" => $order_id
	);	

	$messageText = json_encode($message);
	$http_params = array(
		"marketPlace" => $market_place_id,
		"message" => base64_encode($messageText),
		"signature" => hash('sha256', $messageText . $merchant_key)
	);
	
	$text = TEXT1.$amount; 
	
	$outtext = "
		<html lang=\"en\">
			<head>
				<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
				<title>".TITLE."</title>
			</head>
			<body scroll=\"no\" >
				<center>
				</br>
				".TITLE."</br>
				</br>
				".$fio."</br>
				</br>
				".$text."</br>
				</br>
				<form method='POST' action=".$url_payment.">
					<input type='hidden' name='marketPlace' value=".$http_params['marketPlace']." />
					<input type='hidden' name='message' value=".$http_params['message']." />
					<input type='hidden' name='signature' value=".$http_params['signature']." />
										
					<button type='submit'><h2>".TEXT2."</h2><img src='/res/logo/pscb_logo.png' border='0' /></button>
				</form>
				</center>
			</body>
		</html>";
	
}
else{
$outtext = "
			<html lang=\"en\">
				<head>
					<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
				</head>
				<body scroll=\"no\" >
					<center>
						Извините, платежная система PSCB не подключена.
					</center>
				</body>
			</html>";
}

echo $outtext;
mysql_close($LINK);

?>
