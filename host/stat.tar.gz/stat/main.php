<?php

ini_set('display_errors',1);
ini_set('ignore_repeated_errors', '0');
ini_set('display_startup_errors', '0');
set_error_handler('err_handler_stathtml');
error_reporting(E_ERROR);

include_once('./data/lib/SystemsClass.php');
include_once('./data/lib/CabinetClass.php');
include_once('./data/lib/TemplateClass.php');
include_once('./data/lib/LangDetectClass.php');
include_once('./data/lib/gettext.inc');

/**
 * Слабый обработчик ошибок для сайта
 *
 * @param $errno
 * @param $errmsg
 * @param $filename
 * @param $linenum
 */
function err_handler_stathtml($errno, $errmsg, $filename, $linenum)
{
	$date = date('Y-m-d H:i:s (T)');

	$err = "$date\r\n";
	$err .= "$errmsg\r\n";
	$err .= "$filename\r\n";
	$err .= "on line: $linenum\r\n";
	$err .= "\r\n\r\n";

	file_put_contents('./app/log/html5.log', $err, FILE_APPEND);
}

# Текущий URL кабинета
if(isset($_SERVER['HTTPS'])  AND $_SERVER['HTTPS'] <> ''){
	$urlHost = "https://".$_SERVER['HTTP_HOST'];
}else{
	$urlHost = "http://".$_SERVER['HTTP_HOST'];
}

# Создали экземпляр класса SystemClass
$systemClass = new SystemsClass();

# Получаем массив с полными путями для запросов к бекенду
$billLink = $systemClass->getBillLink($urlHost);

# Получаем входные Get/Post
$paramsInput = $systemClass->get_input_data();

# Создали экземпляр класса CabinetClass
$cabinetClass = new CabinetClass($billLink, $paramsInput);

# Выбор локализации:
setLanguage($cabinetClass->_attributesOut);

# Start обработчика запроса и информации
$cabinetClass->proceedRequest();

# Страница которую необходимо вывести на экран
$page = $cabinetClass->_outPage;
$module = $cabinetClass->_module;

# Вывод шаблона
$tpl = new TemplateClass($cabinetClass->_attributesOut['config']['path_template']);
$tpl->set('val', $cabinetClass->attributesArrayOut());
$tpl->display($page, $module);

