﻿<?php
$error_text='ERROR';


if (isset($_POST['uid'])){
	$uid = $_POST['uid'];
}else{
	die($error_text);
}

if (!is_numeric($uid)){
	die($error_text);
}

if (isset($_POST['phone'])){
	$phone = $_POST['phone'];
}else{
	die($error_text);
}

if (!is_numeric($phone)){
	die($error_text);
}

if (isset($_POST['summa'])){
	$summa = $_POST['summa'];
}else{
	$summa=100;
}

if (!is_numeric($summa)){
	die($error_text);
}

define ( "BILL_SYSTEM_OPTIONS_TABLE", "system_options" );
define ( "BILL_WQIWIRU_TABLE", "addons_wqiwiru" );

$config_file='./app/etc/config.xml';

if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
} else {
	die($error_text);
}

$LINK = mysql_connect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK );

if (!mysql_ping($LINK)){
	die($error_text);
}

function billing_init_system_options($LINK)
{
$result = mysql_query ( "SELECT * FROM ".BILL_SYSTEM_OPTIONS_TABLE." WHERE 1 ", $LINK ) or die();
	$options= array();
	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$options[$res['key']]=$res['value'];
	}
	mysql_free_result($result);
	return $options;
}

$sys_options = billing_init_system_options($LINK);
if (isset($sys_options['wqiwiru_shop_id'])){
$wqiwiru_shop_id=$sys_options['wqiwiru_shop_id'];
}else{
	die($error_text);
}
mysql_query ( "INSERT INTO " . BILL_WQIWIRU_TABLE . " (`prv_txn`, `status`, `uid`, `sum`, `time_stamp`) VALUES (NULL, 0, '".$uid."', '".$summa."',  CURRENT_TIMESTAMP ); ", $LINK ) or die(mysql_error($LINK));

$tranzakt_wqiwiru_id = mysql_insert_id();
mysql_close($LINK);

$url='http://w.qiwi.ru/setInetBill_utf.do?from='.$wqiwiru_shop_id.'&to='.$phone.'&summ='.$summa.'&txn_id='.$tranzakt_wqiwiru_id.'&com=uid='.$uid;

header("Location: ".$url);
exit;


