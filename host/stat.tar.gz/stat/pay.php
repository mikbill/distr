<?php
header('Content-type: text/html; charset=UTF-8');
/**
 * @author NickCool
 * @about  файл для уменьшения количества файлов платёжных систем в корне папки
 */

# сокращаем DS
define('DS', DIRECTORY_SEPARATOR);
define('BILL_SYSTEM_OPTIONS_TABLE', 'system_options');
# путь к платёжным системам
$pathToPS = '.' . DS . 'res' . DS . 'paysystems' . DS;
# вспомогательные ф-ии
include_once($pathToPS . 'helper' . DS . 'functions.php');
include_once($pathToPS . 'helper' . DS . 'form.class.php');

# файл-конфиг соединения с БД
$configFilePath = './app/etc/config.xml';

# необходимо задать в обработчиках ПС
$title = 'ISP - пополнение счёта';
$response = 'Error! Платёжная система не выбрана!';

# NEW!!! инициализируем класс формы.
$form = new formClass();

# получаем необходимые данные для оплаты
# данные абонента
$user = getUserDataFromPOST();

# сумма платежа
$amount = round(getPostParam('amount', 100), 2);

/*
# для отладки
$amount = 10;
$amount = round($amount, 2);
$user['uid'] = 1;
$user['email'] = 'simple@e.mail';
*/

if (isset($_GET['system']) AND !empty($_GET['system'])) {
	$file = 'default.php';
	$systemName = $_GET['system'];
	# получаем сис. опции и проверяем, включены ли системы
	# соединение с БД
	$LINK = connectToDB($configFilePath);
	if (!$LINK->ping()) {
		die('Connection with DB lost.');
	}

	switch ($systemName) {
		# https://stripe.com - Stripe
		case 'stripe':
			# для Stripe нужны все сис. опции
			$systemOptions = billingInitSystemOptions($LINK);

			# заменяем символ из сис. опций на символ Евро
			$systemOptions['stripe_currency_symbol'] = '€';

			if (isset($systemOptions['stripe_on'], $systemOptions['stripe_secret_key'], $systemOptions['stripe_publishable_key'], $systemOptions['stripe_currency']) AND $systemOptions['stripe_on'] == 1) {
				# действие по умолчанию
				$file = 'form.php';

				if (isset($_GET['act'])) {
					switch ($_GET['act']) {
						# оплата
						case 'pay':
							if (isset($_POST['stripeToken'])) {
								$file = 'charge.php';
							}
							break;
					}
				}
			}
			break;

		case 'paykeeper':
			$systemOptions = billingInitSystemOptionsByKey($LINK, 'paykeeper_%');

			if (isset($systemOptions['paykeeper_on']) && $systemOptions['paykeeper_on'] == 1 && !empty($systemOptions['paykeeper_urlpay'])) {
				$file = 'index.php';
			}
			break;

		case 'ukrpays':
			$systemOptions = billingInitSystemOptionsByKey($LINK, 'ukrpays_%');

			if (isset($systemOptions['ukrpays_on']) && $systemOptions['ukrpays_on'] == 1 && isset($systemOptions['ukrpays_service_id']) && !empty($systemOptions['ukrpays_urlpay'])) {
				$file = 'index.php';
			}
			break;

		case 'paypal':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');

			if (isset($systemOptions['paypal_on'], $systemOptions['paypal_merchant'], $systemOptions['paypal_currency']) AND $systemOptions['paypal_on'] == 1 AND trim($systemOptions['paypal_merchant']) != '' AND trim($systemOptions['paypal_currency']) != '') {
				$file = 'index.php';
			}
			break;

		case 'uniteller':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;

		case 'oplata':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;

		case 'yandex':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;

		case 'portmone':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;

		case 'ipay':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;

		case 'robokassa':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;

		case 'sberbankrumrch':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;

		case 'liqpay':
			$systemOptions = billingInitSystemOptions($LINK);
			if (isset($systemOptions['do_liqpay_terminal'])) {
				$file = 'index.php';
			}
			break;

		case 'onpay':
			$systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '%');
			if (isset($systemOptions['do_onpay_terminal'])) {
				$file = 'index.php';
			}
			break;

		case 'privat24':
			$systemOptions = billingInitSystemOptionsByKey($LINK, '%' . $systemName . '%');
			if (isset($systemOptions['do_privat24_terminal'])) {
				$file = 'index.php';
			}
			break;

		case 'pscb':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;

		case 'paymaster':
			$systemOptions = billingInitSystemOptionsByKey($LINK, $systemName . '_%');
			if (isset($systemOptions[$systemName . '_on'])) {
				$file = 'index.php';
			}
			break;
	}
	# выполняем указанный файл
	if ($file == 'default.php') {
		include_once($pathToPS . $file);
	} else {
		include_once($pathToPS . $systemName . DS . $file);
	}

	# закрываем соединение с БД
	$LINK->close();
}

//Старые ПС
$oldPS = array(
	'stripe',
	'paykeeper',
	'paypal',
	'oplata'
);


# выводим отформатированный ответ
if (in_array($systemName, $oldPS)) {

	# Старая форма
	echo setResponse($response, $title);
} else {

	# Новый класс формы
	echo $form->getForm();
}
