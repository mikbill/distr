<?

$text = 'Ooops! Something wrong.';

if (isset($_REQUEST['act'])) {
	$text = "<html lang=\"en\">
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
</head>
<body scroll=\"no\" >
<center>";

	switch ($_REQUEST['act']) {
		case 2:
			$text .= "Платёж успешно осуществлён";
			break;
		case 3:
			$text .= "Вы отказались от платежа";
			break;
	}

	$text .= "</center>
</body></html>";
}

echo $text;