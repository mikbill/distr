<?php

if (isset($_POST['uid']) && is_numeric($_POST['uid'])) {
	$uid = $_POST['uid'];
} else {
	die();
}

$config_file = './app/etc/config.xml';

if (file_exists($config_file)) {
	$xml = simplexml_load_file($config_file);
	$CONF_MYSQL_HOST = (string)$xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string)$xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string)$xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME = (string)$xml->parameters->mysql->dbname;
} else {
	die();
}

define ("BILL_SYSTEM_OPTIONS_TABLE", "system_options");
define ("BILL_ROBOKASSA_TABLE", "addons_robokassa");

$LINK = mysql_connect($CONF_MYSQL_HOST, $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD);
mysql_select_db($CONF_MYSQL_DBNAME, $LINK);

if (!mysql_ping($LINK)) {
	die();
}

function billing_init_system_options($LINK)
{
	$result = mysql_query("SELECT `key`, `value` FROM ".BILL_SYSTEM_OPTIONS_TABLE." WHERE `key` LIKE 'robokassa_%'", $LINK) or die();
	$options = array();
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
		$res = mysql_fetch_array($result);
		$options[$res['key']] = $res['value'];
	}
	mysql_free_result($result);
	return $options;
}

$sys_options = billing_init_system_options($LINK);


// Проверяем, включена ли robokassa в системных опциях
if (isset($sys_options['robokassa_on']) && ($sys_options['robokassa_on'] == 1)) {
	if (isset($_POST['summa']) && is_numeric($_POST['summa']) && $_POST['summa'] > 0) {
		$amount = round($_POST['summa'], 2);
	} else {
		$amount = 100;
	}

	if (isset($_POST['fio'])) {
		$fio = $_POST['fio'];
	} else {
		$fio = "";
	}

	$mrh_login = $sys_options['robokassa_MrchLogin'];
	$mrh_pass1 = $sys_options['robokassa_mrh_pass1'];
	$mrh_pass2 = $sys_options['robokassa_mrh_pass2'];
	$test_mode = isset($sys_options['robokassa_test']) ? $sys_options['robokassa_test'] : 0;
	$language = isset($sys_options['robokassa_language']) ? $sys_options['robokassa_language'] : '';

	$result = mysql_query("INSERT INTO `".BILL_ROBOKASSA_TABLE."` (`order_id`, `order_date`, `uid`, `amount` , `status`) VALUES (NULL, CURRENT_TIMESTAMP, '$uid', '$amount', '0');", $LINK) or die(mysql_error($LINK));
	$order_id = mysql_insert_id();
	$encoding = "UTF-8";

	$text = "Пополнить счет на сумму: ".$amount;
	$text3 = "Оплатить в ";
	$title = "Пополнение ROBOKASSA";

#$fio=iconv ("CP1251","UTF-8",$fio);

//if (mb_detect_encoding($fio, 'UTF-8', true) === FALSE) {
//	$fio = iconv("CP1251", "UTF-8", $fio);
//}

	// Генерируем ChechSum
	$crc = md5("$mrh_login:$amount:$order_id:$mrh_pass1:shp_uid=$uid");

	if ($test_mode == 0) {
		$url = "https://merchant.roboxchange.com/Index.aspx";
	} else {
	// Тестовый URL
		$url = "http://test.robokassa.ru/Index.aspx";
	}

	$outtext = "
<html lang=\"en\">
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<title>".$title."</title>
</head>
<body scroll=\"no\" >
<center>
</br>
".$title."</br>
</br>
".$fio."</br>
</br>
".$text."</br>
</br>
<form method='POST' action='$url'>
<input type='hidden' name='MrchLogin' value='$mrh_login' />
<input type='hidden' name='OutSum' value='$amount' />
<input type='hidden' name='InvId' value='$order_id' />
<input type='hidden' name='shp_uid' value='$uid' />
<input type='hidden' name='Desc' value='internet $uid' />
<input type='hidden' name='SignatureValue' value='$crc' />
<input type='hidden' name='Encoding' value='$encoding' />
<input type='hidden' name='Culture' value='$language' />
<button type='submit'><h2>$text3</h2><img src='/res/robokassa_logo.jpg' border='0' /></button>
</form>
</center>
</body></html>";
} else {
	$outtext = "
<html lang=\"en\">
<head>
<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
</head>
<body scroll=\"no\" >
<center>
Извините, платежная система не подключена
</center>
</body></html>";
}

echo $outtext;
mysql_close($LINK);