<?php

/**
 * @MikBill
 * @MikBill PayMaster.ua payment
 * @version 1.0
 * @http://www.mikbill.ru/
 * @copyright Copyright (C) 2014. All rights reserved.
 */


$config_file='./app/etc/config.xml';
define ( "BILL_SYSTEM_OPTIONS_TABLE", "system_options" );
define ( "BILL_PAYMASTER_TABLE", "addons_paymaster" );

// Для изменения текста страницы 
define ( "TITLE", "Пополнение PayMaster" );
define ( "TEXT1", "Пополнить счет на сумму: " );
define ( "TEXT2", "Оплатить " );

$url_payment= 'https://lmi.paymaster.ua/';
$text_desc= 'Оплата интернета';

if (isset($_POST['uid'])){
	$uid = $_POST['uid'];
}else{
	die();
}

# конфиг соединения с БД
if (file_exists($config_file) ) {
	$xml = simplexml_load_file($config_file);
	$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
} else {
	die();
}

$LINK = mysql_connect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK );

if (!mysql_ping($LINK)){
	die();
}

function billing_init_system_options($LINK)
{
	$query_init = "SELECT * FROM ".BILL_SYSTEM_OPTIONS_TABLE." WHERE 1 ";
	$result = mysql_query ( $query_init, $LINK ) or die();
	$options= array();
	for ($i = 0; $i < mysql_num_rows ($result); $i++) {
		$res = mysql_fetch_array ( $result );
		$options[$res['key']]=$res['value'];
	}
	mysql_free_result($result);
	return $options;
}


$sys_options = billing_init_system_options($LINK);

// Проверка: -Активна ли PayMaster в системных опциях админки
if (isset($sys_options['paymaster_on']) && ($sys_options['paymaster_on'] == 1)) {
	if (isset($_POST['summa']) && $_POST['summa'] > 0) {
		$amount = round($_POST['summa'], 2);
	} else {
		$amount = 100;
	}

	if (isset($_POST['fio'])) {
		$fio = $_POST['fio'];
	} else {
		$fio = "";
	}
	
	// TEST-MODE
	if (isset($sys_options['paymaster_test']) ? $sys_options['paymaster_test'] : 0) {
		$test_mode = "<input type='hidden' name='LMI_SIM_MODE' value='0' />";
	}
	else{
		$test_mode = "";
	}
		
	$query_insert = "INSERT INTO `".BILL_PAYMASTER_TABLE."` (`order_id`, `order_date`, `uid`, `payment_system`, `amount` , `status`) VALUES (NULL, CURRENT_TIMESTAMP, '".$uid."', '0', '".$amount."', '0')";
	$result 	= mysql_query($query_insert, $LINK) or die(mysql_error($LINK));
	$order_id 	= mysql_insert_id();
			
	$text = TEXT1.$amount; 
			
	$outtext = "
		<html lang=\"en\">
			<head>
				<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
				<title>".TITLE."</title>
			</head>
			<body scroll=\"no\" >
				<center>
				</br>
				".TITLE."</br>
				</br>
				".$fio."</br>
				</br>
				".$text."</br>
				</br>
				<form method='POST' action=".$url_payment.">
					<input type='hidden' name='LMI_MERCHANT_ID' value=".$sys_options['paymaster_MrchID']." />
					<input type='hidden' name='LMI_PAYMENT_AMOUNT' value=".$amount." />
					<input type='hidden' name='LMI_PAYMENT_NO' value=".$order_id." />
					<input type='hidden' name='LMI_PAYMENT_DESC' value=".$text_desc." />
					".$test_mode."
					<button type='submit'><h2>".TEXT2."</h2><img src='/res/paymaster_logo_green.png' border='0' /></button>
				</form>
				</center>
			</body>
		</html>";
	
}
else{
$outtext = "
			<html lang=\"en\">
				<head>
					<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
				</head>
				<body scroll=\"no\" >
					<center>
						Извините, платежная система PayMaster не подключена.
					</center>
				</body>
			</html>";
}

echo $outtext;
mysql_close($LINK);

?>
