<?php
header("Location: index.html");
die();
