<?php

	
	define ("OLD_PAKETS","rm_services");
	define ("OLD_USERS","rm_users");	
	define ("OLD_CARDS","rm_cards");	
	define ("OLD_PASS","radcheck");
	
	define ("BILL_CARDS_TABLE","mod_cards_cards");
	define ("BILL_AUTH_TABLE","users");	
	define ("BILL_NAS_TABLE", "radnas" );
	define ("BILL_NASLOG_TABLE", "radnaslog" );
	define ("BILL_SYSPOTS_TABLE", "sysopts" );
	define ("BILL_PACKET_TABLE", "packets" );	
	define ("BILL_MIGRATE_TABLE", "migratenodeny" );
	
	$config_file='../../app/etc/config.xml';

	if (file_exists($config_file)) {
		$xml = simplexml_load_file($config_file);
		$CONF_LOG  = (string) $xml->parameters->kernel->log;
		$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
		$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
		$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
		$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;

	} else {
		die("config not found");
	}

	function open_logs($CONF_LOG)
	{
		return 	fopen($CONF_LOG, "a");
	}

	$stdlog = open_logs($CONF_LOG);


	function do_log($stdlog,$text_log)
	{
		fputs($stdlog, get_date()." ".$text_log."\n");
	}

	function do_log_sql($stdlog,$text_log,&$LINK)
	{
		if (!mysql_ping($GLOBALS["LINK"]))
		{
			$do_mysql_reconect=1;
			fputs($stdlog, get_date()." MySQL Connect failed"."\n");
		}else{
			fputs($stdlog, get_date()." ".$text_log."\n");
		}

		while ($do_mysql_reconect==1)
		{
			$config_file='../../app/etc/config.xml';

			if (file_exists($config_file)) {
				$xml = simplexml_load_file($config_file);
				$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
				$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
				$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
				$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
			}
			$GLOBALS["LINK"] = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
			mysql_select_db ( $CONF_MYSQL_DBNAME , $GLOBALS["LINK"] );

			if (mysql_ping($GLOBALS["LINK"])){
				$do_mysql_reconect=0;
				fputs($stdlog, get_date()." MySQL Connect restored"."\n");
			}


		}
		return "1";
	}


	function get_date()
	{
		return date ( 'd.m.Y H:i:s' );
	}

	function init_nas($LINK,$stdlog)
	{

		$result = mysql_query ( "SELECT * FROM " . BILL_NAS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#2 ".mysql_error ( $LINK ),$LINK );

		for ($i = 0; $i < mysql_num_rows ($result); $i++) {
			$res = mysql_fetch_array ( $result );
			$nases[$i]=$res;
		}

		mysql_free_result ( $result );

		return $nases;
	}

	function init_sysopts($LINK,$stdlog)
	{
		$result = mysql_query ( "SELECT * FROM " . BILL_SYSPOTS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#6 ".mysql_error ( $LINK ),$LINK );
		$res = mysql_fetch_array ( $result );
		mysql_free_result ( $result );

		return $res;
	}
	
	function billing_delete_packets($LINK,$stdlog)
	#�������� ���� �������
	{
		$packets = array();
		mysql_query ( "delete FROM " . BILL_PACKET_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
		
	}
	function billing_delete_all_users($LINK,$stdlog)
	#�������� ���� �������������
	{
		$packets = array();
		mysql_query ( "delete FROM " . BILL_AUTH_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	
	}	
	
	function billing_insert_card($LINK,$stdlog,$value)
	#������� ��������
	{
		$sn=$value['cardnum'];
		$nominal=$value['value'];
		$serie='00'.substr($sn,0,2);
		$card=substr($sn,2,14);

		
		$querry="INSERT INTO " . BILL_CARDS_TABLE . "  (`cards_id` ,`series` ,`added` ,`nominal` ,`expired` ,`sn` ,`status`) VALUES  (NULL,'".$serie."', CURRENT_TIMESTAMP ,'".$nominal."','2015-12-31','".$card."','a'); ";
	
		#		var_dump($querry);
		mysql_query ($querry , $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	
	}	
	
	function billing_insert_user($LINK,$stdlog,$value)
	#������� ������������
	{
		$user=$value['username'];
		$pass=$value['Value'];
		$deposit=round($value['credits'],3);
		$gid=$value['srvid'];
		$phone=$value['phone'];
		$address=$value['address'];
		$sectorid='1';
		$user_real=$value['usestaticip'];
		$framed_ip=$value['staticip'];
		$fio=$value['lastname']." ".$value['firstname'];
		$prim=$value['state'];
		$email=$value['email'];
		$add_date=$value['createdon'];
		$inn=$value['taxid'];
		$mob_tel=$value['mobile'];
		$sms_tel=$value['mobile'];
		$date_abonka=$value['date_abonka'];
		$querry="INSERT INTO " . BILL_AUTH_TABLE . "  (`user`, `password`,`gid`, `deposit`,`phone`,`address`,`sectorid`,`framed_ip`,`real_ip`,`fio`,`prim`,`email`,`add_date`,`inn`,`mob_tel`,`sms_tel`,`date_abonka`) VALUES ('".$user."','".$pass."',".$gid.",".$deposit.",'".$phone."','".$address."',".$sectorid.",'".$framed_ip."',".$user_real.",'".$fio."','".$prim."','".$email."','".$add_date."','".$inn."','".$mob_tel."','".$sms_tel."',".$date_abonka."); ";
	
#		var_dump($querry);
if ($deposit<0){
var_dump($deposit);	
#var_dump($value['']);	
}
#		mysql_query ($querry , $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	
	}
		
	function billing_insert_packet($LINK,$stdlog,$value)
	#������� ������
	{
		$gid=$value['srvid'];
		$packet=$value['srvname'];
		$speed_rate=$value['downrate']/1024;
		$speed_burst=$value['uprate']/1024;
		$fixed_cost=round($value['unitprice'],2);
		$querry="INSERT INTO " . BILL_PACKET_TABLE . "  (`packet`, `gid`,`fixed`, `fixed_cost`,`speed_rate`,`speed_burst`,`do_shapers`,`do_mik_rad_shapers`,`use_change_pass`,`use_change_data`) VALUES ('".$packet."',".$gid.",10,".$fixed_cost.",".$speed_rate.",".$speed_burst.",1,1,1,1); ";

#		var_dump($querry);
		
		mysql_query ($querry , $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	
	}
	
	function billing_init_packets($LINK,$stdlog)
	{
        $packets = array();
	$result = mysql_query ( "SELECT * FROM " . BILL_PACKET_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
	for ($i = 0; $i < mysql_num_rows($result); $i++) {
	    $res = mysql_fetch_array($result);
	    $packets[$res["gid"]]=$res;
	}
	    mysql_free_result($result);
	    return $packets;
	}

	function billing_init_packets_old($LINK,$stdlog)
	#�������� ������ ������ �������
	{
		$packets = array();
		$result = mysql_query ( "SELECT * FROM " . OLD_PAKETS . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
		for ($i = 0; $i < mysql_num_rows($result); $i++) {
			$res = mysql_fetch_array($result);
			$packets[$res["srvid"]]=$res;
		}
		mysql_free_result($result);
		return $packets;
	}
	
	function billing_init_old_cards($LINK,$stdlog)
	{
		$packets = array();
		$query = "SELECT cardnum,value FROM ".OLD_CARDS." WHERE used='0000-00-00 00:00:00';";
		$result = mysql_query ($query, $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
		for ($i = 0; $i < mysql_num_rows($result); $i++) {
			$res = mysql_fetch_array($result);
			$packets[$i]=$res;
		}
		mysql_free_result($result);
		return $packets;	
	}
	
	function billing_init_users_old($LINK,$stdlog)
	#�������� ������ ������ �������������
	{
		$packets = array();
#		$query =  "SELECT * FROM " . OLD_USERS . " WHERE 1 ";
		$query = "SELECT * FROM ".OLD_USERS." U , ".OLD_PASS." P WHERE U.username=P.UserName and attribute='Cleartext-Password';";
		$result = mysql_query ($query, $LINK ) or do_log_sql($stdlog,"#1 ".mysql_error($LINK),$child );
		for ($i = 0; $i < mysql_num_rows($result); $i++) {
			$res = mysql_fetch_array($result);
			$packets[$i]=$res;
		}
		mysql_free_result($result);
		return $packets;
	}	
	
	function get_users_by_gid($LINK,$stdlog,$gid )
	{
	    $result = mysql_query ( "SELECT * FROM " . BILL_AUTH_TABLE . " WHERE gid=".$gid." ", $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
	    $res = mysql_fetch_array ( $result );
		for ($i = 0; $i < mysql_num_rows($result); $i++) {
	        	$res = mysql_fetch_array($result);
			$users[$res["uid"]]=$res;
		}

	    mysql_free_result ( $result );
	    
	    return $users;
	}
	function get_all_users($LINK,$stdlog)
	{
	    $result = mysql_query ( "SELECT * FROM " . BILL_AUTH_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
		for ($i = 0; $i < mysql_num_rows($result); $i++) {
	        	$res = mysql_fetch_array($result);
			$users[$res["uid"]]=$res;
		}

	    mysql_free_result ( $result );
	    
	    return $users;
	}
	
	function update_user($LINK,$stdlog,$uid,$framed_ip)
	{
	    mysql_query ( "UPDATE " . BILL_AUTH_TABLE . " SET framed_ip='".$framed_ip."' WHERE uid=".$uid, $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error($LINK),$child);
	}
							
	global $LINK;
	
	$LINK = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
	if (!$LINK) {
		do_log($stdlog,"Cant connect to DB ".$CONF_MYSQL_HOST);
		exit();
	}

	mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK ) or die('Could not select database.');
	mysql_query("SET NAMES koi8r", $LINK );
	mysql_query("SET CHARSET koi8r", $LINK );

	
	$old_cards_list=billing_init_old_cards($LINK,$stdlog);
		
	foreach ($old_cards_list as $key=>$value)
	{
		
		billing_insert_card($LINK,$stdlog,$value);

	}
	
var_dump(count($old_cards_list));
	
mysql_close($LINK);



