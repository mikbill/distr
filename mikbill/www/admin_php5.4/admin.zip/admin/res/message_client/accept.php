<?php

if (isset($_SERVER['REMOTE_ADDR'])){
	$ip_remote=$_SERVER['REMOTE_ADDR'];
}else{
	$ip_remote="";
}

if ($ip_remote!=""){
	define ("BILL_AUTH_TABLE","users");
	define ("BILL_NAS_TABLE", "radnas" );
	define ("BILL_NASLOG_TABLE", "radnaslog" );
	define ("BILL_SYSPOTS_TABLE", "sysopts" );
	$config_file='../../app/etc/config.xml';

	if (file_exists($config_file)) {
		$xml = simplexml_load_file($config_file);

		$CONF_IP   = (string) $xml->parameters->kernel->ip;
		$CONF_PORT = (string) $xml->parameters->kernel->port;
		$CONF_PID  = (string) $xml->parameters->kernel->pid;
		$CONF_LOG  = (string) $xml->parameters->kernel->log;
		$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
		$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
		$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
		$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;

	} else {
		die("config not found");
	}

	function open_logs($CONF_LOG)
	{
		return 	fopen($CONF_LOG, "a");
	}

	$stdlog = open_logs($CONF_LOG);


	function do_log($stdlog,$text_log)
	{
		fputs($stdlog, get_date()." ".$text_log."\n");
	}

	function do_log_sql($stdlog,$text_log,&$LINK)
	{
		if (!mysql_ping($GLOBALS["LINK"]))
		{
			$do_mysql_reconect=1;
			fputs($stdlog, get_date()." MySQL Connect failed"."\n");
		}else{
			fputs($stdlog, get_date()." ".$text_log."\n");
		}

		while ($do_mysql_reconect==1)
		{
			$config_file='../../app/etc/config.xml';

			if (file_exists($config_file)) {
				$xml = simplexml_load_file($config_file);
				$CONF_MYSQL_HOST     = (string) $xml->parameters->mysql->host;
				$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
				$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
				$CONF_MYSQL_DBNAME   = (string) $xml->parameters->mysql->dbname;
			}
			$GLOBALS["LINK"] = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
			mysql_select_db ( $CONF_MYSQL_DBNAME , $GLOBALS["LINK"] );

			if (mysql_ping($GLOBALS["LINK"])){
				$do_mysql_reconect=0;
				fputs($stdlog, get_date()." MySQL Connect restored"."\n");
			}


		}
		return "1";
	}


	function get_date()
	{
		return date ( 'd.m.Y H:i:s' );
	}

	function init_nas($LINK,$stdlog)
	{

		$result = mysql_query ( "SELECT * FROM " . BILL_NAS_TABLE . " WHERE id=3 ", $LINK ) or do_log_sql($stdlog,"#2 ".mysql_error ( $LINK ),$LINK );

		for ($i = 0; $i < mysql_num_rows ($result); $i++) {
			$res = mysql_fetch_array ( $result );
			$nases[$i]=$res;
		}

		mysql_free_result ( $result );

		return $nases;
	}

	function init_sysopts($LINK,$stdlog)
	{
		$result = mysql_query ( "SELECT * FROM " . BILL_SYSPOTS_TABLE . " WHERE 1 ", $LINK ) or do_log_sql($stdlog,"#6 ".mysql_error ( $LINK ),$LINK );
		$res = mysql_fetch_array ( $result );
		mysql_free_result ( $result );

		return $res;
	}

	function get_user_proper_by_ip($LINK,$stdlog,$ip )
	{
		$result = mysql_query ( "SELECT * FROM " . BILL_AUTH_TABLE . " WHERE local_ip='".$ip."' or framed_ip='".$ip."' ", $LINK ) or do_log_sql($stdlog,"#12 ".mysql_error ( $LINK ) ,$LINK);
		$res = mysql_fetch_array ( $result );
		mysql_free_result ( $result );
		return $res;
	}

	global $LINK;

	$LINK = mysql_pconnect ( $CONF_MYSQL_HOST ,  $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD );
	if (!$LINK) {
		do_log($stdlog,"Cant connect to DB ".$CONF_MYSQL_HOST);
		exit();
	}

	mysql_select_db ( $CONF_MYSQL_DBNAME , $LINK ) or die('Could not select database.');

	$nases = init_nas($LINK,$stdlog);

	$sysoptions = init_sysopts($LINK,$stdlog);



	$nas=$nases[0];
	$IP_SRV=$nas['nasname'];
	$Login_SRV=$nas['naslogin'];
	$Pass_SRV=$nas['naspass'];
	$ssh='/usr/bin/ssh '.$Login_SRV.'@'.$IP_SRV;
	$mik_ssh=$sysoptions['sudo'].' '.$ssh.' ';

	$user = get_user_proper_by_ip($LINK,$stdlog,$ip_remote);
	$command='/ip firewall address-list remove  [/ip firewall address-list find address='.$user['local_ip'].']';
	exec($mik_ssh.$command." &>/dev/null 2>&1");
	$command='/ip firewall address-list remove  [/ip firewall address-list find address='.$user['framed_ip'].']';
	exec($mik_ssh.$command." &>/dev/null 2>&1");
	sleep(2);
	header("Location: ".$_POST['url']);
}
php?>
<html>
<script language="JavaScript">
<!-- hide
function closeIt() {
close();
}
// -->
</script>
<body onload="closeIt()">
<center><img width="250" height="95" src="logo2.png" alt="" /></center>
<center>
<form>
<input type=button value="���������� ������" onClick="closeIt()">
</form>
</center>
</body>
</html>



