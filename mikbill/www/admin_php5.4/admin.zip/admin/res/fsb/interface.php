<html>
<head>
<title> </title>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script src="jquery-latest.js"></script>
<style>
label { padding-right: 20px; }
select { padding: 0px 10px 0px 10px; }
#head { width: 800px; }
#exit { margin-left: 500px; }
#output table td { min-width: 100px; padding: 0px 10px 0px 10px; } 

#insert_1 tr:first-child, #insert_2 tr:first-child { background-color: #FFFFAA; }
#insert_1 td, #insert_2 td { border: 1px solid black; }
</style>
<script>
window.onload = function () {
    var day = new Date,
        md = (new Date(day.getFullYear(), day.getMonth() + 1, 0, 0, 0, 0, 0)).getDate(),
        $month_name = "Января Февраля Марта Апреля Мая Июня Июля Августа Сентября Октября Ноября Декабря".split(" ");
 
    function set_select(a, c, d, e) {
        var el = document.getElementsByName(a)[0];
        for (var b = el.options.length = 0; b < c; b++) {
            el.options[b] = new Option(a == 'month' ? $month_name[b] : b + d, b + d);
         }
        el.options[e] && (el.options[e].selected = !0)
    }
    set_select("day", md, 1, day.getDate() - 1);
    set_select("month", 12, 1, day.getMonth());
    set_select("year", 11, day.getFullYear()-10, 10);
 
 
    var year = document.getElementById('year');
    var month = document.getElementById("month");
 
    function check_date() {
        var a = year.value | 0,
            c = month.value | 0;
        md = (new Date(a, c, 0, 0, 0, 0, 0)).getDate();
        a = document.getElementById("day").selectedIndex;
        set_select("day", md, 1, a)
    };
 
    if (document.addEventListener) {
        year.addEventListener('change', check_date, false);
        month.addEventListener('change', check_date, false);
 
    } else {
        year.detachEvent('onchange', check_date);
        month.detachEvent('onchange', check_date);
    }
 
}

function doQuery()
{	
	$("#search").text("Поиск...");
	$.post( "index.php", $( "#input_form" ).serialize(), function( data ) 
	{
		console.log(data);
		
		$("#insert_1").empty();
		$("#insert_2").empty();
			
		if(data != "")
		{
			var $box = $("#insert_"+data[0].table);
			
			var html = '';		
			
			if(data[0].table == 1)
				html += '<tr> <td> Логин </td><td> IP адрес </td><td> Ф.И.О. </td><td> Адрес </td><td> Подключился </td><td> Отключился </td> </tr>';
			
			if(data[0].table == 2)
				html += '<tr> <td> Логин </td><td> Ф.И.О </td><td> Адрес </td> </tr>';
				
			for (var line in data)
			{
				console.log(data[line].table);
				if(data[line].table == 1)
				{
					html += '<tr>';
					html += '<td>'+data[line].user+'</td>';
					html += '<td>'+data[line].ip+'</td>';
					html += '<td>'+data[line].fio+'</td>';
					html += '<td>'+data[line].address+'</td>';
					html += '<td>'+data[line].start+'</td>';
					html += '<td>'+data[line].stop+'</td>';
					html += '</tr>';
				}
				
				if(data[line].table == 2)
				{
					html += '<tr>';
					html += '<td>'+data[line].user+'</td>';
					html += '<td>'+data[line].fio+'</td>';
					html += '<td>'+data[line].address+'</td>';
					html += '</tr>';
				}
			}
			
			$box.append(html);
		}
		$("#search").text("Поиск завершен");
		setTimeout(function(){$("#search").text("Поиск");}, 1000);
		
	}, 'json');

}

</script>
</head>
<body>
<div id="container">
	<div id="head"><b> Поиск пользователя: </b></div>
	<div id="input">
		<form id="input_form" action="http://google.com" method="POST">
			<input type="hidden" name="request" value="search">
			<table>
				<tr>
					<td> Логин </td> <td> <input name="login"/> </td> <td> IP </td> <td> <input name="ip"/> </td>
				</tr>
				<tr>
					<td> Адрес </td> <td> <input name="address" /> </td> <td> Ф.И.О </td> <td> <input name="fio" /> </td>
				</tr>
			</table>
				<h4> Статистика за период: </h4>
			<table>
				<tr>
					<td> Год </td> <td> <select name="year" id="year"> </select> </td>
					<td> Месяц </td> <td> <select name="month" id="month"> </select> </td>
					<td> День </td><td> <select name="day" id="day"> </select> </td>
				</tr>
			</table>
		</form>
		<button id="search" onclick="doQuery();"> Поиск </button> <a id="exit" href="index.php?page=logout"><button>Выход</button></a>
	</div>
	<hr> 
	<div id="output">
	
		<h4> Результаты по логину и IP: </h4>
		<table id="insert_1">
			<tr> <td> Логин </td><td> IP адрес </td><td> Ф.И.О. </td><td> Адрес </td><td> Подключился </td><td> Отключился </td> </tr>
		</table>
	

		<h4> Результаты по адресу и Ф.И.О: </h4>
		<table id="insert_2">
			<tr> <td> Логин </td><td> Ф.И.О </td><td> Адрес </td> </tr>
		</table>
		
	</div>
</div>
</body>
</html>