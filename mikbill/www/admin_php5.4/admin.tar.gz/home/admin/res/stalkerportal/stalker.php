﻿<?php

ini_set('maximum_execution_time', 3600);
$config_file = '/var/www/mikbill/admin/app/etc/config.xml';
$config_file = 'D:\\WORK\\SOFT\\OpenServer\\domains\\admin2x\\app\\etc\\config.xml';
$pathToLogFile = './stalker.log';

echo "<pre>";
include('./stalker_helper.php');

$link = connectToDB($CONF_MYSQL_HOST, $CONF_MYSQL_USERNAME, $CONF_MYSQL_PASSWORD, $CONF_MYSQL_DBNAME);

# получить сис. опции
$StalkerOptions = getSystemOptionsStalker($link);

$StalkerOptions['stalkerportal_login'] = 'stalker_portal';
$StalkerOptions['stalkerportal_pass'] = 'NKMRjRdRJvC5WOT7';
$StalkerOptions['stalkerportal_host'] = '194.125.224.16';
$StalkerOptions['stalkerportal_port'] = '88';
$StalkerOptions['stalkerportal_path'] = '';

if (!isset($StalkerOptions['stalkerportal_login'], $StalkerOptions['stalkerportal_pass'], $StalkerOptions['stalkerportal_host'])) {
	die('Stalker does not configured in system options.');
}

# Так же, не забываем включить API в конфиге Сталкера (/stalker_porta/server/custom.ini) при помощи добавления следующих строк:
# enable_api = true
# api_auth_login = логин_для_авторизации_при_доступе_к_API
# api_auth_password = пароль_для_авторизации_при_доступе_к_API

if (isset($StalkerOptions['stalkerportal_https']) AND $StalkerOptions['stalkerportal_https'] == 1) {
	$scheme = 'https';
} else {
	$scheme = 'http';
}

if (!isset($StalkerOptions['stalkerportal_port'])) {
	$StalkerOptions['stalkerportal_port'] = '88';
}

if (!isset($StalkerOptions['stalkerportal_path'])) {
	$StalkerOptions['stalkerportal_path'] = '';
}

$StalkerOptions['stalkerportal_api'] = $scheme . '://' . $StalkerOptions['stalkerportal_host'] . ':' . $StalkerOptions['stalkerportal_port'] . '/' . $StalkerOptions['stalkerportal_path'] . 'api/';

# file_get_contents test
//testRequest();
# cURL test

# пользователь - это приставка
testRequestNew();

$usersCount = count(jsonRequestRead('accounts'));

$newUser = array(
	'login' => 'test' . $usersCount,
	'password' => '123'
);
$query = http_build_query($newUser);
//var_dump(jsonRequestCreate('accounts', $query));
var_dump(jsonRequestDelete('users', 'test1'));






function testRequest()
{
	print_r(jsonRequest('GET', 'accounts'));
}

function testRequestNew()
{
	print_r(jsonRequestNewCall('GET', 'accounts'));
}

//jsonRequest("delete",
//	array(
//		"from" => "package",
//	)
//);
//jsonRequest("delete",
//	array(
//		"from" => "terminal",
//	)
//);
//jsonRequest("delete",
//	array(
//		"from" => "subscriber",
//	)
//);

$usersMikBiLLLogin = array();
$usersIPTV = array();
$addUsers = array();
$deleteUsers = array();
$currentUsers = array();

# синхронищзация пакетов (услуг)
//syncServicesIPTV($link);
//
//$usersMikBiLL = getUsersWithServices($link);
//
//foreach ($usersMikBiLL as $user) {
//	$usersMikBiLLLogin[$user['user']] = 0;
//}
////print_r($usersMikBiLL);
//# по каждому абоненту выберем оборудование и услуги
//
//# выборка списка абонентов
//$usersIPTVList = getUsersIPTV();
////echo 'select users: ';
////print_r($usersIPTVList);
////print_r($usersMikBiLL);
//
//foreach ($usersIPTVList as $user) {
//	$usersIPTV[$user[1]] = $user;
//}
//
//foreach ($usersMikBiLL as $user) {
//	if (!isset($usersIPTV[$user['user']])) {
//		# новый
//		$addUsers[] = $user;
//	} else {
//		# уже есть - обновить
//		$currentUsers[] = $user;
//	}
//}
//
//foreach ($usersIPTV as $user) {
//	if (!isset($usersMikBiLLLogin[$user[1]])) {
//		# удаление по логину
//		$deleteUsers[] = $user[1];
//	}
//}
//
//unset($usersMikBiLL, $usersIPTVList);
//
//echo "\ndel:\n";
//#print_r($deleteUsers);
//deleteAccountsIPTV($deleteUsers);
//echo "\nadd:\n";
//#print_r($addUsers);
//addAccountIPTV($addUsers);
//
//sunkSubscriberServices();

# @TODO выбрать абонов с биллнга с услугами

# @TODO кого нет в портале - добавим, кого нет в биллинге - удалим с портала







function addAccountIPTV($usersList)
{
	if (!empty($usersList)) {
		global $link;
		$usersData = array();
		$usersDevicesData = array();
		$MikBiLL2IPTV = array();
		$userDevice = array();
		$devices = array();
		$UIDsRow = '';
		$devidsRow = '';

		foreach ($usersList as $user) {
			$UIDsRow .= $user['uid'] . ',';
			$usersData[] = array(
				$user['user'],
				$user['password']
			);
		}

		$UIDsRow = substr($UIDsRow, 0, -1);

		# добавление абонентов
		$result = jsonRequest("insert", array(
			"into"      => "subscriber",
			"columns"   => array(
				"username",
				"password"
			),
			"values"    => $usersData,
			"returning" => "id"
		));
		echo 'insert cmd result: ';
		#print_r($result);

		foreach ($result as $key => $subscriberID) {
			$MikBiLL2IPTV[$usersList[$key]['uid']] = $subscriberID;
		}

		$query = "SELECT * FROM `dev_user` WHERE `uid` IN ($UIDsRow) AND `devid` IN (SELECT `devid` FROM `dev_fields` WHERE `key` = 'devtypeid' AND `value` IN (SELECT `devtypeid` FROM `dev_types` WHERE `portal` = 1))";
		$userDeviceTmp = fetchAll($query, $link);

		foreach ($userDeviceTmp as $row) {
			$devidsRow .= $row['devid'] . ',';
			$userDevice[$row['devid']] = $row['uid'];
		}
		$devidsRow = substr($devidsRow, 0, -1);

		$query = "SELECT * FROM `dev_fields` WHERE `devid` IN ($devidsRow)";
		# по каждому новому абоненту выберем и соберём его оборудование из MikBiLL
		$devicesTmp = fetchAll($query, $link);

		# нужно "собрать" устройства
		foreach ($devicesTmp as $device) {
			$devices[$device['devid']][$device['key']] = $device['value'];
		}

//		var_dump($userDevice['14'], $MikBiLL2IPTV[$userDevice[14]]);

		if (!empty($devices)) {
			foreach ($devices as $devid => $device) {
				$usersDevicesData[] = array(
					$MikBiLL2IPTV[$userDevice[$devid]],
					isset($device['dev_mac']) ? $device['dev_mac'] : '00:00:00:00:00:00',
					true
				);
			}

			# добавление терминала с мак-адресом
			$res = jsonRequest("insert",
				array(
					"into"    => "terminal",
					"columns" => array(
						"subscriber_id",
						"mac_addr",
						"registered"
					),
					"values"  => $usersDevicesData
					//			"returning" => "id"
				)
			);
//		echo 'insert cmd result: ';
//		print_r($res);
		}
	}
}

function deleteAccountsIPTV($usersList)
{
	if (!empty($usersList)) {
		# составим список для удаления
		$deleteList = array(
			'username'
		);

		foreach ($usersList as $user) {
			$deleteList[] = $user;
		}

//		var_dump($deleteList);

		# удаление абонентских устройств акаунта "123456"
		$res = jsonRequest("delete",
			array(
				"from"  => "terminal",
				"where" => array(
					"in" => array(
						"subscriber_id",
						array(
							"select" => array(
								"data"  => "id",
								"from"  => "subscriber",
								"where" => array(
									"in" => $deleteList
								)
							)
						)
					)
				),
				//			"returning" => "id"
			));
//		echo 'delete cmd result: ';
//		print_r($res);

# удаление пакетов для акаунта "123456"
		$res = jsonRequest("delete", array(
			"from"      => "subscriber_package",
			"where"     => array(
				"in" => array(
					"subscriber_id",
					array(
						"select" => array(
							"data"  => "id",
							"from"  => "subscriber",
							"where" => array(
								"in" => $deleteList
							)
						)
					)
				)
			),
//			"returning" => "package_id"
		));
//		echo 'delete cmd result: ';
//		print_r($res);

# удаление аккаунта 123456
		$res = jsonRequest("delete", array(
			"from"      => "subscriber",
			"where" => array(
				"in" => $deleteList
			),
//			"returning" => "id"
		));
//		echo 'delete cmd result: ';
//		print_r($res);
	}
}

function changeCurrentUsers($usersMikBiLL, $usersIPTV)
{
	# проверка паролей
	foreach ($usersMikBiLL as $user) {
		if ($usersIPTV[$user['user']][2] != $user['user']['password']) {
			# @TODO action
		}
	}


}


function send($url, $data, $extra_headers = null)
{
	$errorCounter = 0;
	$content = null;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	if (isset($extra_headers)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $extra_headers);
	}

	while ($errorCounter < 100) {
		//echo "HTTP fetching '$url'...\n";
		$content = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if ($content === false) {
			$err_msg = "HTTP error: $http_code (" . curl_error($ch) . ')' . '\n';
			echo $err_msg;
//		throw new Exception ($err_msg);
		} elseif ($http_code != 200) {
			$err_msg = "HTTP request failed ($http_code)\n";
			echo $err_msg;
//		throw new Exception ($err_msg);
		} else {
			//echo "HTTP OK ($http_code)\n";
			curl_close($ch);
			break;
		}
		$errorCounter++;
	}

	return $content;
}

function jsonRequestCall($url, $opts)
{
	$ctx = stream_context_create($opts);

	return file_get_contents($url, false, $ctx);
//	static $req_id = 1;

//	$req = array(
//		"jsonrpc" => '2.0',
//		"id"      => $req_id++,
//		"method"  => $method,
//		"params"  => $params
//	);
//	$req = json_encode($req);
//	$res = send($url, $req, $extra_headers);
//	#echo $res;
//	$res = json_decode($res, true);
//	if (!isset($res)) {
//		echo "error: not result\n";
//
//		return null;
//	} elseif (isset($res['error'])) {
////	} elseif (!array_key_exists('result', $res) || !isset($res['result'])) {
//		print_r($res['error']);
//
//		return null;
//	} else {
//		return $res['result'];
//	}
}

function jsonRequest($http_method, $resource, $content = null)
{
	global $StalkerOptions;

	$auth = sprintf('Authorization: Basic %s',
		base64_encode($StalkerOptions['stalkerportal_login'] . ':' . $StalkerOptions['stalkerportal_pass'])
	);

	$header = array(
		"Content-Type: application/json",
		$auth
	);

	$opts = array(
		'http' => array(
			'method' => $http_method,
			'header' => implode("\r\n", $header)
		)
	);

	if (!is_null($content)) {
		$opts['http']['content'] = $content;
	}

	return json_decode(jsonRequestCall($StalkerOptions['stalkerportal_api'] . $resource, $opts), true);
}

# CRUD
function jsonRequestCreate($resource, $postBody)
{
	return jsonRequestNewCall('POST', $resource, $postBody);
}

function jsonRequestRead($resource, $identifiers = '')
{
	return jsonRequestNewCall('GET', $resource, null, $identifiers);
}

function jsonRequestUpdate($resource, $postBody, $identifiers = '')
{
	return jsonRequestNewCall('PUT', $resource, $postBody, $identifiers);
}

function jsonRequestDelete($resource, $identifiers)
{
	return jsonRequestNewCall('DELETE', $resource, null, $identifiers);
}

function jsonRequestNewCall($http_method, $resource, $postBody = null, $identifiers = '')
{
	global $StalkerOptions;
	$errorCounter = 0;
	$maxErrors = 3;
	$url = $StalkerOptions['stalkerportal_api'] . $resource . '/' . $identifiers;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $http_method);

	if (!is_null($postBody)) {
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postBody);
	}

	$auth = sprintf('Authorization: Basic %s',
		base64_encode($StalkerOptions['stalkerportal_login'] . ':' . $StalkerOptions['stalkerportal_pass'])
	);

	$header = array(
		"Content-Type: application/json",
		$auth
	);

	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

	while ($errorCounter < $maxErrors) {
		//echo "HTTP fetching '$url'...\n";
		$response = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		if ($response === false) {
			$err_msg = "HTTP error: $http_code (" . curl_error($ch) . ')' . '\n';
			echo $err_msg;
//		throw new Exception ($err_msg);
		} elseif ($http_code != 200) {
			$err_msg = "HTTP request failed ($http_code)\n";
			echo $err_msg;
//		throw new Exception ($err_msg);
		} else {
			//echo "HTTP OK ($http_code)\n";
			curl_close($ch);
			break;
		}
		$errorCounter++;
		sleep($errorCounter * 2);
	}

	if ($maxErrors == $errorCounter) {
		# вывести ошибку
		echo "max errors count was reached\n";
	} else {
		$response = json_decode($response, true);

		if ($response['status'] == 'OK') {
			return $response['results'];
		} elseif ($response['status'] == 'ERROR' AND isset($response['error'])) {
			return $response['error'];
		} else {
			# ???
			return null;
		}
	}
}
