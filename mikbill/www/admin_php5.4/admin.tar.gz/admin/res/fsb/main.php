<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>MIKBILL | Search module </title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">

    <!-- FooTable -->
    <link href="css/plugins/footable/footable.core.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/plugins/datapicker/datepicker3.css" rel="stylesheet">
</head>

<body>

    <div id="wrapper">

        <div class="row border-bottom">
            <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0; margin-left:10px;">
                <ul class="nav navbar-top-links navbar-right">
                    <li>
                        <a href="index.php?page=logout">
                            <?php //var_dump($result) ?>
                            <i class="fa fa-sign-out"></i> Log out
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-9">
                <h2>Поиск абонентов</h2>
                <ol class="breadcrumb">
                    <li class="active">
                        <strong>Главная</strong>
                    </li>
                </ol>
            </div>
        </div>

        <div class="wrapper wrapper-content animated fadeInRight ecommerce">

            <form id="search" role="form" action="index.php" method="get">
                <div class="ibox-content m-b-sm border-bottom">
                    <div class="row">
                        <h3>Поиск по абонентам:</h3>
                        <input type="hidden" name="request" value="search" form="search">
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label class="control-label" for="login">Логин</label>
                                <input type="text" id="login" name="login" value="<?php echo $_GET["login"]; ?>" placeholder="login" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label class="control-label" for="fio">Ф.И.О</label>
                                <input type="text" id="fio" name="fio" value="<?php echo $_GET["fio"]; ?>" placeholder="Иванов Иван Иванович" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label class="control-label" for="address">Адрес</label>
                                <input type="text" id="address" name="address" value="<?php echo $_GET["address"]; ?>" placeholder="" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label class="control-label" for="dogovor">№ договора</label>
                                <input type="text" id="dogovor" name="dogovor" value="<?php echo $_GET["dogovor"]; ?>" placeholder="" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-2">
                            <div class="form-group">
                                <label class="control-label" for="phone">№ телефона</label>
                                <input type="text" id="phone" name="phone" value="<?php echo $_GET["phone"]; ?>" placeholder="" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <h3>Поиск по сессиям:</h3>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label class="control-label" for="ip">IP</label>
                                <input type="text" id="ip" name="ip" value="<?php echo $_GET["ip"]; ?>" placeholder="127.0.0.1" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label class="control-label" for="date_added">Дата начала</label>
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input id="date_added" name="date_start" type="text" class="form-control" value="
                                        <?php if(isset($_GET["date_start"]) && $_GET["date_start"] != "")
                                            echo str_replace(' ', '', $_GET["date_start"]);
                                        else
                                            echo date("m/d/Y");
                                        ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label class="control-label" for="date_modified">Дата конца</label>
                                <div class="input-group date">
                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        <input id="date_modified" name="date_stop" type="text" class="form-control" value="
                                        <?php if(isset($_GET["date_stop"]) && $_GET["date_stop"] != "")
                                            echo str_replace(' ', '', $_GET["date_stop"]);
                                        else
                                            echo date("m/d/Y");
                                        ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-1">
                            <br/>
                            <button type="submit" class="btn btn-primary block full-width m-b" form="search">Поиск</button>
                        </div>

                    </div>
                </div>
            </form>

            <div class="row">
                <div class="col-lg-12">
                    <div class="ibox">
                        <div class="ibox-content">
                            <input type="text" class="form-control input-sm m-b-xs" id="filter" placeholder="Поиск по таблице">

                            <table class="footable table table-stripped toggle-arrow-tiny" data-page-size="25" data-filter=#filter>
                                <thead>
                                <tr>
                                    <th data-hide="phone,tablet">UID</th>
                                    <th>Логин</th>
                                    <th>Ф.И.О</th>
                                    <th data-hide="phone,tablet">Договор</th>
                                    <th data-hide="phone,tablet">Телефон</th>
                                    <th data-hide="phone,tablet">Адрес</th>
                                    <th data-hide="phone,tablet">Состояние</th>
                                    <th class="text-right">Действие</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php
                                foreach($result as $res)
                                {
                                    echo "
                                        <tr>
                                            <td> {$res["uid"]} </td>
                                            <td> {$res["user"]} </td>
                                            <td> {$res["fio"]} </td>
                                            <td> {$res["numdogovor"]} </td>
                                            <td> {$res["phone"]} </td>
                                            <td> {$res["address"]} </td>
                                            <td> <span class=\"label label-{$res["label"]}\" >{$res["text"]}</span></td>
                                            <td class=\"text-right\"> <a href=\"index.php?request=detail&uid={$res["uid"]}\"><button class=\"label label-plain\">Подробнее</button></a> </td>
                                        </tr>
                                    ";
                                }
                                ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <td colspan="7">
                                        <ul class="pagination pull-right"></ul>
                                    </td>
                                </tr>
                                </tfoot>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

    <!-- Custom and plugin javascript -->
    <script src="js/plugins/pace/pace.min.js"></script>

    <!-- Data picker -->
    <script src="js/plugins/datapicker/bootstrap-datepicker.js"></script>

    <!-- FooTable -->
    <script src="js/plugins/footable/footable.all.min.js"></script>

    <!-- Page-Level Scripts -->
    <script>
        $(document).ready(function() {

            $('.footable').footable();

            $('#date_added').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

            $('#date_modified').datepicker({
                todayBtn: "linked",
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true
            });

        });

    </script>

</body>

</html>
