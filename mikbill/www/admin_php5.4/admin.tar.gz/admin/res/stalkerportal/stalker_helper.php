<?php

include('./SqlConstructor.php');

$pathToLogFile = '';
$config_file = 'D:\\WORK\\SOFT\\OpenServer\\domains\\admin2x\\app\\etc\\config.xml';
$pathToLogFile = 'D:\\WORK\\SOFT\\OpenServer\\domains\\admin2x\\app\\log\\log.txt';

if (file_exists($config_file) AND is_readable($config_file)) {
	$xml = simplexml_load_file($config_file);

	if (empty($pathToLogFile)) {
		$pathToLogFile = (string) $xml->parameters->kernel->log;
	}

	$CONF_MYSQL_HOST = (string) $xml->parameters->mysql->host;
	$CONF_MYSQL_USERNAME = (string) $xml->parameters->mysql->username;
	$CONF_MYSQL_PASSWORD = (string) $xml->parameters->mysql->password;
	$CONF_MYSQL_DBNAME = (string) $xml->parameters->mysql->dbname;
} else {
	die("config not found");
}

//if (file_exists($pathToLogFile) AND is_writable($pathToLogFile)) {
	define('LOG_FILE', trim($pathToLogFile));
//} else {
//	die("Log file don't exist or not writable");
//}

function getSystemOptionsStalker(mysqli $link)
{
	$options = array();

	$query = "SELECT `key`, `value` FROM `system_options` WHERE `key` LIKE 'stalkerportal_%';";
	$tmps = fetchAll($query, $link);

	foreach ($tmps as $tmp) {
		$options[$tmp['key']] = iconv('koi8-u', 'utf-8', $tmp['value']);
	}

	return $options;
}


function getUsersWithServices(mysqli $link)
{
	$users = array();
	$SQLC = new SqlConstructor();

//	$query = "SELECT * FROM " . $SQLC->union_users_with_attributes('1,2,3,4', 'uid, user, password, gid', 0) . " WHERE (`uid` IN (SELECT DISTINCT `uid` FROM `services_users_pairs`) OR `gid` IN (SELECT DISTINCT `gid` FROM services_packets_pairs WHERE serviceid IN (SELECT `serviceid` FROM `services` WHERE `serviceid` > 100 AND service_activation = 0 AND `service_portal` = 1)) OR `uid` IN (SELECT DISTINCT `uid` FROM `dev_user` WHERE `devid` IN (SELECT `devid` FROM `dev_fields` WHERE `key` = 'devtypeid' AND `value` = '1'))) ORDER BY `uid`";
	$query = "SELECT * FROM " . $SQLC->union_users_with_attributes('1,2,3,4', 'uid, user, password, gid', 0) . " WHERE (`uid` IN (SELECT DISTINCT `uid` FROM `services_users_pairs`) OR `gid` IN (SELECT DISTINCT `gid` FROM services_packets_pairs WHERE serviceid IN (SELECT `serviceid` FROM `services` WHERE `serviceid` > 100 AND service_activation = 0 AND `service_portal` = 1)) OR `uid` IN (SELECT DISTINCT `uid` FROM `dev_user` WHERE `devid` IN (SELECT `devid` FROM `dev_fields` WHERE `key` = 'devtypeid' AND `value` IN (SELECT `devtypeid` FROM `dev_types` WHERE `portal` = 1)))) ORDER BY `uid`";
	$usersList = fetchAll($query, $link);

	foreach ($usersList as $user) {
		$tmp = array();

		foreach ($user as $k => $v) {
			$tmp[iconv('koi8-u', 'utf-8', $k)] = iconv('koi8-u', 'utf-8', $v);
		}

		$users[$tmp['uid']] = $tmp;
	}

	return $users;
}

function getServices(mysqli $link)
{
	$services = array();

	$query = "SELECT serviceid, CONCAT(serviceid, ' ', servicename) as servicename, amount FROM `services` WHERE serviceid > 100 AND `service_portal` = 1;";
	$servicesList = fetchAll($query, $link);

	foreach ($servicesList as $service) {
		$tmp = array();

		foreach ($service as $k => $v) {
			$tmp[iconv('koi8-u', 'utf-8', $k)] = iconv('koi8-u', 'utf-8', $v);
		}

		$services[$tmp['serviceid']] = $tmp;
	}

	return $services;
}

function getUsersIPTV()
{
	return jsonRequest("select", array(
		"data" => array(
			"id",
			"username",
			"password"
		),
		"from" => "subscriber"
	));
}

function sunkSubscriberServices()
{
	global $link;
	# MB ID => IPTV ID
	$usersMB2IPTV = array();
	# MB ID => IPTV ID
	$servicesMB2IPTV = array();
	$servicesIPTV = getServicesIPTV();
	$addSubscriberPackets = array();
	$IPTVnames = array();

	foreach ($servicesIPTV as $k => $v) {
		$servicesMB2IPTV[intval($v[1])] = $v[0];
	}

	$activeServicesMB = getActiveServicesMB();
	$activeServicesIPTV = getActiveServicesIPTV();

	$usersMikBiLL = getUsersWithServices($link);
	$usersIPTV = getUsersIPTV();

	foreach ($usersIPTV as $user) {
		$IPTVnames[$user[1]] = $user[0];
	}

	# UID => ID
	# преобразуем через логин UID в subscriber_id
	foreach ($usersMikBiLL as $uid => $user) {
		$usersMB2IPTV[$uid] = $IPTVnames[$user['user']];
	}

	foreach ($activeServicesMB as $uid => $user) {
		foreach ($user as $serviceid => $v) {
			if (isset($usersMB2IPTV[$uid]) AND !isset($activeServicesIPTV[$usersMB2IPTV[$uid]][$servicesMB2IPTV[$serviceid]])) {
				$addSubscriberPackets[] = array(
					$usersMB2IPTV[$uid],
					$servicesMB2IPTV[$serviceid],
					true
				);
			}
		}
	}

	#print_r($addSubscriberPackets);

	if (!empty($addSubscriberPackets)) {
		# добавление пакетов
		$res = jsonRequest("insert", array(
			"into"      => "subscriber_package",
			"columns"   => array(
				"subscriber_id",
				"package_id",
				"enabled"
			),
			"values"    => $addSubscriberPackets,
						"returning" => "package_id"
		));
		echo 'insert cmd result: ';
		#print_r($res);
	}
}

function getActiveServicesMB()
{
	global $link;
	$activeServices = array();

	$query = "SELECT DISTINCT uid, serviceid FROM services_logs WHERE `date` > NOW() AND `serviceid` IN (SELECT `serviceid` FROM `services` WHERE `serviceid` > 100 AND `service_portal` = 1);";
	$activeServicesTmp = fetchAll($query, $link);

	foreach ($activeServicesTmp as $tmp) {
		$activeServices[$tmp['uid']][$tmp['serviceid']] = 1;
	}

	return $activeServices;
}

function getActiveServicesIPTV()
{
	$servicesIPTV = array();

	$servicesIPTVList = jsonRequest("select", array(
		"data" => array(
			"subscriber_id",
			"package_id",
			"expired_on",
			"enabled",
		),
		"from" => "subscriber_package"
	));

	foreach ($servicesIPTVList as $v) {
		$servicesIPTV[$v[0]][$v[1]] = $v;
	}

	return $servicesIPTV;
}

function getServicesIPTV()
{
	$servicesIPTVList = jsonRequest("select", array(
		"data" => array(
			"id",
			"name",
			"cost",
			"paid",
		),
		"from" => "package"
	));

	return $servicesIPTVList;
}

function syncServicesIPTV(mysqli $link)
{
	$servicesAdd = array();
	$servicesMB = getServices($link);
	$servicesIPTV = getServicesIPTV();
	$IPTVnames = array();

	foreach ($servicesIPTV as $service) {
		$IPTVnames[$service[1]] = $service[0];
	}

	foreach ($servicesMB as $service) {
		if (!isset($IPTVnames[$service['servicename']])) {
			$servicesAdd[] = $service;
		}
	}

	servicesAdd($servicesAdd);
}

function servicesAdd($servicesAdd)
{
//	jsonsql_call("delete",
//		array(
//			"from" => "package",
//		)
//	);
	$servicesMB2IPTV = array();

	$serviceData = array();
	foreach ($servicesAdd as $service) {

		# Если цена услуги 0 тогда - бесплатная
		if (isset($service['amount']) and $service['amount'] == '0'){
			$paid = false;
		}else{
			$paid = true;
		}

		$serviceData[] = array(
			$service['servicename'],
			$paid
		);
	}

	# добавление пакетов
	if (!empty($servicesAdd)) {
		$result = jsonRequest("insert",
			array(
				"into"      => "package",
				"columns"   => array(
					"name",
					//			"cost",
					"paid"
				),
				"values"    => $serviceData,
				"returning" => "id"
			));
		echo 'insert services result: ';
		#print_r($result);
	}

	# выбрать все услуги
	$servicesIPTV = getServicesIPTV();


}

#
# MAIN function section
#

function get_date()
{
	return date('d.m.Y H:i:s');
}

function doSystemLog($text_log)
{
	file_put_contents(LOG_FILE, get_date() . "\t" . $text_log . "\n", FILE_APPEND);
}

function SQLConnectFail($link)
{
	echo 'Connect Error (' . $link->connect_errno . ') ' . $link->connect_error . "\n";
	doSystemLog('Connect Error (' . $link->connect_errno . ') ' . $link->connect_error);
}

function connectToDB($dbhost, $dbuser, $dbpass, $dbname, $coding = 'koi8r')
{
	$link = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

	if ($link->connect_error) {
		SQLConnectFail($$link);
		die();
	}

	$link->query("SET NAMES $coding;") or die('Could not SET NAMES.');
	$link->set_charset($coding);

	return $link;
}

function SQLFail($query, $link)
{
	doSystemLog('SQL Error (' . $link->connect_errno . ') ' . $link->connect_error . ", query: $query");
}

/**
 * Если получили только одну запись, то возаращаем её, иначе - false
 *
 * @param $query
 * @param $link
 *
 * @return bool
 */
function fetchRowIfOne($query, mysqli $link)
{
	$result = $link->query($query);

	if ($link->errno) {
		SQLFail($query, $link);
		die();
	}

	if ($result->num_rows == 1) {
		$row = $result->fetch_assoc();

		$result->free();

		return $row;
	}

	$result->free();

	return array();
}

/**
 * @param        $query
 * @param mysqli $link
 *
 * @return array
 */
function fetchRow($query, mysqli $link)
{
	$result = $link->query($query);

	if ($link->errno) {
		SQLFail($query, $link);
		die();
	}

	$row = $result->fetch_assoc();
	$result->free();

	if (is_null($row)) {
		$row = array();
	}

	return $row;
}

/**
 * Возвращаем массив записей
 *
 * @param        $query
 * @param mysqli $link
 *
 * @return array
 */
function fetchAll($query, mysqli $link)
{
	$result = $link->query($query);

	if ($link->errno) {
		SQLFail($query, $link);
		die();
	}

	if ($result->num_rows != 0) {
		$rows = array();

		while ($row = $result->fetch_array(MYSQLI_ASSOC)) {
			$rows[] = $row;
		}

		$result->free();

		return $rows;
	} else {
		$result->free();

		return array();
	}
}

/**
 * Выполняем query, в случае неуспеха - системный лог
 *
 * @param $link
 * @param $query
 * @param $logMassage
 */
function queryWithSystemLog($link, $query, $logMassage)
{
	$link->query($query) OR doSystemLog($logMassage . " " . iconv('koi8-r', 'utf-8', $link->error . ": $query"));
}

