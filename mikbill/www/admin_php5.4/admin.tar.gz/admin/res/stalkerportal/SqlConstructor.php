<?php
class SqlConstructor
{
	protected $_users = '`users`';
	protected $_usersblok = '`usersblok`';
	protected $_usersdel = '`usersdel`';
	protected $_usersfreeze = '`usersfreeze`';

	// Вспомогательные ф-ии
	/**
	 * Убираем пробелы и дробим на запятых
	 *
	 * @param string $income
	 *        	что делим
	 * @return array
	 */
	private function kill_spaces_and_explode($income)
	{
		return explode(',', str_replace(' ', '', $income));
	}

	/** Возвращает название базы пользователей по id
	 *
	 * @param int $tableID id таблицы
	 *
	 * @return string
	 */
	private function get_users_table_name_by_id($tableID)
	{
		switch ($tableID)
		{
			case 1:
				return $this->_users;
			case 2:
				return $this->_usersblok;
			case 3:
				return $this->_usersdel;
			case 4:
				return $this->_usersfreeze;
		}
	}

	/**
	 * Возвращает '(UNION) as userslist' для заданных таблиц юзеров по параметрам
	 *
	 * @param string $tables = '1,2,3,4' id таблиц
	 * @param string $fields = '`uid`, `swid`, `houseid`' какие атрибуты вернуть
	 * @param int    $status = 1 возвращать ли статусы пользователей
	 *
	 * @return string (PROMT) AS userslist
	 */
	public function union_users_with_attributes($tables = '1,2,3,4', $fields = '`uid`, `swid`, `houseid`', $status = 1)
	{
		$result = '(';
		$tables = $this->kill_spaces_and_explode($tables);

		if ($status == 1) {
			for ($i = 0; $i < count($tables); $i++) {
				($i != 0) ? $result .= ' UNION ' : '';
				$result .= "SELECT $fields, '".$this->get_status_by_table_id($tables[$i])."' AS status FROM ".$this->get_users_table_name_by_id($tables[$i]);
			}
		} else {
			for ($i = 0; $i < count($tables); $i++) {
				($i != 0) ? $result .= ' UNION ' : '';
				$result .= 'SELECT '.$fields.' FROM '.$this->get_users_table_name_by_id($tables[$i]);
			}
		}

		$result .= ') AS userslist';
		return $result;
	}

	/**
	 * Возвращаем статус пользователя по id таблицы
	 *
	 * @param string $tableID
	 *
	 * @return string
	 */
	private function get_status_by_table_id($tableID)
	{
		switch ($tableID) {
			case 1:
				return 'normal';
			case 2:
				return 'otkluchen';
			case 3:
				return 'deleted';
			case 4:
				return 'frozen';
		}
	}
}